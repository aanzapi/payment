// FILE: server.js (upgrade with Telegram Channel & Admin)
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const unzipper = require('unzipper');
const { exec } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const execAsync = promisify(exec);

const app = express();
const PORT = 3000;

// ============ TELEGRAM CONFIG ============
// Ganti dengan Bot Token, Channel ID, dan Admin ID kamu
const TELEGRAM_BOT_TOKEN = '7726684474:AAFCvOqrRFET8WKrdqus1VTJNbZCfVl4NJ4';
const TELEGRAM_CHANNEL_ID = '@your_channel_username'; // atau -1001234567890
const TELEGRAM_ADMIN_ID = '8038424443'; // ID Telegram admin

// ============ DATABASE ============
const DB_PATH = path.join(__dirname, 'database');
const USERS_FILE = path.join(DB_PATH, 'users.json');
const BUILDS_FILE = path.join(DB_PATH, 'builds.json');
const SETTINGS_FILE = path.join(DB_PATH, 'settings.json');

// Ensure directories
fs.ensureDirSync(DB_PATH);
fs.ensureDirSync(path.join(__dirname, 'uploads'));
fs.ensureDirSync(path.join(__dirname, 'projects'));
fs.ensureDirSync(path.join(__dirname, 'output'));
fs.ensureDirSync(path.join(__dirname, 'logs'));
fs.ensureDirSync(path.join(__dirname, 'temp'));
fs.ensureDirSync(path.join(__dirname, 'public/css'));
fs.ensureDirSync(path.join(__dirname, 'public/js'));
fs.ensureDirSync(path.join(__dirname, 'views/partials'));

// Initialize databases
if (!fs.existsSync(USERS_FILE)) {
  fs.writeJsonSync(USERS_FILE, [
    { username: 'admin', password: 'admin123', role: 'admin' }
  ], { spaces: 2 });
}

if (!fs.existsSync(BUILDS_FILE)) {
  fs.writeJsonSync(BUILDS_FILE, [], { spaces: 2 });
}

if (!fs.existsSync(SETTINGS_FILE)) {
  fs.writeJsonSync(SETTINGS_FILE, {
    maxUploadSize: 50 * 1024 * 1024,
    autoDelete: true,
    buildLimit: 10
  }, { spaces: 2 });
}

// ============ MIDDLEWARE ============
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'azxcrasher-super-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false,
    maxAge: 24 * 60 * 60 * 1000
  }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ============ TELEGRAM HELPER ============
async function sendTelegramMessage(message, parseMode = 'HTML') {
  if (!TELEGRAM_BOT_TOKEN || TELEGRAM_BOT_TOKEN === 'YOUR_BOT_TOKEN') {
    console.log('📱 [Telegram] Skipped (no token):', message);
    return;
  }

  const messages = [];

  // Send to Channel
  if (TELEGRAM_CHANNEL_ID && TELEGRAM_CHANNEL_ID !== '@your_channel_username') {
    messages.push({ chat_id: TELEGRAM_CHANNEL_ID, message });
  }

  // Send to Admin
  if (TELEGRAM_ADMIN_ID && TELEGRAM_ADMIN_ID !== 'YOUR_ADMIN_ID') {
    messages.push({ chat_id: TELEGRAM_ADMIN_ID, message });
  }

  // Send to both
  for (const msg of messages) {
    try {
      const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
      await axios.post(url, {
        chat_id: msg.chat_id,
        text: msg.message,
        parse_mode: parseMode
      });
      console.log('📱 [Telegram] Notification sent to:', msg.chat_id);
    } catch (error) {
      console.error('❌ [Telegram] Error:', error.message);
    }
  }
}

// ============ MULTER CONFIG ============
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.]/g, '_');
    cb(null, `${uuidv4()}-${safeName}`);
  }
});

const settings = fs.readJsonSync(SETTINGS_FILE);

const upload = multer({
  storage: storage,
  limits: { fileSize: settings.maxUploadSize },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
      cb(null, true);
    } else {
      cb(new Error('Hanya file ZIP yang diperbolehkan'));
    }
  }
});

// ============ AUTH MIDDLEWARE ============
const authMiddleware = (req, res, next) => {
  if (req.session && req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
};

// ============ DB HELPERS ============
const readDB = (file) => {
  try {
    return fs.readJsonSync(file);
  } catch {
    return [];
  }
};

const writeDB = (file, data) => {
  fs.writeJsonSync(file, data, { spaces: 2 });
};

// ============ SSE CLIENTS ============
const clients = new Map();

// ============ BUILD QUEUE ============
class BuildQueue {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
  }

  add(buildId) {
    this.queue.push(buildId);
    this.process();
  }

  async process() {
    if (this.isProcessing || this.queue.length === 0) return;
    
    this.isProcessing = true;
    const buildId = this.queue.shift();
    
    try {
      await this.executeBuild(buildId);
    } catch (error) {
      console.error('Build error:', error);
    } finally {
      this.isProcessing = false;
      this.process();
    }
  }

  broadcastLog(buildId, message) {
    const clients_list = clients.get(buildId) || [];
    clients_list.forEach(client => {
      client.write(`data: ${JSON.stringify({ message, timestamp: new Date().toISOString() })}\n\n`);
    });
  }

  async executeBuild(buildId) {
    const builds = readDB(BUILDS_FILE);
    const build = builds.find(b => b.id === buildId);
    
    if (!build) return;

    build.status = 'building';
    writeDB(BUILDS_FILE, builds);

    // Notifikasi Start Build
    await sendTelegramMessage(
      `⚡ <b>BUILD STARTED</b>\n\n` +
      `📦 Project: <b>${build.projectName}</b>\n` +
      `🆔 ID: <code>${buildId}</code>\n` +
      `⏰ Time: ${new Date().toLocaleString()}\n` +
      `👤 User: ${build.user || 'admin'}`
    );

    const startTime = Date.now();
    const projectPath = path.join(__dirname, 'projects', buildId);
    const logPath = path.join(__dirname, 'logs', `${buildId}.log`);
    const outputPath = path.join(__dirname, 'output');

    try {
      this.broadcastLog(buildId, '📦 Extracting ZIP file...');
      
      const zipPath = path.join(__dirname, 'uploads', build.uploadedFile);
      await fs.ensureDir(projectPath);
      
      await new Promise((resolve, reject) => {
        fs.createReadStream(zipPath)
          .pipe(unzipper.Extract({ path: projectPath }))
          .on('close', resolve)
          .on('error', reject);
      });

      this.broadcastLog(buildId, '✅ ZIP extracted successfully');

      const pubspecPath = path.join(projectPath, 'pubspec.yaml');
      if (!fs.existsSync(pubspecPath)) {
        throw new Error('pubspec.yaml tidak ditemukan');
      }

      this.broadcastLog(buildId, '📦 Running flutter pub get...');
      
      await execAsync('flutter pub get', { cwd: projectPath });
      this.broadcastLog(buildId, '✅ flutter pub get completed');

      this.broadcastLog(buildId, '🔨 Building APK... (this may take a few minutes)');
      
      const buildResult = await execAsync('flutter build apk --release', { 
        cwd: projectPath,
        maxBuffer: 50 * 1024 * 1024
      });

      fs.writeFileSync(logPath, buildResult.stdout + '\n' + buildResult.stderr);
      this.broadcastLog(buildId, '✅ APK build completed');

      const apkSource = path.join(projectPath, 'build/app/outputs/flutter-apk/app-release.apk');
      if (fs.existsSync(apkSource)) {
        const apkDest = path.join(outputPath, `${buildId}.apk`);
        await fs.copy(apkSource, apkDest);
        build.apkPath = apkDest;
        build.status = 'success';
        this.broadcastLog(buildId, '🎉 Build SUCCESSFUL! Download APK available');
        
        // Notifikasi Success
        await sendTelegramMessage(
          `✅ <b>BUILD SUCCESSFUL</b>\n\n` +
          `📦 Project: <b>${build.projectName}</b>\n` +
          `🆔 ID: <code>${buildId}</code>\n` +
          `⏱️ Duration: ${Math.round((Date.now() - startTime) / 1000)}s\n` +
          `📱 APK ready for download!`
        );
      } else {
        throw new Error('APK tidak ditemukan');
      }

    } catch (error) {
      build.status = 'failed';
      fs.writeFileSync(logPath, error.message);
      this.broadcastLog(buildId, `❌ Build FAILED: ${error.message}`);
      console.error('Build failed:', error);
      
      // Notifikasi Error
      await sendTelegramMessage(
        `❌ <b>BUILD FAILED</b>\n\n` +
        `📦 Project: <b>${build.projectName}</b>\n` +
        `🆔 ID: <code>${buildId}</code>\n` +
        `⏱️ Duration: ${Math.round((Date.now() - startTime) / 1000)}s\n` +
        `🐛 Error: ${error.message}`
      );
    }

    build.buildDuration = Date.now() - startTime;
    build.logPath = logPath;
    writeDB(BUILDS_FILE, builds);

    if (settings.autoDelete) {
      await fs.remove(projectPath);
      await fs.remove(zipPath);
    }

    const clients_list = clients.get(buildId) || [];
    clients_list.forEach(client => {
      client.end();
    });
    clients.delete(buildId);
  }
}

const buildQueue = new BuildQueue();

// ============ ROUTES ============

// ROOT
app.get('/', (req, res) => {
  if (req.session && req.session.user) {
    res.redirect('/dashboard');
  } else {
    res.redirect('/login');
  }
});

// LOGIN
app.get('/login', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect('/dashboard');
  }
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const users = readDB(USERS_FILE);
  const user = users.find(u => u.username === username);

  if (!user) {
    return res.render('login', { error: 'Username tidak ditemukan' });
  }

  if (user.password !== password) {
    return res.render('login', { error: 'Password salah' });
  }

  req.session.user = { username: user.username, role: user.role };
  res.redirect('/dashboard');
});

// LOGOUT
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// SSE STREAM
app.get('/stream/:buildId', authMiddleware, (req, res) => {
  const buildId = req.params.buildId;
  
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*'
  });

  if (!clients.has(buildId)) {
    clients.set(buildId, []);
  }
  clients.get(buildId).push(res);

  req.on('close', () => {
    const clientList = clients.get(buildId) || [];
    const index = clientList.indexOf(res);
    if (index > -1) {
      clientList.splice(index, 1);
    }
    if (clientList.length === 0) {
      clients.delete(buildId);
    }
  });
});

// DASHBOARD
app.get('/dashboard', authMiddleware, (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const total = builds.length;
  const success = builds.filter(b => b.status === 'success').length;
  const failed = builds.filter(b => b.status === 'failed').length;
  const waiting = builds.filter(b => b.status === 'waiting' || b.status === 'building').length;

  const recentBuilds = builds.slice(-10).reverse();

  res.render('dashboard', {
    user: req.session.user,
    stats: { total, success, failed, waiting },
    builds: recentBuilds
  });
});

// UPLOAD
app.post('/upload', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Tidak ada file yang diupload' });
    }

    const builds = readDB(BUILDS_FILE);
    const settings = fs.readJsonSync(SETTINGS_FILE);

    const activeBuilds = builds.filter(b => b.status === 'waiting' || b.status === 'building');
    if (activeBuilds.length >= settings.buildLimit) {
      await fs.remove(req.file.path);
      return res.status(429).json({ error: 'Build limit tercapai' });
    }

    const buildId = uuidv4();
    const build = {
      id: buildId,
      projectName: req.body.projectName || 'Untitled',
      status: 'waiting',
      createdAt: new Date().toISOString(),
      buildDuration: 0,
      apkPath: null,
      logPath: null,
      uploadedFile: req.file.filename,
      user: req.session.user.username
    };

    builds.push(build);
    writeDB(BUILDS_FILE, builds);

    buildQueue.add(buildId);

    res.json({ success: true, buildId });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// API BUILDS
app.get('/api/builds', authMiddleware, (req, res) => {
  const builds = readDB(BUILDS_FILE);
  res.json(builds);
});

// GET BUILD LOG
app.get('/api/builds/:id/log', authMiddleware, (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const build = builds.find(b => b.id === req.params.id);
  
  if (!build || !build.logPath) {
    return res.status(404).json({ error: 'Log tidak ditemukan' });
  }

  const logPath = build.logPath;
  if (!fs.existsSync(logPath)) {
    return res.status(404).json({ error: 'File log tidak ditemukan' });
  }

  const log = fs.readFileSync(logPath, 'utf8');
  res.json({ log });
});

// HISTORY
app.get('/history', authMiddleware, (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const sortedBuilds = builds.slice().reverse();
  
  res.render('history', {
    user: req.session.user,
    builds: sortedBuilds
  });
});

// DOWNLOAD APK
app.get('/download/apk/:id', authMiddleware, (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const build = builds.find(b => b.id === req.params.id);

  if (!build || build.status !== 'success' || !build.apkPath) {
    return res.status(404).json({ error: 'APK tidak ditemukan' });
  }

  const apkPath = build.apkPath;
  if (!fs.existsSync(apkPath)) {
    return res.status(404).json({ error: 'File APK tidak ditemukan' });
  }

  res.download(apkPath, `${build.projectName}.apk`);
});

// DOWNLOAD LOG
app.get('/download/log/:id', authMiddleware, (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const build = builds.find(b => b.id === req.params.id);

  if (!build || !build.logPath) {
    return res.status(404).json({ error: 'Log tidak ditemukan' });
  }

  const logPath = build.logPath;
  if (!fs.existsSync(logPath)) {
    return res.status(404).json({ error: 'File log tidak ditemukan' });
  }

  res.download(logPath, `build-${build.id}.log`);
});

// DELETE BUILD
app.post('/delete-build/:id', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const index = builds.findIndex(b => b.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({ error: 'Build tidak ditemukan' });
  }

  const build = builds[index];
  
  if (build.apkPath && fs.existsSync(build.apkPath)) {
    await fs.remove(build.apkPath);
  }
  if (build.logPath && fs.existsSync(build.logPath)) {
    await fs.remove(build.logPath);
  }
  
  const projectPath = path.join(__dirname, 'projects', build.id);
  if (fs.existsSync(projectPath)) {
    await fs.remove(projectPath);
  }

  const uploadPath = path.join(__dirname, 'uploads', build.uploadedFile);
  if (fs.existsSync(uploadPath)) {
    await fs.remove(uploadPath);
  }

  builds.splice(index, 1);
  writeDB(BUILDS_FILE, builds);

  res.json({ success: true });
});

// 404 handler
app.use((req, res) => {
  res.status(404).send('Page not found');
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ AzXCrasher Builder V3 running on http://0.0.0.0:${PORT}`);
  console.log(`🔑 Login: admin / admin123`);
  console.log(`📱 Telegram notifications: ${TELEGRAM_BOT_TOKEN !== 'YOUR_BOT_TOKEN' ? 'ENABLED' : 'DISABLED (set token first)'}`);
});