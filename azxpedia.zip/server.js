require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MemoryStore = require('memorystore')(session);
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const fs = require('fs');
const fsPromises = require('fs').promises;
const archiver = require('archiver');
const FormData = require('form-data');
const cron = require('node-cron');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const RECAPTCHA_SECRET_KEY = process.env.RECAPTCHA_SECRET_KEY || '';
const RECAPTCHA_SITE_KEY = process.env.RECAPTCHA_SITE_KEY || '';
const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;

const RUMAHOTP_API_KEY = 'rk-dev-sol08R6qixrUv2MU4jfSzaLostotmwgV';
const RUMAHOTP_BASE_URL = 'https://www.rumahotp.io/api/v2';
const OTP_ADMIN_FEE = 600;

// ==================== PAKASIR CONFIG ====================
const DEFAULT_PAKASIR_API_URL = 'https://app.pakasir.com/api';
const DEFAULT_PAKASIR_PROJECT = process.env.PAKASIR_PROJECT || 'depodomain';
const DEFAULT_PAKASIR_API_KEY = process.env.PAKASIR_API_KEY || '';

// ===== TELEGRAM CHANNEL CONFIG =====
const TELEGRAM_CHANNEL_IDS = ['@aanchannell', '@aanpublic', '-1003961314465', '-1004352059364'];

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILES = {
  users: 'users.json',
  invoices: 'invoices.json',
  transactions: 'transactions.json',
  withdrawals: 'withdrawals.json',
  apiKeys: 'apikeys.json',
  settings: 'settings.json',
  stats: 'stats.json',
  otpOrders: 'otp_orders.json',
  notifications: 'notifications.json',
  events: 'events.json',
  chatMessages: 'chat_messages.json',
  userChatMessages: 'user_chat_messages.json',
  games: 'games.json' // New DB for game history
};

// ============================================
// GAME TYPES (Update)
// ============================================
const GAME_TYPES = {
  'hi-lo': {
    name: 'HI-LO',
    icon: 'fa-dice',
    description: 'Tebak angka HI (51-100) atau LO (1-50)',
    minBet: 1000,
    maxBet: 1000000,
    enabled: true,
    route: '/games/hi-lo',
    hasSettings: true
  },
  'coinflip': {
    name: 'Coin Flip',
    icon: 'fa-coins',
    description: 'Tebak HEAD (Kepala) atau TAIL (Ekor)',
    minBet: 1000,
    maxBet: 1000000,
    enabled: true,
    route: '/games/coinflip',
    hasSettings: true
  },
  'wheel': {
    name: 'Wheel of Fortune',
    icon: 'fa-circle',
    description: 'Putar roda keberuntungan',
    minBet: 2000,
    maxBet: 2000000,
    enabled: false,
    route: '/games/wheel',
    hasSettings: false
  },
  'dice': {
    name: 'Dice Roll',
    icon: 'fa-cubes',
    description: 'Lempar dadu dan tebak hasilnya',
    minBet: 1000,
    maxBet: 500000,
    enabled: false,
    route: '/games/dice',
    hasSettings: false
  },
  'crash': {
    name: 'Crash Game',
    icon: 'fa-rocket',
    description: 'Cashout sebelum crash!',
    minBet: 5000,
    maxBet: 5000000,
    enabled: false,
    route: '/games/crash',
    hasSettings: false
  }
};

// ============================================
// DEFAULT GAME CONFIG (Update)
// ============================================
const DEFAULT_GAME_CONFIG = {
  // HI-LO Settings
  hiLo: {
    enabled: true,
    minBet: 1000,
    maxBet: 1000000,
    winRate: 75,
    maxWinMultiplier: 2,
    cooldown: 10,
    jackpotThreshold: 50000,
    houseEdge: 5
  },
  // Coin Flip Settings
  coinflip: {
    enabled: true,
    minBet: 1000,
    maxBet: 1000000,
    winRate: 75,
    maxWinMultiplier: 1.95,
    cooldown: 5,
    jackpotThreshold: 50000,
    houseEdge: 5
  }
};

// ============================================
// COIN FLIP FUNCTIONS
// ============================================

// Generate coin flip result dengan win rate
function generateCoinFlipResult(winRate) {
  const random = Math.random() * 100;
  const isWin = random <= winRate;
  // 0 = TAIL, 1 = HEAD
  const coin = Math.random() < 0.5 ? 'HEAD' : 'TAIL';
  return {
    coin: coin,
    isWin: isWin,
    winRate: winRate
  };
}

// ============================================
// GAME FUNCTIONS
// ============================================

// Generate angka random dengan win rate
function generateGameResult(winRate) {
  const random = Math.random() * 100;
  const isWin = random <= winRate;
  const number = Math.floor(Math.random() * 100) + 1;
  const result = number >= 51 ? 'HI' : 'LO';
  return { number, result, isWin, winRate };
}

// Calculate payout
function calculatePayout(bet, isWin, multiplier = 2) {
  if (!isWin) return 0;
  return bet * multiplier;
}

// Save game history
async function saveGameHistory(userId, gameData) {
  const games = await readDB('games');
  games.push({
    _id: generateCustomId('GAME'),
    userId: userId,
    ...gameData,
    createdAt: new Date()
  });
  await writeDB('games', games);
  return true;
}

async function getGameHistory(userId, limit = 20) {
  const games = await readDB('games');
  const userGames = games.filter(g => g.userId === userId);
  return userGames.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
}

async function getGameStats() {
  const games = await readDB('games');
  const totalGames = games.length;
  const totalWins = games.filter(g => g.isWin).length;
  const totalBets = games.reduce((sum, g) => sum + (g.bet || 0), 0);
  const totalPayouts = games.reduce((sum, g) => sum + (g.winAmount || 0), 0);
  const houseProfit = totalBets - totalPayouts;
  
  return {
    totalGames,
    totalWins,
    totalLosses: totalGames - totalWins,
    winRate: totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0,
    totalBets,
    totalPayouts,
    houseProfit,
    houseEdge: totalBets > 0 ? Math.round((houseProfit / totalBets) * 100) : 0
  };
}

// ============================================
// AI CS CONFIG - SIPUTZX API (FREE)
// ============================================
const AI_API_URL = 'https://api.siputzx.my.id/api/ai/gptoss120b';

// System Prompt untuk CS Admin
const CS_SYSTEM_PROMPT = `Kamu adalah Customer Service dari AzxPedia, platform payment gateway Indonesia.

Aturan:
1. Bersikap profesional, sopan, dan ramah
2. Gunakan bahasa Indonesia yang baik dan benar
3. Jawaban singkat, padat, dan jelas (maksimal 3-4 kalimat)
4. Jangan menjawab pertanyaan di luar topik layanan
5. Jika ditanya tentang teknis di luar layanan, arahkan ke admin

Informasi Layanan:
- Nama: AzxPedia
- Layanan: Deposit QRIS, Withdraw Saldo, OTP, Payment Gateway
- Metode Pembayaran: QRIS Pakasir
- Deposit minimal: Rp 1.000
- Withdraw minimal: Rp 5.000
- Fee withdraw: Rp 1.000
- Proses deposit: 5-10 menit (otomatis)
- Proses withdraw: 10-20 menit (manual admin)
- Saldo akan otomatis bertambah setelah pembayaran terdeteksi

Jam Operasional: 24/7 (respon cepat 08:00-22:00 WIB)

Kontak Darurat:
- WhatsApp: 08988106426
- Telegram: @AanzCuyxzzz

Jika user marah/mengeluh: tetap tenang, minta maaf, dan tawarkan solusi.
Jika user menanyakan hal di luar layanan: katakan "Maaf, saya hanya bisa membantu pertanyaan seputar layanan AzxPedia. Untuk pertanyaan lain, silakan hubungi admin kami di WhatsApp 08988106426."`;

// Fungsi AI Response dengan API Siputzx
async function getAIResponse(userMessage, chatHistory = []) {
  try {
    const settings = await getSettings();
    
    if (settings.aiEnabled === false) {
      return null;
    }

    let chatContext = '';
    if (chatHistory && chatHistory.length > 0) {
      const recentHistory = chatHistory.slice(-5);
      chatContext = recentHistory.map(msg => {
        const sender = msg.userId === 'admin' ? 'CS' : 'User';
        return `${sender}: ${msg.message}`;
      }).join('\n');
    }

    let prompt = userMessage;
    if (chatContext) {
      prompt = `Riwayat chat:\n${chatContext}\n\nUser: ${userMessage}`;
    }

    const response = await axios.get(AI_API_URL, {
      params: {
        prompt: prompt,
        system: CS_SYSTEM_PROMPT,
        temperature: 0.7
      },
      timeout: 30000
    });

    console.log('[AI] Response status:', response.status);
    
    if (response.data && response.data.status === true && response.data.data) {
      return response.data.data.response || 'Maaf, saya tidak bisa menjawab pertanyaan itu. Silakan hubungi admin di WhatsApp 08988106426.';
    } else {
      console.log('[AI] Response error:', response.data);
      return 'Maaf, AI sedang sibuk. Silakan hubungi admin di WhatsApp 08988106426.';
    }
  } catch (error) {
    console.error('[AI] Error:', error.message);
    if (error.code === 'ECONNABORTED') {
      return 'Maaf, koneksi ke AI timeout. Silakan coba lagi atau hubungi admin di WhatsApp 08988106426.';
    }
    return 'Maaf, sistem AI sedang sibuk. Silakan hubungi admin langsung di WhatsApp 08988106426 atau Telegram @AanzCuyxzzz.';
  }
}

function needsHumanAgent(message) {
  const keywords = ['admin', 'manusia', 'orang', 'cs', 'customer service', 'bantuan langsung', 'telpon', 'telepon', 'wa', 'whatsapp', 'telegram', 'hubungi', 'call', 'chat langsung', 'live chat', 'agent', 'orang'];
  return keywords.some(kw => message.toLowerCase().includes(kw));
}

// ============================================
// DATABASE FUNCTIONS
// ============================================
async function getEvents() {
  const events = await readDB('events');
  return events.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function getActiveEvent() {
  const events = await readDB('events');
  const now = new Date();
  const activeEvent = events.find(e => e.isActive === true && new Date(e.expiredAt) > now);
  return activeEvent || null;
}

async function saveEvent(eventData) {
  const events = await readDB('events');
  events.push(eventData);
  await writeDB('events', events);
  return eventData;
}

async function updateEvent(eventId, updateData) {
  const events = await readDB('events');
  const index = events.findIndex(e => e._id === eventId);
  if (index !== -1) {
    Object.assign(events[index], updateData);
    await writeDB('events', events);
    return true;
  }
  return false;
}

async function deleteEvent(eventId) {
  const events = await readDB('events');
  const filtered = events.filter(e => e._id !== eventId);
  await writeDB('events', filtered);
  return true;
}

async function hasUserClaimedEvent(userId, eventId) {
  const events = await readDB('events');
  const event = events.find(e => e._id === eventId);
  return event?.claimedBy?.includes(userId) || false;
}

async function addUserToEventClaimed(eventId, userId) {
  const events = await readDB('events');
  const index = events.findIndex(e => e._id === eventId);
  if (index !== -1) {
    if (!events[index].claimedBy) events[index].claimedBy = [];
    if (!events[index].claimedBy.includes(userId)) {
      events[index].claimedBy.push(userId);
      await writeDB('events', events);
      return true;
    }
  }
  return false;
}

function deduplicateMessages(messages) {
  if (!Array.isArray(messages) || messages.length === 0) return messages || [];
  const seen = new Set();
  return messages.filter(msg => {
    if (!msg || !msg._id) return false;
    if (seen.has(msg._id)) return false;
    seen.add(msg._id);
    return true;
  });
}

async function getChatMessages(limit = 50) {
  const messages = await readDB('chatMessages');
  if (!messages || !Array.isArray(messages)) return [];
  const sorted = messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const limited = sorted.slice(0, limit);
  return deduplicateMessages(limited.reverse());
}

async function saveChatMessage(messageData) {
  const messages = await readDB('chatMessages');
  if (!messages || !Array.isArray(messages)) {
    await writeDB('chatMessages', []);
    return saveChatMessage(messageData);
  }
  const exists = messages.some(m => m._id === messageData._id);
  if (exists) {
    return messageData;
  }
  messages.push(messageData);
  if (messages.length > 500) {
    const sorted = messages.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    const trimmed = sorted.slice(-500);
    await writeDB('chatMessages', trimmed);
  } else {
    await writeDB('chatMessages', messages);
  }
  return messageData;
}

async function deleteChatMessage(messageId) {
  const messages = await readDB('chatMessages');
  const filtered = messages.filter(m => m._id !== messageId);
  await writeDB('chatMessages', filtered);
  return true;
}

async function deleteAllChatMessages() {
  await writeDB('chatMessages', []);
  return true;
}

async function getChatSettings() {
  const settings = await getSettings();
  return {
    chatMode: settings.chatMode || 'admin',
    blockedUsers: settings.blockedUsers || []
  };
}

async function updateChatSettings(mode, blockedUsers) {
  const settings = await getSettings();
  settings.chatMode = mode;
  settings.blockedUsers = blockedUsers;
  await updateById('settings', settings._id, { $set: settings });
}

async function markManyUserChatRead(messageIds, readerId) {
  if (!messageIds || !Array.isArray(messageIds) || messageIds.length === 0) {
    return 0;
  }
  try {
    const messages = await readDB('userChatMessages');
    if (!messages || !Array.isArray(messages)) return 0;
    let updatedCount = 0;
    const idSet = new Set(messageIds);
    const updatedMessages = messages.map(msg => {
      if (idSet.has(msg._id)) {
        if (!msg.readBy) msg.readBy = [];
        if (!msg.readBy.includes(readerId)) {
          updatedCount++;
          return { ...msg, readBy: [...msg.readBy, readerId] };
        }
      }
      return msg;
    });
    if (updatedCount > 0) {
      await writeDB('userChatMessages', updatedMessages);
    }
    return updatedCount;
  } catch (error) {
    console.error('Error markManyUserChatRead:', error);
    return 0;
  }
}

async function markUserChatRead(messageId, userId) {
  return markManyUserChatRead([messageId], userId);
}

async function getUserChatMessages(userId = null, limit = 100) {
  try {
    const messages = await readDB('userChatMessages');
    if (!messages || !Array.isArray(messages)) return [];
    let filtered = messages;
    if (userId) {
      filtered = messages.filter(m => 
        m.userId === userId || 
        m.targetUserId === userId ||
        (m.userId === 'admin' && m.targetUserId === userId)
      );
    }
    const sorted = filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const limited = sorted.slice(0, limit);
    const result = limited.reverse();
    return deduplicateMessages(result);
  } catch (error) {
    console.error('Error getUserChatMessages:', error);
    return [];
  }
}

async function saveUserChatMessage(messageData) {
  try {
    const messages = await readDB('userChatMessages');
    if (!messages || !Array.isArray(messages)) {
      await writeDB('userChatMessages', []);
      return saveUserChatMessage(messageData);
    }
    const exists = messages.some(m => m._id === messageData._id);
    if (exists) {
      return messageData;
    }
    messages.push(messageData);
    if (messages.length > 2000) {
      const sorted = messages.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
      const trimmed = sorted.slice(-2000);
      await writeDB('userChatMessages', trimmed);
    } else {
      await writeDB('userChatMessages', messages);
    }
    return messageData;
  } catch (error) {
    console.error('Error saveUserChatMessage:', error);
    throw error;
  }
}

async function getUnreadChatCount(userId) {
  try {
    const messages = await readDB('userChatMessages');
    if (!messages || !Array.isArray(messages)) return 0;
    return messages.filter(m => 
      ((m.targetUserId === userId || m.userId === userId) && 
       (!m.readBy || !m.readBy.includes(userId)) &&
       m.userId !== userId)
    ).length;
  } catch (error) {
    console.error('Error getUnreadChatCount:', error);
    return 0;
  }
}

async function getChatList() {
  try {
    const messages = await readDB('userChatMessages');
    const users = await readDB('users');
    if (!messages || !Array.isArray(messages)) return [];
    if (!users || !Array.isArray(users)) return [];
    const userMap = {};
    users.forEach(u => {
      if (u && u._id) {
        userMap[u._id] = u;
      }
    });
    const chatGroups = {};
    messages.forEach(msg => {
      let userId = null;
      if (msg.userId && msg.userId !== 'admin') {
        userId = msg.userId;
      } else if (msg.targetUserId && msg.targetUserId !== 'admin') {
        userId = msg.targetUserId;
      }
      if (userId) {
        if (!chatGroups[userId]) {
          chatGroups[userId] = [];
        }
        chatGroups[userId].push(msg);
      }
    });
    const chatList = [];
    for (const [userId, userMessages] of Object.entries(chatGroups)) {
      const sorted = userMessages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      const lastMessage = sorted[0] || null;
      const unread = userMessages.filter(msg => 
        msg.userId === userId && 
        (!msg.readBy || !msg.readBy.includes('admin'))
      ).length;
      const user = userMap[userId];
      const username = user ? user.username : 'Unknown User';
      const email = user ? user.email : '';
      chatList.push({
        userId: userId,
        username: username,
        email: email,
        lastMessage: lastMessage ? {
          message: lastMessage.message,
          createdAt: lastMessage.createdAt,
          sender: lastMessage.userId === 'admin' ? 'admin' : 'user'
        } : null,
        lastMessageTime: lastMessage ? lastMessage.createdAt : null,
        unreadCount: unread
      });
    }
    chatList.sort((a, b) => {
      const dateA = a.lastMessageTime ? new Date(a.lastMessageTime) : new Date(0);
      const dateB = b.lastMessageTime ? new Date(b.lastMessageTime) : new Date(0);
      return dateB - dateA;
    });
    return chatList;
  } catch (error) {
    console.error('Error getChatList:', error);
    return [];
  }
}

async function deleteChatMessageById(messageId, userId, isAdmin = false) {
  try {
    const messages = await readDB('userChatMessages');
    if (!messages || !Array.isArray(messages)) return false;
    const msg = messages.find(m => m._id === messageId);
    if (!msg) return false;
    if (!isAdmin && msg.userId !== userId) {
      return false;
    }
    const filtered = messages.filter(m => m._id !== messageId);
    await writeDB('userChatMessages', filtered);
    return true;
  } catch (error) {
    console.error('Error deleteChatMessageById:', error);
    return false;
  }
}

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

for (const [key, filename] of Object.entries(DB_FILES)) {
  const filepath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filepath)) {
    fs.writeFileSync(filepath, JSON.stringify([], null, 2));
  }
}

async function readDB(collection) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    const data = await fsPromises.readFile(filepath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${collection}:`, error);
    return [];
  }
}

async function writeDB(collection, data) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    await fsPromises.writeFile(filepath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Error writing ${collection}:`, error);
    return false;
  }
}

async function findOne(collection, query) {
  const data = await readDB(collection);
  return data.find(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  });
}

async function find(collection, query = {}) {
  const data = await readDB(collection);
  if (Object.keys(query).length === 0) return data;
  return data.filter(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  });
}

async function findById(collection, id) {
  const data = await readDB(collection);
  return data.find(item => item._id === id);
}

async function insertOne(collection, document) {
  const data = await readDB(collection);
  data.push(document);
  await writeDB(collection, data);
  return document;
}

async function updateOne(collection, query, update, options = {}) {
  const data = await readDB(collection);
  let updated = false;
  for (let i = 0; i < data.length; i++) {
    let match = true;
    for (const [key, value] of Object.entries(query)) {
      if (data[i][key] !== value) {
        match = false;
        break;
      }
    }
    if (match) {
      if (update.$set) {
        Object.assign(data[i], update.$set);
      }
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      updated = true;
      break;
    }
  }
  if (updated || options.upsert) {
    await writeDB(collection, data);
    return { modifiedCount: updated ? 1 : 0 };
  }
  return { modifiedCount: 0 };
}

async function updateById(collection, id, update) {
  const data = await readDB(collection);
  for (let i = 0; i < data.length; i++) {
    if (data[i]._id === id) {
      if (update.$set) {
        Object.assign(data[i], update.$set);
      }
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      await writeDB(collection, data);
      return true;
    }
  }
  return false;
}

async function deleteOne(collection, query) {
  const data = await readDB(collection);
  let deleted = false;
  for (let i = 0; i < data.length; i++) {
    let match = true;
    for (const [key, value] of Object.entries(query)) {
      if (data[i][key] !== value) {
        match = false;
        break;
      }
    }
    if (match) {
      data.splice(i, 1);
      deleted = true;
      break;
    }
  }
  if (deleted) {
    await writeDB(collection, data);
    return { deletedCount: 1 };
  }
  return { deletedCount: 0 };
}

async function deleteMany(collection, query) {
  const data = await readDB(collection);
  let deletedCount = 0;
  if (Object.keys(query).length === 0) {
    deletedCount = data.length;
    await writeDB(collection, []);
  } else {
    for (let i = data.length - 1; i >= 0; i--) {
      let match = true;
      for (const [key, value] of Object.entries(query)) {
        if (data[i][key] !== value) {
          match = false;
          break;
        }
      }
      if (match) {
        data.splice(i, 1);
        deletedCount++;
      }
    }
    await writeDB(collection, data);
  }
  return { deletedCount };
}

async function countDocuments(collection, query = {}) {
  const data = await readDB(collection);
  if (Object.keys(query).length === 0) return data.length;
  return data.filter(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  }).length;
}

async function getNotifications(userId = null) {
  const notifs = await readDB('notifications');
  if (userId) {
    return notifs.filter(n => n.userId === userId || n.target === 'all').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return notifs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveNotification(notifData) {
  const notifs = await readDB('notifications');
  notifs.push(notifData);
  await writeDB('notifications', notifs);
  return notifData;
}

async function updateNotification(notifId, updateData) {
  const notifs = await readDB('notifications');
  const index = notifs.findIndex(n => n._id === notifId);
  if (index !== -1) {
    Object.assign(notifs[index], updateData);
    await writeDB('notifications', notifs);
    return true;
  }
  return false;
}

async function deleteNotification(notifId) {
  const notifs = await readDB('notifications');
  const filtered = notifs.filter(n => n._id !== notifId);
  await writeDB('notifications', filtered);
  return true;
}

async function markNotificationAsSeen(notifId, userId) {
  const notifs = await readDB('notifications');
  const index = notifs.findIndex(n => n._id === notifId);
  if (index !== -1) {
    if (!notifs[index].seenBy) notifs[index].seenBy = [];
    if (!notifs[index].seenBy.includes(userId)) {
      notifs[index].seenBy.push(userId);
      await writeDB('notifications', notifs);
    }
    return true;
  }
  return false;
}

async function getOTPOrders(userId = null) {
  const orders = await readDB('otpOrders');
  if (userId) {
    return orders.filter(o => o.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveOTPOrder(orderData) {
  const orders = await readDB('otpOrders');
  orders.push(orderData);
  await writeDB('otpOrders', orders);
  return orderData;
}

async function updateOTPOrder(orderId, updateData) {
  const orders = await readDB('otpOrders');
  const index = orders.findIndex(o => o._id === orderId);
  if (index !== -1) {
    Object.assign(orders[index], updateData);
    await writeDB('otpOrders', orders);
    return true;
  }
  return false;
}

// ==================== PAKASIR FUNCTIONS ====================
async function createPakasirQRIS(amount, orderId) {
  try {
    const settings = await getSettings();
    const project = settings.pakasirProject || DEFAULT_PAKASIR_PROJECT;
    const apiKey = settings.pakasirApiKey || DEFAULT_PAKASIR_API_KEY;
    
    if (!apiKey) {
      return { 
        success: false, 
        error: 'API Key Pakasir belum dikonfigurasi di Admin Settings' 
      };
    }
    
    console.log(`[PAKASIR] Creating QRIS for amount: ${amount}, order_id: ${orderId}`);
    
    const url = `${DEFAULT_PAKASIR_API_URL}/transactioncreate/qris`;
    
    const payload = {
      project: project,
      order_id: orderId,
      amount: amount,
      api_key: apiKey
    };
    
    console.log('[PAKASIR] Request payload:', JSON.stringify(payload));
    
    const response = await axios.post(url, payload, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });
    
    console.log('[PAKASIR] Response status:', response.status);
    
    if (response.data && response.data.payment) {
      const payment = response.data.payment;
      return {
        success: true,
        image_url: '',
        qr_string: payment.payment_number || '',
        trxid: payment.order_id || orderId,
        expired: payment.expired_at || new Date(Date.now() + 10 * 60000).toISOString(),
        nominal: payment.amount || amount,
        total_payment: payment.total_payment || amount,
        fee: payment.fee || 0,
        payment_method: payment.payment_method || 'qris',
        payment_number: payment.payment_number || '',
        raw: payment
      };
    } else {
      return { 
        success: false, 
        error: response.data?.message || 'Gagal membuat Qris Payment' 
      };
    }
  } catch (error) {
    console.error('[PAKASIR] Create QRIS error:', error.response?.data || error.message);
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
}

async function checkPakasirTransaction(orderId, amount) {
  try {
    const settings = await getSettings();
    const project = settings.pakasirProject || DEFAULT_PAKASIR_PROJECT;
    const apiKey = settings.pakasirApiKey || DEFAULT_PAKASIR_API_KEY;
    
    if (!apiKey) {
      return { 
        success: false, 
        data: null, 
        error: 'API Key Pakasir belum dikonfigurasi' 
      };
    }
    
    const url = `${DEFAULT_PAKASIR_API_URL}/transactiondetail?project=${project}&amount=${amount}&order_id=${orderId}&api_key=${apiKey}`;
    
    console.log('[PAKASIR] Checking transaction:', orderId);
    
    const response = await axios.get(url, { timeout: 30000 });
    
    console.log('[PAKASIR] Check response status:', response.status);
    
    if (response.data && response.data.transaction) {
      return {
        success: true,
        data: response.data.transaction
      };
    } else {
      return { 
        success: false, 
        data: null, 
        error: response.data?.message || 'Gagal cek transaksi Pakasir' 
      };
    }
  } catch (error) {
    console.error('[PAKASIR] Check transaction error:', error.response?.data || error.message);
    return { success: false, data: null, error: error.message };
  }
}

async function cancelPakasirTransaction(orderId, amount) {
  try {
    const settings = await getSettings();
    const project = settings.pakasirProject || DEFAULT_PAKASIR_PROJECT;
    const apiKey = settings.pakasirApiKey || DEFAULT_PAKASIR_API_KEY;
    
    if (!apiKey) {
      return { 
        success: false, 
        error: 'API Key Pakasir belum dikonfigurasi' 
      };
    }
    
    const url = `${DEFAULT_PAKASIR_API_URL}/transactioncancel`;
    
    const payload = {
      project: project,
      order_id: orderId,
      amount: amount,
      api_key: apiKey
    };
    
    console.log('[PAKASIR] Cancelling transaction:', orderId);
    
    const response = await axios.post(url, payload, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });
    
    return {
      success: response.data?.success || false,
      data: response.data
    };
  } catch (error) {
    console.error('[PAKASIR] Cancel transaction error:', error.response?.data || error.message);
    return { success: false, error: error.message };
  }
}

async function getRumahOTPBalance() {
  try {
    console.log('[DEBUG] Fetching RumahOTP balance...');
    const response = await axios.get('https://www.rumahotp.io/api/v1/user/balance', {
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Balance response:', response.data);
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get balance failed:', error.response?.data || error.message);
    return { success: false, error: error.response?.data?.error?.message || error.message };
  }
}

async function getRumahOTPServices() {
  try {
    console.log('[DEBUG] Fetching services from RumahOTP...');
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/services`, {
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Services response status:', response.status);
    console.log('[DEBUG] Services success:', response.data.success);
    if (response.data.data) {
      console.log('[DEBUG] Services count:', response.data.data.length);
    }
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get services failed:');
    console.error('Status:', error.response?.status);
    console.error('Message:', error.response?.data?.error?.message || error.message);
    return { success: false, data: [], error: error.response?.data?.error?.message || error.message };
  }
}

async function getRumahOTPCountries(serviceId) {
  try {
    console.log(`[DEBUG] Fetching countries for service ${serviceId}...`);
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/countries?service_id=${serviceId}`, {
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Countries response success:', response.data.success);
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get countries failed:', error.response?.data || error.message);
    return { success: false, data: [] };
  }
}

async function getRumahOTPOperators(countryName, providerId) {
  try {
    console.log(`[DEBUG] Fetching operators for ${countryName} with provider ${providerId}...`);
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/operators?country=${encodeURIComponent(countryName)}&provider_id=${providerId}`, {
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Operators response success:', response.data.success);
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get operators failed:', error.response?.data || error.message);
    return { success: false, data: [] };
  }
}

async function orderRumahOTPNumber(numberId, providerId, operatorId) {
  try {
    console.log(`[DEBUG] Ordering number - numberId:${numberId}, providerId:${providerId}, operatorId:${operatorId}`);
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/orders`, {
      params: {
        number_id: parseInt(numberId),
        provider_id: parseInt(providerId),
        operator_id: parseInt(operatorId)
      },
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Order response status:', response.status);
    console.log('[DEBUG] Order response data:', JSON.stringify(response.data).substring(0, 200));
    return response.data;
  } catch (error) {
    console.error('[ERROR] Order number failed:');
    console.error('Status:', error.response?.status);
    console.error('Message:', error.response?.data?.error?.message || error.message);
    return { success: false, error: error.response?.data?.error?.message || 'Gagal memesan nomor' };
  }
}

async function checkRumahOTPStatus(orderId) {
  try {
    console.log(`[DEBUG] Checking status for order ${orderId}...`);
    const response = await axios.get(`https://www.rumahotp.io/api/v1/orders/get_status`, {
      params: { order_id: orderId },
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Status response success:', response.data.success);
    if (response.data.data) {
      console.log('[DEBUG] Order status:', response.data.data.status);
      if (response.data.data.otp_code) {
        console.log('[DEBUG] OTP Code found:', response.data.data.otp_code);
      }
    }
    return response.data;
  } catch (error) {
    console.error('[ERROR] Check status failed:', error.response?.data || error.message);
    return { success: false };
  }
}

async function cancelRumahOTPOrder(orderId) {
  try {
    console.log(`[DEBUG] Cancelling order ${orderId}...`);
    const response = await axios.get(`https://www.rumahotp.io/api/v1/orders/set_status`, {
      params: { order_id: orderId, status: 'cancel' },
      headers: {
        'x-apikey': RUMAHOTP_API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('[DEBUG] Cancel response success:', response.data.success);
    return response.data;
  } catch (error) {
    console.error('[ERROR] Cancel order failed:', error.response?.data || error.message);
    return { success: false };
  }
}

async function verifyRecaptcha(recaptchaResponse) {
  if (!recaptchaResponse) return false;
  try {
    const response = await axios.post('https://www.google.com/recaptcha/api/siteverify', null, {
      params: {
        secret: RECAPTCHA_SECRET_KEY,
        response: recaptchaResponse
      }
    });
    return response.data.success === true;
  } catch (error) {
    console.error('reCAPTCHA verification error:', error.message);
    return false;
  }
}

const startId = {
  apikey: 'AZX',
  invoice: 'INV',
  withdraw: 'WD',
  transaction: 'TRX',
  otp: 'OTP',
  event: 'EVT',
  chat: 'CHT',
  uchat: 'UCHT',
  game: 'GAME'
};

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  store: new MemoryStore({ checkPeriod: 86400000 }),
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const Limiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 15,
  handler: (req, res) => {
    req.session.errorMsg = 'Terlalu banyak percobaan login. Silakan coba lagi setelah 5 menit.';
    res.redirect('/login');
  }
});

function generateCustomId(prefix) {
  const len = 10 - prefix.length;
  const randomHex = crypto.randomBytes(Math.ceil(len / 2)).toString('hex').substring(0, len);
  return prefix + randomHex;
}

function generateApiKey() {
  return startId.apikey + '_' + crypto.randomUUID().replace(/-/g, '').substring(0, 16);
}

async function createWithRetry(collection, data, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      if (!data._id) {
        if (collection === 'invoices') data._id = generateCustomId(startId.invoice);
        else if (collection === 'transactions') data._id = generateCustomId(startId.transaction);
        else if (collection === 'withdrawals') data._id = generateCustomId(startId.withdraw);
        else if (collection === 'apiKeys') data._id = generateCustomId(startId.apikey);
        else if (collection === 'otpOrders') data._id = generateCustomId(startId.otp);
        else if (collection === 'games') data._id = generateCustomId(startId.game);
      }
      
      if (collection === 'apiKeys' && !data.key) {
        data.key = generateApiKey();
      }
      
      const existing = await findOne(collection, { _id: data._id });
      if (existing) {
        if (collection === 'invoices') data._id = generateCustomId(startId.invoice);
        else if (collection === 'transactions') data._id = generateCustomId(startId.transaction);
        else if (collection === 'withdrawals') data._id = generateCustomId(startId.withdraw);
        else if (collection === 'apiKeys') {
          data._id = generateCustomId(startId.apikey);
          data.key = generateApiKey();
        }
        else if (collection === 'otpOrders') data._id = generateCustomId(startId.otp);
        else if (collection === 'games') data._id = generateCustomId(startId.game);
        continue;
      }
      return await insertOne(collection, data);
    } catch (err) {
      if (attempt < maxRetries - 1) continue;
      throw err;
    }
  }
  throw new Error('Gagal membuat dokumen setelah beberapa kali percobaan');
}

async function getSettings() {
  let settings = await findOne('settings', {});
  if (!settings) {
    settings = {
      _id: 'settings_1',
      name: 'AzxPedia',
      title: 'Layanan Payment Gateway',
      description: 'Terima pembayaran melalui QRIS Payment untuk Aplikasi atau Platform Bisnis kamu dengan mudah, cepat, dan aman.',
      channelWhatsApp: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
      minDeposit: 1000,
      minWithdraw: 5000,
      feeWithdraw: 1000,
      feeDeposit: 0,
      maxFee: 500,
      checkInterval: 20,
      autoCheckEnabled: true,
      autoBackupEnabled: false,
      autoRestartEnabled: false,
      backupType: 'database',
      backupInterval: 5,
      restartTime: '03:00',
      backupTime: '00:00',
      smtpUser: '',
      smtpPass: '',
      aiEnabled: true,
      telegramBotToken: '',
      telegramAdminChatId: '',
      logoUrl: 'https://img2.pixhost.to/images/8187/731158188_skyzo.png',
      pakasirApiUrl: DEFAULT_PAKASIR_API_URL,
      pakasirProject: DEFAULT_PAKASIR_PROJECT,
      pakasirApiKey: '',
      chatMode: 'all',
      blockedUsers: [],
      gameConfig: DEFAULT_GAME_CONFIG,
      gameTypes: GAME_TYPES
    };
    await insertOne('settings', settings);
  }
  
  // Ensure game settings exist
  if (!settings.gameConfig) {
    settings.gameConfig = DEFAULT_GAME_CONFIG;
    await updateById('settings', settings._id, { $set: settings });
  }
  
  // Ensure hiLo config exists
  if (!settings.gameConfig.hiLo) {
    settings.gameConfig.hiLo = DEFAULT_GAME_CONFIG.hiLo;
    await updateById('settings', settings._id, { $set: settings });
  }
  
  // Ensure coinflip config exists
  if (!settings.gameConfig.coinflip) {
    settings.gameConfig.coinflip = DEFAULT_GAME_CONFIG.coinflip;
    await updateById('settings', settings._id, { $set: settings });
  }
  
  // Ensure gameTypes exist
  if (!settings.gameTypes) {
    settings.gameTypes = GAME_TYPES;
    await updateById('settings', settings._id, { $set: settings });
  }
  
  // Ensure each game type exists
  const gameTypeKeys = ['hi-lo', 'coinflip', 'wheel', 'dice', 'crash'];
  let updated = false;
  for (const key of gameTypeKeys) {
    if (!settings.gameTypes[key]) {
      settings.gameTypes[key] = GAME_TYPES[key];
      updated = true;
    }
  }
  if (updated) {
    await updateById('settings', settings._id, { $set: settings });
  }
  
  return settings;
}

async function getStats() {
  const transactions = await readDB('transactions');
  
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;

  await updateOne('stats', {}, {
    $set: {
      totalDepositAmount: dAmount,
      totalDepositFee: dFee,
      totalWithdrawAmount: wAmount,
      totalWithdrawFee: wFee,
      totalUsers,
      totalTransactions
    }
  }, { upsert: true });

  return { totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions };
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex') === hash;
}

async function sendTelegramChannelMessage(text, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) {
    console.log('[TELEGRAM] Bot token tidak dikonfigurasi');
    return;
  }
  
  const results = [];
  for (const chatId of TELEGRAM_CHANNEL_IDS) {
    try {
      const payload = { 
        chat_id: chatId, 
        text: text, 
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      };
      if (replyMarkup) payload.reply_markup = replyMarkup;
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, payload);
      console.log(`[TELEGRAM] Message sent to channel: ${chatId}`);
      results.push({ chatId, success: true });
    } catch (e) {
      console.error(`[TELEGRAM] Send to ${chatId} error:`, e.response?.data || e.message);
      results.push({ chatId, success: false, error: e.message });
    }
  }
  return results;
}

async function sendTelegramChannelPhoto(photoUrl, caption, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) {
    console.log('[TELEGRAM] Bot token tidak dikonfigurasi');
    return;
  }
  
  const results = [];
  for (const chatId of TELEGRAM_CHANNEL_IDS) {
    try {
      const formData = new FormData();
      formData.append('chat_id', chatId);
      formData.append('photo', photoUrl);
      formData.append('caption', caption);
      formData.append('parse_mode', 'Markdown');
      if (replyMarkup) {
        formData.append('reply_markup', JSON.stringify(replyMarkup));
      }
      
      await axios.post(`https://api.telegram.org/bot${token}/sendPhoto`, formData, {
        headers: { ...formData.getHeaders() }
      });
      console.log(`[TELEGRAM] Photo sent to channel: ${chatId}`);
      results.push({ chatId, success: true });
    } catch (e) {
      console.error(`[TELEGRAM] Send photo to ${chatId} error:`, e.response?.data || e.message);
      results.push({ chatId, success: false, error: e.message });
    }
  }
  return results;
}

async function sendAdminNotification(event, data) {
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const token = settings.telegramBotToken;
  
  if (!token || !adminChatId) return;
  
  let message = '';
  switch (event) {
    case 'new_register':
      message = `🆕 *Pendaftaran Baru*\n\n👤 Username: ${data.username}\n📧 Email: ${data.email}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_login':
      message = `🔐 *Login Baru*\n\n👤 Username: ${data.username}\n📧 Email: ${data.email}\n🌐 IP: ${data.ip}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_deposit':
      message = `💰 *Deposit Baru*\n\n👤 User: ${data.username}\n💵 Jumlah: Rp ${data.amount.toLocaleString()}\n📝 Status: ${data.status}\n📱 Metode: ${data.method || 'Qris Payment'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'deposit_success':
      message = `✅ *Deposit Sukses*\n\n👤 User: ${data.username}\n💵 Jumlah: Rp ${data.amount.toLocaleString()}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_withdraw':
      message = `💸 *Withdraw Baru*\n\n👤 User: ${data.username}\n💵 Jumlah: Rp ${data.amount.toLocaleString()}\n📝 Status: ${data.status}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'game_jackpot':
      message = `🎉 *JACKPOT!*\n\n👤 User: ${data.username}\n🎯 Game: ${data.game}\n💰 Taruhan: Rp ${data.bet.toLocaleString()}\n🏆 Menang: Rp ${data.winAmount.toLocaleString()}\n📈 Multiplier: ${data.multiplier}x\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_otp_order':
      message = `📱 *OTP Order Baru*\n\n👤 User: ${data.username}\n📱 Layanan: ${data.service}\n🌍 Negara: ${data.country}\n📡 Operator: ${data.operator}\n💰 Harga: Rp ${data.price.toLocaleString()}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'otp_order_success':
      message = `✅ *OTP Order Sukses*\n\n👤 User: ${data.username}\n📱 Layanan: ${data.service}\n🌍 Negara: ${data.country}\n📡 Operator: ${data.operator}\n💰 Harga: Rp ${data.price.toLocaleString()}\n📱 Nomor: ${data.phoneNumber || '-'}\n🔑 Kode OTP: ${data.otpCode || '-'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'backup_success':
      message = `💾 *Backup Berhasil*\n\n📁 Tipe: ${data.type}\n📊 Ukuran: ${data.size} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'restart_success':
      message = `🔄 *Restart Server*\n\n✅ Server berhasil direstart\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_user_chat':
      message = `💬 *Pesan Baru dari User*\n\n👤 *User:* ${data.username} (${data.email})\n📝 *Isi Pesan:*\n${data.message}\n\n⏰ *Waktu:* ${data.time}\n\n🔗 Silakan login ke website untuk membalas`;
      break;
  }
  
  if (message) {
    await sendTelegramMessage(adminChatId, message);
  }
}

async function createBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_db_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', () => {
        console.log(`Backup DB berhasil: ${zipFileName}`);
        resolve({ path: zipFilePath, name: zipFileName, size: archive.pointer() });
      });
      
      archive.on('error', (err) => reject(err));
      archive.pipe(output);
      
      if (fs.existsSync(DATA_DIR)) {
        archive.directory(DATA_DIR, 'data');
      } else {
        reject(new Error('Folder data tidak ditemukan'));
      }
      
      await archive.finalize();
    } catch (error) {
      reject(error);
    }
  });
}

async function createFullBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_full_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', () => {
        console.log(`Full backup berhasil: ${zipFileName}`);
        resolve({ path: zipFilePath, name: zipFileName, size: archive.pointer() });
      });
      
      archive.on('error', (err) => reject(err));
      archive.pipe(output);
      
      archive.glob('**/*', {
        cwd: __dirname,
        ignore: [
          'node_modules/**',
          'package-lock.json',
          '.env',
          'backup_*.zip',
          'backup_db_*.zip',
          'backup_full_*.zip',
          'data/backup_*.json'
        ]
      });
      
      await archive.finalize();
    } catch (error) {
      reject(error);
    }
  });
}

async function sendBackupToTelegram(zipPath, zipName, isFull = false) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  const adminChatId = settings.telegramAdminChatId;
  
  if (!token || !adminChatId) {
    console.log('Telegram belum dikonfigurasi, backup hanya disimpan lokal');
    return false;
  }
  
  try {
    const stats = fs.statSync(zipPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    
    if (stats.size === 0) {
      console.error('File backup kosong!');
      return false;
    }
    
    if (stats.size > 50 * 1024 * 1024) {
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: adminChatId,
        text: `⚠️ *Backup terlalu besar*\n\nFile backup ${zipName} berukuran ${fileSizeMB} MB melebihi batas Telegram (50MB).\n\nSilakan download manual dari server: ${zipPath}`,
        parse_mode: 'Markdown'
      });
      return false;
    }
    
    const formData = new FormData();
    formData.append('chat_id', adminChatId);
    formData.append('document', fs.createReadStream(zipPath));
    formData.append('caption', `🗄️ *${isFull ? 'Full Backup' : 'Backup Database'}* - ${new Date().toLocaleDateString('id-ID')}\n\n📁 File: ${zipName}\n📊 Ukuran: ${fileSizeMB} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n⚠️ Simpan file ini dengan aman!`);
    
    await axios.post(`https://api.telegram.org/bot${token}/sendDocument`, formData, {
      headers: { ...formData.getHeaders() }
    });
    
    console.log(`Backup terkirim ke Telegram: ${zipName}`);
    await sendAdminNotification('backup_success', { type: isFull ? 'Full Backup' : 'Database Backup', size: fileSizeMB });
    return true;
  } catch (error) {
    console.error('Gagal kirim backup ke Telegram:', error.message);
    return false;
  }
}

async function performBackup(backupType) {
  try {
    let result;
    if (backupType === 'full') {
      const { path: zipPath, name: zipName } = await createFullBackupZip();
      await sendBackupToTelegram(zipPath, zipName, true);
      setTimeout(() => fs.unlink(zipPath, () => {}), 5000);
      result = { success: true, fileName: zipName };
    } else {
      const { path: zipPath, name: zipName } = await createBackupZip();
      await sendBackupToTelegram(zipPath, zipName, false);
      setTimeout(() => fs.unlink(zipPath, () => {}), 5000);
      result = { success: true, fileName: zipName };
    }
    return result;
  } catch (error) {
    console.error('Backup gagal:', error);
    return { success: false, error: error.message };
  }
}

let restartCronJob = null;

async function scheduleAutoRestart() {
  if (restartCronJob) {
    restartCronJob.stop();
    restartCronJob = null;
  }
  
  const settings = await getSettings();
  if (!settings.autoRestartEnabled) {
    console.log('Auto restart dimatikan');
    return;
  }
  
  const [hour, minute] = settings.restartTime.split(':');
  const cronTime = `${minute} ${hour} * * *`;
  
  restartCronJob = cron.schedule(cronTime, async () => {
    console.log(`Auto restart berjalan pada ${new Date().toLocaleString('id-ID')}`);
    await sendAdminNotification('restart_success', {});
    setTimeout(() => process.exit(0), 2000);
  });
  
  console.log(`Auto restart dijadwalkan setiap hari pukul ${settings.restartTime}`);
}

let backupIntervalId = null;

async function scheduleAutoBackup() {
  if (backupIntervalId) {
    clearInterval(backupIntervalId);
    backupIntervalId = null;
  }
  
  const settings = await getSettings();
  if (!settings.autoBackupEnabled) {
    console.log('Auto backup dimatikan');
    return;
  }
  
  const intervalMinutes = settings.backupInterval || 5;
  const intervalMs = intervalMinutes * 60 * 1000;
  
  console.log(`Auto backup dijadwalkan setiap ${intervalMinutes} menit (tipe: ${settings.backupType})`);
  
  setTimeout(async () => {
    console.log(`Auto backup pertama berjalan pada ${new Date().toLocaleString('id-ID')}`);
    await performBackup(settings.backupType);
  }, 5000);
  
  backupIntervalId = setInterval(async () => {
    console.log(`Auto backup berjalan pada ${new Date().toLocaleString('id-ID')}`);
    await performBackup(settings.backupType);
  }, intervalMs);
}

let pollingTimeout = null;
let isPollingActive = false;

async function getAdminChatId() {
  const settings = await getSettings();
  return settings.telegramAdminChatId || null;
}

async function sendTelegramMessage(chatId, text, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token || !chatId) return;
  try {
    const payload = { chat_id: chatId, text, parse_mode: 'Markdown' };
    if (replyMarkup) payload.reply_markup = replyMarkup;
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, payload);
  } catch (e) {
    console.error('Telegram sendMessage error:', e.response?.data || e.message);
  }
}

async function deleteMessage(chatId, messageId) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/deleteMessage`, {
      chat_id: chatId,
      message_id: messageId
    });
  } catch (e) {
    console.error('Telegram deleteMessage error:', e.response?.data || e.message);
  }
}

async function answerCallbackQuery(callbackQueryId, text) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
      callback_query_id: callbackQueryId,
      text,
      show_alert: false
    });
  } catch (e) {}
}

const mainMenuKeyboard = {
  inline_keyboard: [
    [{ text: '💾 Backup Database', callback_data: 'backup_db' }],
    [{ text: '📦 Backup Full', callback_data: 'backup_full' }]
  ]
};

async function handleTelegramCommand(msg) {
  const text = msg.text;
  const chatId = msg.chat.id;
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const isAdminUser = String(chatId) === String(adminChatId);
  
  if (text === '/login') {
    const welcomeText = `🤖 *${settings.name} Bot*\n\nSelamat datang!\n\nGunakan menu di bawah untuk mengakses fitur.`;
    await sendTelegramMessage(chatId, welcomeText, isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
  } else if (text === '/menu') {
    await sendTelegramMessage(chatId, '📋 *Menu Utama*', isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
  } else if (text === '/backupdb' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses backup database...*', null);
    const result = await performBackup('database');
    if (result.success) {
      await sendTelegramMessage(chatId, `✅ Backup database berhasil: ${result.fileName}`);
    } else {
      await sendTelegramMessage(chatId, `❌ Backup gagal: ${result.error}`);
    }
  } else if (text === '/backupall' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses full backup...*\n\n⏳ Mohon tunggu, proses ini mungkin memakan waktu beberapa saat.', null);
    const result = await performBackup('full');
    if (result.success) {
      await sendTelegramMessage(chatId, `✅ Full backup berhasil: ${result.fileName}`);
    } else {
      await sendTelegramMessage(chatId, `❌ Backup gagal: ${result.error}`);
    }
  }
}

async function handleCallbackQuery(cb) {
  const data = cb.data;
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const isAdminUser = String(chatId) === String(adminChatId);
  
  await answerCallbackQuery(cb.id, 'Processing...');
  
  if (data === 'backup_db' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses backup database...*\n\n⏳ Mohon tunggu.', null);
    await performBackup('database');
    await deleteMessage(chatId, messageId);
  } else if (data === 'backup_full' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses full backup...*\n\n⏳ Mohon tunggu, proses ini mungkin memakan waktu beberapa saat.', null);
    await performBackup('full');
    await deleteMessage(chatId, messageId);
  }
}

async function handleTelegramUpdate(update) {
  if (update.callback_query) {
    await handleCallbackQuery(update.callback_query);
  } else if (update.message && update.message.text) {
    await handleTelegramCommand(update.message);
  }
}

async function telegramGetUpdates(offset) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return [];
  try {
    const res = await axios.get(`https://api.telegram.org/bot${token}/getUpdates`, {
      params: { offset, timeout: 15 },
      timeout: 20000
    });
    if (res.data.ok) return res.data.result;
    return [];
  } catch (e) {
    if (e.response && e.response.status === 409) {
      console.error('Error 409 Conflict terdeteksi, menghentikan polling.');
      stopTelegramPolling();
    }
    return [];
  }
}

function stopTelegramPolling() {
  if (pollingTimeout) {
    clearTimeout(pollingTimeout);
    pollingTimeout = null;
  }
  isPollingActive = false;
}

async function ensureNoWebhook(token) {
  try {
    const infoRes = await axios.get(`https://api.telegram.org/bot${token}/getWebhookInfo`);
    if (infoRes.data.ok && infoRes.data.result.url) {
      console.log('Webhook terdeteksi, menghapus...');
      await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook`);
      console.log('Webhook dihapus.');
    }
    return true;
  } catch (e) {
    console.error('Gagal menghapus webhook:', e.message);
    return false;
  }
}

async function startTelegramPolling() {
  stopTelegramPolling();
  const settings = await getSettings();
  if (!settings.telegramBotToken) {
    console.log('Telegram bot token belum dikonfigurasi');
    return;
  }
  if (isPollingActive) {
    console.log('Polling sudah berjalan.');
    return;
  }
  const ok = await ensureNoWebhook(settings.telegramBotToken);
  if (!ok) {
    console.log('Tidak dapat memastikan webhook, polling tidak dimulai.');
    return;
  }
  isPollingActive = true;
  console.log('Polling Telegram dimulai.');
  let offset = 0;
  async function poll() {
    if (!isPollingActive) return;
    const updates = await telegramGetUpdates(offset);
    for (const update of updates) {
      offset = update.update_id + 1;
      await handleTelegramUpdate(update);
    }
    pollingTimeout = setTimeout(poll, 1000);
  }
  poll();
}

app.use(async (req, res, next) => {
  res.locals.user = null;
  if (req.session.userId) {
    try {
      res.locals.user = await findById('users', req.session.userId);
    } catch {}
  }
  res.locals.settings = await getSettings();
  res.locals.error = req.session.errorMsg || null;
  res.locals.success = req.session.successMsg || null;
  delete req.session.errorMsg;
  delete req.session.successMsg;
  next();
});

function isAuth(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}

function isAdmin(req, res, next) {
  if (req.session.userRole === 'admin') return next();
  res.redirect('/login');
}

async function seed() {
  const admin = await findOne('users', { role: 'admin' });
  if (!admin) {
    await insertOne('users', {
      _id: crypto.randomBytes(12).toString('hex'),
      username: 'aancuy2333',
      email: 'admin@gmail.com',
      password: hashPassword('aancuy2323'),
      role: 'admin',
      balance: 0,
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    });
    console.log(`Admin Account Default\nUsername: admin\nPassword: admin123`);
  }
}

// ============================================
// GAME ROUTES
// ============================================

// Game List Page
app.get('/games', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameTypes = settings.gameTypes || GAME_TYPES;
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    
    // Get game stats for user
    const userId = req.session.userId;
    const history = await getGameHistory(userId, 50);
    const stats = await getGameStats();
    const userStats = {
      totalGames: history.length,
      totalWins: history.filter(g => g.isWin).length,
      totalBets: history.reduce((sum, g) => sum + (g.bet || 0), 0),
      totalWinAmount: history.reduce((sum, g) => sum + (g.winAmount || 0), 0),
      netProfit: history.reduce((sum, g) => sum + (g.netWin || 0), 0)
    };
    
    res.render('games', {
      gameTypes: gameTypes,
      gameConfig: gameConfig,
      user: res.locals.user,
      userStats: userStats,
      stats: stats
    });
  } catch (error) {
    console.error('[GAMES] Error:', error);
    req.session.errorMsg = 'Gagal memuat halaman game';
    res.redirect('/dashboard');
  }
});

// Game Specific Route - HI-LO
app.get('/games/hi-lo', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const userId = req.session.userId;
    const history = await getGameHistory(userId, 20);
    const user = res.locals.user;
    
    res.render('games/hi-lo_game', {
      gameConfig: gameConfig,
      history: history,
      user: user,
      gameName: 'HI-LO',
      gameIcon: 'fa-dice'
    });
  } catch (error) {
    console.error('[GAME] HI-LO error:', error);
    req.session.errorMsg = 'Gagal memuat game';
    res.redirect('/games');
  }
});

// Wheel Game (Coming Soon)
app.get('/games/wheel', isAuth, async (req, res) => {
  res.render('games/wheel_game', {
    user: res.locals.user,
    gameName: 'Wheel of Fortune',
    gameIcon: 'fa-circle',
    comingSoon: true
  });
});

// Dice Game (Coming Soon)
app.get('/games/dice', isAuth, async (req, res) => {
  res.render('games/dice_game', {
    user: res.locals.user,
    gameName: 'Dice Roll',
    gameIcon: 'fa-cubes',
    comingSoon: true
  });
});

// Crash Game (Coming Soon)
app.get('/games/crash', isAuth, async (req, res) => {
  res.render('games/crash_game', {
    user: res.locals.user,
    gameName: 'Crash Game',
    gameIcon: 'fa-rocket',
    comingSoon: true
  });
});

// ============================================
// GAME API ROUTES
// ============================================

// Get game config
app.get('/api/game/config', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    res.json({
      success: true,
      config: {
        enabled: gameConfig.enabled,
        minBet: gameConfig.minBet,
        maxBet: gameConfig.maxBet,
        winRate: gameConfig.winRate,
        maxWinMultiplier: gameConfig.maxWinMultiplier,
        cooldown: gameConfig.cooldown,
        jackpotThreshold: gameConfig.jackpotThreshold
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Play HI-LO Game
app.post('/api/game/hi-lo/play', isAuth, async (req, res) => {
  try {
    const { bet, choice } = req.body;
    const userId = req.session.userId;
    const user = await findById('users', userId);
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    
    // Validasi
    if (!gameConfig.enabled) {
      return res.json({ success: false, message: 'Game sedang tidak aktif' });
    }
    
    if (!bet || isNaN(bet) || bet < gameConfig.minBet) {
      return res.json({ 
        success: false, 
        message: `Minimal taruhan Rp ${gameConfig.minBet.toLocaleString('id-ID')}` 
      });
    }
    
    if (bet > gameConfig.maxBet) {
      return res.json({ 
        success: false, 
        message: `Maksimal taruhan Rp ${gameConfig.maxBet.toLocaleString('id-ID')}` 
      });
    }
    
    if (!choice || !['HI', 'LO'].includes(choice)) {
      return res.json({ success: false, message: 'Pilih HI atau LO' });
    }
    
    if (user.balance < bet) {
      return res.json({ success: false, message: 'Saldo tidak cukup' });
    }
    
    // Cek cooldown
    const lastGame = await getGameHistory(userId, 1);
    if (lastGame.length > 0) {
      const lastTime = new Date(lastGame[0].createdAt);
      const now = new Date();
      const diff = (now.getTime() - lastTime.getTime()) / 1000;
      if (diff < (gameConfig.cooldown || 10)) {
        return res.json({ 
          success: false, 
          message: `Tunggu ${Math.ceil((gameConfig.cooldown || 10) - diff)} detik lagi` 
        });
      }
    }
    
    // Generate result
    const winRate = gameConfig.winRate || 75;
    const result = generateGameResult(winRate);
    const isWin = result.isWin && choice === result.result;
    const multiplier = gameConfig.maxWinMultiplier || 2;
    const winAmount = isWin ? calculatePayout(bet, true, multiplier) : 0;
    const netWin = winAmount - bet;
    
    // Update balance
    if (isWin) {
      user.balance += netWin;
    } else {
      user.balance -= bet;
    }
    await updateById('users', userId, { $set: user });
    
    // Save history
    const gameData = {
      gameType: 'hi-lo',
      bet: bet,
      choice: choice,
      number: result.number,
      result: result.result,
      isWin: isWin,
      winAmount: winAmount,
      netWin: netWin,
      multiplier: isWin ? multiplier : 0,
      balanceAfter: user.balance,
      winRate: winRate
    };
    await saveGameHistory(userId, gameData);
    
    // Kirim notifikasi jika jackpot
    if (isWin && winAmount >= (gameConfig.jackpotThreshold || 50000)) {
      await sendAdminNotification('game_jackpot', {
        username: user.username,
        game: 'HI-LO',
        bet: bet,
        winAmount: winAmount,
        multiplier: multiplier
      });
      
      const channelReplyMarkup = {
        inline_keyboard: [
          [{ text: '🎮 Main Lagi', url: 'https://app.azxpedia.my.id/games/hi-lo' }],
          [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
        ]
      };
      
      const photoUrl = 'https://cdn.yupra.my.id/yp/tftx606i.png';
      
      await sendTelegramChannelPhoto(
        photoUrl,
        `🎉 *JACKPOT!*\n\n` +
        `🌐 *AzxPedia*\n\n` +
        `👤 *User:* ${user.username}\n` +
        `🎯 *Game:* HI-LO\n` +
        `💰 *Taruhan:* Rp ${bet.toLocaleString()}\n` +
        `🏆 *Menang:* Rp ${winAmount.toLocaleString()}\n` +
        `📈 *Multiplier:* x${multiplier}\n` +
        `🔢 *Angka:* ${result.number} (${result.result})\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}`,
        channelReplyMarkup
      );
    }
    
    res.json({
      success: true,
      data: {
        bet: bet,
        choice: choice,
        number: result.number,
        result: result.result,
        isWin: isWin,
        winAmount: winAmount,
        netWin: netWin,
        multiplier: isWin ? multiplier : 0,
        balance: user.balance
      }
    });
    
  } catch (error) {
    console.error('[GAME] Play error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get game history API
app.get('/api/game/history', isAuth, async (req, res) => {
  try {
    const userId = req.session.userId;
    const limit = parseInt(req.query.limit) || 20;
    const history = await getGameHistory(userId, limit);
    
    const totalGames = history.length;
    const totalWins = history.filter(g => g.isWin).length;
    const totalBets = history.reduce((sum, g) => sum + (g.bet || 0), 0);
    const totalWinAmount = history.reduce((sum, g) => sum + (g.winAmount || 0), 0);
    const netProfit = totalWinAmount - totalBets;
    
    res.json({
      success: true,
      data: {
        history: history,
        stats: {
          totalGames,
          totalWins,
          totalLosses: totalGames - totalWins,
          totalBets,
          totalWinAmount,
          netProfit,
          winRate: totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// GAME ROUTES - COIN FLIP
// ============================================

// Coin Flip Game Page
app.get('/games/coinflip', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const coinflipConfig = gameConfig.coinflip || DEFAULT_GAME_CONFIG.coinflip;
    const userId = req.session.userId;
    const history = await getGameHistory(userId, 20);
    const user = res.locals.user;
    
    res.render('games/coinflip_game', {
      gameConfig: coinflipConfig,
      history: history,
      user: user,
      gameName: 'Coin Flip',
      gameIcon: 'fa-coins'
    });
  } catch (error) {
    console.error('[GAME] Coin Flip error:', error);
    req.session.errorMsg = 'Gagal memuat game';
    res.redirect('/games');
  }
});

// Play Coin Flip
app.post('/api/game/coinflip/play', isAuth, async (req, res) => {
  try {
    const { bet, choice } = req.body; // choice: 'HEAD' or 'TAIL'
    const userId = req.session.userId;
    const user = await findById('users', userId);
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const coinflipConfig = gameConfig.coinflip || DEFAULT_GAME_CONFIG.coinflip;
    
    // Validasi
    if (!coinflipConfig.enabled) {
      return res.json({ success: false, message: 'Game Coin Flip sedang tidak aktif' });
    }
    
    if (!bet || isNaN(bet) || bet < coinflipConfig.minBet) {
      return res.json({ 
        success: false, 
        message: `Minimal taruhan Rp ${coinflipConfig.minBet.toLocaleString('id-ID')}` 
      });
    }
    
    if (bet > coinflipConfig.maxBet) {
      return res.json({ 
        success: false, 
        message: `Maksimal taruhan Rp ${coinflipConfig.maxBet.toLocaleString('id-ID')}` 
      });
    }
    
    if (!choice || !['HEAD', 'TAIL'].includes(choice)) {
      return res.json({ success: false, message: 'Pilih HEAD atau TAIL' });
    }
    
    if (user.balance < bet) {
      return res.json({ success: false, message: 'Saldo tidak cukup' });
    }
    
    // Cek cooldown
    const lastGame = await getGameHistory(userId, 1);
    if (lastGame.length > 0) {
      const lastTime = new Date(lastGame[0].createdAt);
      const now = new Date();
      const diff = (now.getTime() - lastTime.getTime()) / 1000;
      if (diff < (coinflipConfig.cooldown || 5)) {
        return res.json({ 
          success: false, 
          message: `Tunggu ${Math.ceil((coinflipConfig.cooldown || 5) - diff)} detik lagi` 
        });
      }
    }
    
    // Generate result
    const winRate = coinflipConfig.winRate || 75;
    const result = generateCoinFlipResult(winRate);
    const isWin = result.isWin && choice === result.coin;
    const multiplier = coinflipConfig.maxWinMultiplier || 1.95;
    const winAmount = isWin ? Math.round(bet * multiplier) : 0;
    const netWin = winAmount - bet;
    
    // Update balance
    if (isWin) {
      user.balance += netWin;
    } else {
      user.balance -= bet;
    }
    await updateById('users', userId, { $set: user });
    
    // Save history
    const gameData = {
      gameType: 'coinflip',
      bet: bet,
      choice: choice,
      coin: result.coin,
      isWin: isWin,
      winAmount: winAmount,
      netWin: netWin,
      multiplier: isWin ? multiplier : 0,
      balanceAfter: user.balance,
      winRate: winRate
    };
    await saveGameHistory(userId, gameData);
    
    // Kirim notifikasi jika jackpot
    if (isWin && winAmount >= (coinflipConfig.jackpotThreshold || 50000)) {
      await sendAdminNotification('game_jackpot', {
        username: user.username,
        game: 'Coin Flip',
        bet: bet,
        winAmount: winAmount,
        multiplier: multiplier
      });
      
      const channelReplyMarkup = {
        inline_keyboard: [
          [{ text: '🎮 Main Lagi', url: 'https://app.azxpedia.my.id/games/coinflip' }],
          [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
        ]
      };
      
      const photoUrl = 'https://cdn.yupra.my.id/yp/tftx606i.png';
      
      await sendTelegramChannelPhoto(
        photoUrl,
        `🪙 *JACKPOT! Coin Flip*\n\n` +
        `🌐 *AzxPedia*\n\n` +
        `👤 *User:* ${user.username}\n` +
        `🪙 *Game:* Coin Flip\n` +
        `💰 *Taruhan:* Rp ${bet.toLocaleString()}\n` +
        `🏆 *Menang:* Rp ${winAmount.toLocaleString()}\n` +
        `📈 *Multiplier:* x${multiplier}\n` +
        `🪙 *Coin:* ${result.coin}\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}`,
        channelReplyMarkup
      );
    }
    
    res.json({
      success: true,
      data: {
        bet: bet,
        choice: choice,
        coin: result.coin,
        isWin: isWin,
        winAmount: winAmount,
        netWin: netWin,
        multiplier: isWin ? multiplier : 0,
        balance: user.balance
      }
    });
    
  } catch (error) {
    console.error('[COINFLIP] Play error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ADMIN GAME ROUTES
// ============================================

app.get('/admin/games', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const gameTypes = settings.gameTypes || GAME_TYPES;
    const stats = await getGameStats();
    
    // Top players
    const games = await readDB('games');
    const users = await readDB('users');
    const playerStats = {};
    games.forEach(g => {
      if (!playerStats[g.userId]) {
        playerStats[g.userId] = { wins: 0, losses: 0, totalBet: 0, totalWin: 0 };
      }
      if (g.isWin) {
        playerStats[g.userId].wins++;
        playerStats[g.userId].totalWin += g.winAmount || 0;
      } else {
        playerStats[g.userId].losses++;
      }
      playerStats[g.userId].totalBet += g.bet || 0;
    });
    
    const topPlayers = Object.keys(playerStats).map(userId => {
      const user = users.find(u => u._id === userId);
      return {
        userId: userId,
        username: user ? user.username : 'Unknown',
        ...playerStats[userId],
        netProfit: playerStats[userId].totalWin - playerStats[userId].totalBet
      };
    }).sort((a, b) => b.totalBet - a.totalBet).slice(0, 10);
    
    res.render('admin_games', {
      gameConfig: gameConfig,
      gameTypes: gameTypes,
      stats: stats,
      topPlayers: topPlayers,
      user: res.locals.user
    });
  } catch (error) {
    console.error('[ADMIN GAMES] Error:', error);
    req.session.errorMsg = 'Gagal memuat halaman game';
    res.redirect('/admin/dashboard');
  }
});

// Update game settings
app.post('/admin/games/update', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await getSettings();
    
    // HI-LO Settings
    settings.gameConfig.hiLo = {
      enabled: req.body.hiLo_enabled === 'on',
      minBet: parseInt(req.body.hiLo_minBet) || 1000,
      maxBet: parseInt(req.body.hiLo_maxBet) || 1000000,
      winRate: parseInt(req.body.hiLo_winRate) || 75,
      maxWinMultiplier: parseFloat(req.body.hiLo_maxWinMultiplier) || 2,
      cooldown: parseInt(req.body.hiLo_cooldown) || 10,
      jackpotThreshold: parseInt(req.body.hiLo_jackpotThreshold) || 50000,
      houseEdge: 5
    };
    
    // Coin Flip Settings
    settings.gameConfig.coinflip = {
      enabled: req.body.coinflip_enabled === 'on',
      minBet: parseInt(req.body.coinflip_minBet) || 1000,
      maxBet: parseInt(req.body.coinflip_maxBet) || 1000000,
      winRate: parseInt(req.body.coinflip_winRate) || 75,
      maxWinMultiplier: parseFloat(req.body.coinflip_maxWinMultiplier) || 1.95,
      cooldown: parseInt(req.body.coinflip_cooldown) || 5,
      jackpotThreshold: parseInt(req.body.coinflip_jackpotThreshold) || 50000,
      houseEdge: 5
    };
    
    await updateById('settings', settings._id, { $set: settings });
    
    req.session.successMsg = 'Pengaturan game berhasil diperbarui!';
    res.redirect('/admin/games');
  } catch (error) {
    console.error('[ADMIN GAMES] Update error:', error);
    req.session.errorMsg = 'Gagal memperbarui pengaturan game: ' + error.message;
    res.redirect('/admin/games');
  }
});

// Reset game history
app.post('/admin/games/reset', isAuth, isAdmin, async (req, res) => {
  try {
    await writeDB('games', []);
    req.session.successMsg = 'Riwayat game berhasil direset!';
  } catch (error) {
    req.session.errorMsg = 'Gagal reset riwayat game';
  }
  res.redirect('/admin/games');
});

// ============================================
// AUTH ROUTES (Existing)
// ============================================
app.get('/', (req, res) => res.render('home'));
app.get('/home', (req, res) => res.render('home'));
app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('login', { recaptchaSiteKey: RECAPTCHA_SITE_KEY, error: null, success: null });
});

app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('register', { recaptchaSiteKey: RECAPTCHA_SITE_KEY, error: null, success: null });
});

app.post('/login', Limiter, async (req, res) => {
  const { login, password, 'g-recaptcha-response': recaptchaResponse } = req.body;
  
  if (!login || !password) {
    req.session.errorMsg = 'Harap isi semua field';
    return res.redirect('/login');
  }
  
  const isHuman = await verifyRecaptcha(recaptchaResponse);
  if (!isHuman) {
    req.session.errorMsg = 'Verifikasi keamanan gagal. Silakan coba lagi.';
    return res.redirect('/login');
  }
  
  const isEmail = login.includes('@');
  let user;
  if (isEmail) {
    user = await findOne('users', { email: login.toLowerCase() });
    if (user && user.role === 'admin') {
      req.session.errorMsg = 'Admin hanya dapat login menggunakan username';
      return res.redirect('/login');
    }
  } else {
    user = await findOne('users', { username: login.toLowerCase() });
  }
  if (!user || !verifyPassword(password, user.password)) {
    req.session.errorMsg = 'Username/email atau kata sandi salah';
    return res.redirect('/login');
  }
  if (user.suspended) {
    req.session.errorMsg = 'Akun Anda dinonaktifkan';
    return res.redirect('/login');
  }
  req.session.userId = user._id;
  req.session.userRole = user.role;
  
  await sendAdminNotification('new_login', {
    username: user.username,
    email: user.email,
    ip: req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress
  });
  
  if (user.role === 'admin') return res.redirect('/admin/dashboard');
  res.redirect('/dashboard');
});

app.post('/register', Limiter, async (req, res) => {
  const { username, email, password, 'g-recaptcha-response': recaptchaResponse } = req.body;
  
  if (!username || username.trim().length === 0) {
    req.session.errorMsg = 'Username tidak boleh kosong';
    return res.redirect('/register');
  }
  if (!/^[a-zA-Z0-9]+$/.test(username)) {
    req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
    return res.redirect('/register');
  }
  if (username.length > 15) {
    req.session.errorMsg = 'Username maksimal 15 karakter';
    return res.redirect('/register');
  }
  if (!email || !email.includes('@')) {
    req.session.errorMsg = 'Email tidak valid';
    return res.redirect('/register');
  }
  if (!password || password.length < 4) {
    req.session.errorMsg = 'Password minimal 4 karakter';
    return res.redirect('/register');
  }
  
  const isHuman = await verifyRecaptcha(recaptchaResponse);
  if (!isHuman) {
    req.session.errorMsg = 'Verifikasi keamanan gagal. Silakan coba lagi.';
    return res.redirect('/register');
  }
  
  try {
    const existingUser = await findOne('users', { $or: [{ username: username.toLowerCase() }, { email: email.toLowerCase() }] });
    if (existingUser) {
      req.session.errorMsg = 'Username atau email sudah terdaftar';
      return res.redirect('/register');
    }
    
    const user = {
      _id: crypto.randomBytes(12).toString('hex'),
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      password: hashPassword(password),
      balance: 0,
      role: 'user',
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    };
    await insertOne('users', user);
    
    const apiKeyData = {
      _id: generateCustomId(startId.apikey),
      userId: user._id,
      key: generateApiKey(),
      createdAt: new Date()
    };
    await insertOne('apiKeys', apiKeyData);
    
    req.session.userId = user._id;
    req.session.userRole = 'user';
    
    await sendAdminNotification('new_register', {
      username: user.username,
      email: user.email
    });
    
    res.redirect('/dashboard');
  } catch (err) {
    console.error('Register error:', err);
    req.session.errorMsg = 'Gagal mendaftar, periksa kembali data Anda';
    res.redirect('/register');
  }
});

app.post('/check-availability', async (req, res) => {
  const { type, value } = req.body;
  if (!type || !value || !['username', 'email'].includes(type)) {
    return res.json({ available: false, message: 'Parameter tidak valid' });
  }

  if (type === 'username') {
    if (!/^[a-zA-Z0-9]{1,15}$/.test(value)) {
      return res.json({ available: false, message: 'Format username tidak valid (huruf/angka, maks 15 karakter)' });
    }
    const exists = await findOne('users', { username: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Username sudah digunakan' : 'Username tersedia' });
  }

  if (type === 'email') {
    if (!/^\S+@\S+\.\S+$/.test(value)) {
      return res.json({ available: false, message: 'Format email tidak valid' });
    }
    const exists = await findOne('users', { email: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Email sudah terdaftar' : 'Email tersedia' });
  }
});

app.get('/forgot-password', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('forgot_password');
});

app.post('/forgot-password', Limiter, async (req, res) => {
  const { login } = req.body;
  if (!login) {
    req.session.errorMsg = 'Harap masukkan email atau username Anda.';
    return res.redirect('/forgot-password');
  }
  try {
    const settings = await getSettings();
    if (!settings.smtpUser || !settings.smtpPass) {
      req.session.errorMsg = 'Fitur pengiriman email belum dikonfigurasi oleh Administrator.';
      return res.redirect('/forgot-password');
    }
    const isEmail = login.includes('@');
    let user;
    if (isEmail) {
      user = await findOne('users', { email: login.toLowerCase() });
    } else {
      user = await findOne('users', { username: login.toLowerCase() });
    }
    if (!user) {
      req.session.errorMsg = 'Akun tidak ditemukan di sistem kami.';
      return res.redirect('/forgot-password');
    }
    if (!user.email) {
      req.session.errorMsg = 'Akun ini tidak memiliki alamat email yang valid.';
      return res.redirect('/forgot-password');
    }
    const token = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 30 * 60 * 1000;
    await updateById('users', user._id, { $set: user });

    const resetLink = `http://${req.headers.host}/reset-password/${token}`;
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: settings.smtpUser,
        pass: settings.smtpPass
      },
      tls: { rejectUnauthorized: false }
    });

    await transporter.sendMail({
      to: user.email,
      from: `"${settings.name}" <${settings.smtpUser}>`,
      subject: `Permintaan Reset Password - ${settings.name}`,
      text: `Halo ${user.username},\n\nKami menerima permintaan untuk mengatur ulang kata sandi akun Anda. Silakan salin tautan berikut ke browser Anda:\n${resetLink}\n\nTautan ini hanya berlaku 30 menit.\n\nJika Anda tidak meminta ini, abaikan email ini.`,
      html: `<div>Reset password link: <a href="${resetLink}">${resetLink}</a></div>`
    });

    req.session.successMsg = `Link reset password telah dikirim ke email Anda yang terdaftar.`;
    res.redirect('/forgot-password');
  } catch (error) {
    console.error('Error Forgot Password:', error);
    req.session.errorMsg = 'Gagal memproses email. Pastikan konfigurasi SMTP di Admin valid.';
    res.redirect('/forgot-password');
  }
});

app.get('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const user = users.find(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (!user) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa (berlaku 30 menit).';
      return res.redirect('/forgot-password');
    }
    res.render('reset_password', { token: req.params.token });
  } catch (error) {
    res.redirect('/login');
  }
});

app.post('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const userIndex = users.findIndex(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (userIndex === -1) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa.';
      return res.redirect('/forgot-password');
    }
    const { password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      req.session.errorMsg = 'Password dan konfirmasi password tidak cocok.';
      return res.redirect(`/reset-password/${req.params.token}`);
    }
    users[userIndex].password = hashPassword(password);
    delete users[userIndex].resetPasswordToken;
    delete users[userIndex].resetPasswordExpires;
    await writeDB('users', users);
    req.session.successMsg = 'Password berhasil diubah. Silakan login dengan password baru.';
    res.redirect('/login');
  } catch (error) {
    req.session.errorMsg = 'Gagal mereset password.';
    res.redirect(`/reset-password/${req.params.token}`);
  }
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/login'); });

// ============================================
// DASHBOARD & OTHER ROUTES
// ============================================
app.get('/dashboard', isAuth, async (req, res) => {
  if (req.session.userRole === 'admin') return res.redirect('/admin/dashboard');
  const userId = req.session.userId;
  const user = res.locals.user || { balance: 0 };
  
  const transactions = await readDB('transactions');
  const userTransactions = transactions.filter(t => t.userId === user._id);
  const totalDeposit = userTransactions.filter(t => t.type === 'deposit' && t.status === 'paid').reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalWithdraw = userTransactions.filter(t => t.type === 'withdraw' && t.status === 'success').reduce((sum, t) => sum + (t.amount || 0), 0);
  const recentTrx = userTransactions.filter(t => t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  const apiKeys = await find('apiKeys', { userId });
  
  const allNotifications = await getNotifications();
  const activeNotifications = allNotifications.filter(n => n.isActive === true);
  
  const unreadChatCount = await getUnreadChatCount(userId);
  
  res.render('dashboard', { 
    user: user || { balance: 0, username: '', email: '' }, 
    totalDeposit: totalDeposit || 0, 
    totalWithdraw: totalWithdraw || 0, 
    recentTrx: recentTrx || [], 
    apiKeys: apiKeys || [],
    allNotifications: activeNotifications || [],
    unreadChatCount: unreadChatCount || 0
  });
});

app.get('/chat/user', isAuth, async (req, res) => {
  const userId = req.session.userId;
  const messages = await getUserChatMessages(userId, 200);
  const user = res.locals.user;
  
  const adminMessageIds = messages.filter(msg => msg.userId === 'admin').map(msg => msg._id);
  if (adminMessageIds.length > 0) {
    await markManyUserChatRead(adminMessageIds, userId);
  }
  
  res.render('user_chat', { 
    messages: messages, 
    user: user,
    unreadChatCount: 0
  });
});

app.post('/chat/user/send', isAuth, async (req, res) => {
  const { message } = req.body;
  if (!message || message.trim() === '') {
    return res.json({ success: false, message: 'Pesan tidak boleh kosong' });
  }
  
  const user = res.locals.user;
  const settings = await getSettings();
  const useAI = settings.aiEnabled !== false;
  
  const userMessage = {
    _id: generateCustomId('UCHAT'),
    userId: user._id,
    username: user.username,
    message: message.trim(),
    targetUserId: 'admin',
    role: 'user',
    readBy: [],
    createdAt: new Date()
  };
  await saveUserChatMessage(userMessage);
  
  const adminChatId = settings.telegramAdminChatId;
  if (adminChatId) {
    const timeString = new Date().toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    await sendTelegramMessage(adminChatId, 
      `💬 *Pesan Baru dari User*\n\n` +
      `👤 *User:* ${user.username} (${user.email})\n` +
      `📝 *Isi Pesan:*\n${message.trim()}\n\n` +
      `⏰ *Waktu:* ${timeString}`
    );
  }
  
  let aiResponse = null;
  if (useAI) {
    if (needsHumanAgent(message)) {
      aiResponse = 'Baik, saya akan menghubungkan Anda dengan admin. Mohon tunggu sebentar ya. Admin akan merespon secepatnya.\n\nAtau Anda juga bisa langsung menghubungi admin di:\n📱 WhatsApp: 08988106426\n✈️ Telegram: @AanzCuyxzzz';
    } else {
      try {
        const chatHistory = await getUserChatMessages(user._id, 20);
        aiResponse = await getAIResponse(message, chatHistory);
      } catch (error) {
        console.error('[AI] Reply Error:', error);
        aiResponse = null;
      }
    }
    
    if (aiResponse) {
      const aiMessage = {
        _id: generateCustomId('UCHAT'),
        userId: 'admin',
        username: '🤖 AI Assistant',
        message: aiResponse,
        targetUserId: user._id,
        role: 'admin',
        readBy: [user._id],
        isAI: true,
        aiProvider: 'siputzx',
        createdAt: new Date()
      };
      await saveUserChatMessage(aiMessage);
      
      if (adminChatId) {
        await sendTelegramMessage(adminChatId,
          `🤖 *AI Auto-Reply*\n\n` +
          `👤 *User:* ${user.username}\n` +
          `📝 *Balasan AI:*\n${aiResponse.substring(0, 300)}${aiResponse.length > 300 ? '...' : ''}`
        );
      }
      
      return res.json({ 
        success: true, 
        message: userMessage,
        aiResponse: aiMessage 
      });
    }
  }
  
  res.json({ success: true, message: userMessage });
});

app.get('/chat/user/messages', isAuth, async (req, res) => {
  const userId = req.session.userId;
  const messages = await getUserChatMessages(userId, 200);
  res.json({ success: true, messages: deduplicateMessages(messages) });
});

app.get('/admin/chat/user', isAuth, isAdmin, async (req, res) => {
  const chatList = await getChatList();
  const selectedUserId = req.query.user_id || null;
  let messages = [];
  let selectedUser = null;
  
  if (selectedUserId) {
    messages = await getUserChatMessages(selectedUserId, 200);
    selectedUser = await findById('users', selectedUserId);
    
    const userMessageIds = messages.filter(msg => msg.userId === selectedUserId).map(msg => msg._id);
    if (userMessageIds.length > 0) {
      await markManyUserChatRead(userMessageIds, 'admin');
    }
  }
  
  const uniqueMessages = deduplicateMessages(messages);
  
  res.render('admin_chat_user', { 
    chatList: chatList,
    messages: uniqueMessages, 
    selectedUserId, 
    selectedUser,
    user: res.locals.user
  });
});

app.post('/admin/chat/user/send', isAuth, isAdmin, async (req, res) => {
  const { userId, message } = req.body;
  if (!userId || !message || message.trim() === '') {
    return res.json({ success: false, message: 'Data tidak lengkap' });
  }
  
  const admin = res.locals.user;
  const targetUser = await findById('users', userId);
  if (!targetUser) {
    return res.json({ success: false, message: 'User tidak ditemukan' });
  }
  
  const newMessage = {
    _id: generateCustomId('UCHAT'),
    userId: 'admin',
    username: admin.username,
    message: message.trim(),
    targetUserId: userId,
    role: 'admin',
    readBy: [],
    createdAt: new Date()
  };
  
  await saveUserChatMessage(newMessage);
  
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  if (adminChatId) {
    const timeString = new Date().toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    await sendTelegramMessage(adminChatId, 
      `💬 *Pesan dari Admin ke User*\n\n` +
      `👤 *User:* ${targetUser.username} (${targetUser.email})\n` +
      `👨‍💼 *Admin:* ${admin.username}\n` +
      `📝 *Isi Pesan:*\n${message.trim()}\n\n` +
      `⏰ *Waktu:* ${timeString}`
    );
  }
  
  res.json({ success: true, message: newMessage });
});

app.get('/admin/chat/user/messages/:userId', isAuth, isAdmin, async (req, res) => {
  const userId = req.params.userId;
  const messages = await getUserChatMessages(userId, 200);
  
  const userMessageIds = messages.filter(msg => msg.userId === userId).map(msg => msg._id);
  if (userMessageIds.length > 0) {
    await markManyUserChatRead(userMessageIds, 'admin');
  }
  
  const uniqueMessages = deduplicateMessages(messages);
  
  res.json({ success: true, messages: uniqueMessages });
});

app.get('/admin/chat/user/list', isAuth, isAdmin, async (req, res) => {
  const chatList = await getChatList();
  res.json({ success: true, chatList });
});

app.post('/admin/chat/user/delete/:id', isAuth, isAdmin, async (req, res) => {
  const messages = await readDB('userChatMessages');
  const filtered = messages.filter(m => m._id !== req.params.id);
  await writeDB('userChatMessages', filtered);
  res.json({ success: true });
});

app.get('/profile', isAuth, (req, res) => res.render('profile'));
app.post('/profile', isAuth, async (req, res) => {
  const { email, newPassword, ewallet, accountNumber, accountName } = req.body;
  try {
    const user = await findById('users', req.session.userId);
    if (email && email !== user.email) {
      const existing = await findOne('users', { email: email.toLowerCase() });
      if (existing && existing._id !== req.session.userId) {
        req.session.errorMsg = 'Email sudah digunakan oleh pengguna lain';
        return res.redirect('/profile');
      }
      user.email = email.toLowerCase();
    }
    user.ewallet = ewallet || '';
    user.accountNumber = accountNumber || '';
    user.accountName = accountName || '';
    if (newPassword && newPassword.trim()) {
      user.password = hashPassword(newPassword);
    }
    await updateById('users', req.session.userId, { $set: user });
    req.session.successMsg = 'Profil berhasil diperbarui';
    res.redirect('/profile');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui profil';
    res.redirect('/profile');
  }
});

app.post('/api/user/api-key/regenerate', isAuth, async (req, res) => {
  await deleteMany('apiKeys', { userId: req.session.userId });
  const key = generateApiKey();
  try {
    await createWithRetry('apiKeys', { userId: req.session.userId, key, createdAt: new Date() });
    res.json({ apiKey: key });
  } catch (err) {
    res.status(500).json({ error: 'Gagal membuat API key' });
  }
});

app.get('/deposit', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const transactions = await readDB('transactions');
  const deposits = transactions.filter(t => t.userId === req.session.userId && t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const invoices = await find('invoices', { userId: req.session.userId });
  const feeDeposit = settings.feeDeposit || 0;
  res.render('deposit', { 
    deposits, 
    invoices: invoices.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), 
    minDeposit: settings.minDeposit,
    feeDeposit: feeDeposit
  });
});

app.post('/invoice/create', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const userId = req.session.userId;
  const amount = parseInt(req.body.amount);
  const feeDeposit = settings.feeDeposit || 0;
  const totalAmount = amount + feeDeposit;
  
  if (isNaN(amount) || amount < settings.minDeposit) {
    req.session.errorMsg = `Minimal deposit adalah Rp ${settings.minDeposit.toLocaleString('id-ID')}`;
    return res.redirect('/deposit');
  }
  
  try {
    const orderId = generateCustomId('PAK');
    
    const qrisResult = await createPakasirQRIS(totalAmount, orderId);
    if (!qrisResult.success) {
      throw new Error(qrisResult.error || 'Gagal membuat Qris Payment');
    }
    
    const expiredAt = new Date(qrisResult.expired || Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId,
      amount: amount,
      fee: feeDeposit,
      total: totalAmount,
      trxid: qrisResult.trxid || orderId,
      qris_image: '',
      qr_string: qrisResult.qr_string || '',
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date(),
      paymentMethod: 'Qris Payment',
      paymentProvider: 'pakasir',
      providerData: {
        order_id: orderId,
        total_payment: qrisResult.total_payment,
        fee: qrisResult.fee,
        payment_method: qrisResult.payment_method,
        raw: qrisResult.raw
      }
    });
    
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId,
      type: 'deposit',
      amount: amount,
      fee: feeDeposit,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date(),
      paymentMethod: 'Qris Payment',
      paymentProvider: 'pakasir',
      providerData: {
        order_id: orderId
      }
    });
    
    const user = await findById('users', userId);
    await sendAdminNotification('new_deposit', {
      username: user.username,
      amount: totalAmount,
      status: 'pending',
      method: 'Qris Payment'
    });
    
    const channelReplyMarkup = {
      inline_keyboard: [
        [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
      ]
    };
    
    let qrImageUrl = '';
    if (qrisResult.qr_string) {
      qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrisResult.qr_string)}`;
    }
    
    const photoUrl = 'https://cdn.yupra.my.id/yp/34qy2k2t.png';
    
    await sendTelegramChannelPhoto(
      photoUrl,
      `🌐 *AzxPedia*\n\n` + 
      `📊 *Invoice Deposit*\n` +
      `User: ${user.username}\n` +
      `ID Invoice: ${invoice._id}\n` +
      `Order ID: ${orderId}\n` +
      `Jumlah Deposit: Rp ${amount.toLocaleString()}\n` +
      `Fee Admin: Rp ${feeDeposit.toLocaleString()}\n` +
      `Total Dibayar: Rp ${totalAmount.toLocaleString()}\n` +
      `Status:⏳ Pending\n\n` +
      `_${new Date().toLocaleString('id-ID')}_`,
      channelReplyMarkup
    );
    
    return res.redirect(`/invoice/${invoice._id}`);
    
  } catch (e) {
    console.error('Create invoice error:', e.response?.data || e.message);
    req.session.errorMsg = e.message || 'Gagal membuat invoice deposit. Silakan coba lagi.';
    return res.redirect('/deposit');
  }
});

app.get('/invoice/:id', isAuth, async (req, res) => {
  const inv = await findById('invoices', req.params.id);
  if (!inv || inv.userId !== req.session.userId) {
    return res.status(404).send('Tidak ditemukan');
  }
  res.render('invoice_detail', { inv });
});

app.get('/withdraw', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const withdrawals = await find('withdrawals', { userId: req.session.userId });
  res.render('withdraw', { settings, withdrawals: withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) });
});

app.post('/withdraw/request', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const user = res.locals.user;
  if (!user.ewallet || !user.accountNumber || !user.accountName) {
    req.session.errorMsg = 'Harap lengkapi data E-Wallet di Profil terlebih dahulu.';
    return res.redirect('/withdraw');
  }
  const { amount } = req.body;
  const amt = parseInt(amount);
  const fee = settings.feeWithdraw || 0;
  const totalDeduct = amt + fee;
  if (isNaN(amt) || amt < settings.minWithdraw) {
    req.session.errorMsg = 'Minimal penarikan Rp ' + settings.minWithdraw;
    return res.redirect('/withdraw');
  }
  
  if (user.balance < totalDeduct) {
    req.session.errorMsg = 'Saldo tidak cukup (termasuk biaya admin Rp ' + fee.toLocaleString() + ')';
    return res.redirect('/withdraw');
  }
  
  user.balance -= totalDeduct;
  await updateById('users', req.session.userId, { $set: user });
  
  try {
    const ref = 'W' + Date.now().toString(36).toUpperCase();
    const wd = await createWithRetry('withdrawals', {
      _id: generateCustomId(startId.withdraw),
      userId: req.session.userId, amount: amt, fee,
      method: user.ewallet, accountNumber: user.accountNumber, accountName: user.accountName,
      status: 'pending',
      adminNote: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId: req.session.userId, type: 'withdraw', amount: amt, fee,
      status: 'pending', reference: ref,
      createdAt: new Date()
    });
    
    await sendAdminNotification('new_withdraw', {
      username: user.username,
      amount: amt + fee,
      status: 'pending'
    });
    
    const adminChatId = await getAdminChatId();
    if (adminChatId) {
      const userForMsg = await findById('users', req.session.userId);
      const timeString = new Date(wd.createdAt).toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      }).replace(/, /, ' pukul ');
      const header = `🌐 *Notifikasi - ${settings.name}*\n\n`;
      const userInfo = `👤 *Informasi User*\n• *User:* ${userForMsg.username} (${userForMsg.email})\n• *Saldo Saat Ini:* Rp ${user.balance.toLocaleString()}\n• *E-Wallet:* ${user.ewallet}\n• *No. Rek:* \`${user.accountNumber}\`\n• *Nama Rek:* ${user.accountName}\n\n`;
      const withdrawInfo = `📤 Informasi Withdraw\n• *Jumlah:* Rp ${amt.toLocaleString()}\n• *Biaya:* Rp ${fee.toLocaleString()}\n• *Total Penarikan:* Rp ${totalDeduct.toLocaleString()}\n• *Waktu:* ${timeString}\n`;
      const inlineKeyboard = {
        inline_keyboard: [[
          { text: '✅ Setujui', callback_data: `approve_wd:${wd._id}` },
          { text: '❌ Tolak', callback_data: `reason_wd:${wd._id}` }
        ]]
      };
      sendTelegramMessage(adminChatId, header + userInfo + withdrawInfo, inlineKeyboard);
    }
    req.session.successMsg = 'Penarikan berhasil diajukan dan sedang diproses.';
  } catch (err) {
    user.balance += totalDeduct;
    await updateById('users', req.session.userId, { $set: user });
    req.session.errorMsg = 'Gagal memproses penarikan sistem.';
  }
  res.redirect('/withdraw');
});

app.get('/admin/dashboard', isAuth, isAdmin, async (req, res) => {
  const stats = await getStats();
  res.render('admin_dashboard', stats);
});

app.get('/admin/users', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let users = await readDB('users');
  users = users.filter(u => u.role === 'user');
  if (search) {
    users = users.filter(u => 
      u.email.toLowerCase().includes(search.toLowerCase()) || 
      u.username.toLowerCase().includes(search.toLowerCase())
    );
  }
  users.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_users', { users, search });
});

app.get('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const targetUser = await findById('users', req.params.id);
  if (!targetUser) return res.status(404).send('Tidak ditemukan');
  res.render('admin_user_edit', { users: targetUser });
});

app.post('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const { username, email, password, balance, suspended } = req.body;
  if (username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
  }
  const user = await findById('users', req.params.id);
  if (!user) {
    req.session.errorMsg = 'User tidak ditemukan';
    return res.redirect('/admin/users');
  }
  
  if (username) user.username = username.toLowerCase();
  if (email) user.email = email.toLowerCase();
  if (balance !== undefined) user.balance = parseInt(balance) || 0;
  user.suspended = suspended === 'on';
  if (password && password.trim()) user.password = hashPassword(password);
  
  try {
    await updateById('users', req.params.id, { $set: user });
    req.session.successMsg = 'Data pengguna berhasil diperbarui';
    res.redirect('/admin/users');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui data pengguna';
    res.redirect(`/admin/users/${req.params.id}/edit`);
  }
});

app.post('/admin/users/:id/delete', isAuth, isAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const userToDelete = await findById('users', userId);
    if (!userToDelete) {
      req.session.errorMsg = 'User tidak ditemukan.';
      return res.redirect('/admin/users');
    }
    if (userToDelete.role === 'admin') {
      req.session.errorMsg = 'Tidak dapat menghapus akun admin.';
      return res.redirect('/admin/users');
    }
    await deleteMany('invoices', { userId });
    await deleteMany('transactions', { userId });
    await deleteMany('withdrawals', { userId });
    await deleteMany('apiKeys', { userId });
    await deleteOne('users', { _id: userId });
    req.session.successMsg = 'User berhasil dihapus beserta seluruh data terkait.';
    res.redirect('/admin/users');
  } catch (err) {
    console.error(err);
    req.session.errorMsg = 'Gagal menghapus user.';
    res.redirect('/admin/users');
  }
});

app.get('/admin/withdraw', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let withdrawals = await readDB('withdrawals');
  
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => 
      u.email.toLowerCase().includes(search.toLowerCase()) || 
      u.username.toLowerCase().includes(search.toLowerCase())
    ).map(u => u._id);
    withdrawals = withdrawals.filter(w => matchedUsers.includes(w.userId));
  }
  
  for (const w of withdrawals) {
    const user = await findById('users', w.userId);
    if (user) {
      w.username = user.username;
      w.email = user.email;
    }
  }
  withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_withdraw', { withdrawals, search });
});

app.post('/admin/withdraw/success/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'success';
    await updateById('withdrawals', wd._id, { $set: wd });
    
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'success';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    
    await updateOne('stats', {}, { $inc: { totalWithdrawAmount: wd.amount, totalWithdrawFee: wd.fee } });
    
    const settings = await getSettings();
    const user = await findById('users', wd.userId);
    const channelReplyMarkup = {
      inline_keyboard: [
        [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
      ]
    };
    
    let maskedAccountNumber = wd.accountNumber || '-';
    if (maskedAccountNumber !== '-' && maskedAccountNumber.length > 4) {
      const last4 = maskedAccountNumber.slice(-4);
      maskedAccountNumber = '••••••' + last4;
    } else if (maskedAccountNumber !== '-' && maskedAccountNumber.length <= 4) {
      maskedAccountNumber = '••••';
    }
    
    let maskedAccountName = wd.accountName || '-';
    if (maskedAccountName !== '-' && maskedAccountName.length > 3) {
      const firstChar = maskedAccountName.charAt(0);
      const lastChar = maskedAccountName.charAt(maskedAccountName.length - 1);
      maskedAccountName = firstChar + '••••' + lastChar;
    } else if (maskedAccountName !== '-' && maskedAccountName.length <= 3) {
      maskedAccountName = '••••';
    }
    
    const photoUrl = 'https://cdn.yupra.my.id/yp/0k7sxf4g.png';
    
    await sendTelegramChannelPhoto(
      photoUrl,
       `🌐 *AzxPedia*\n\n` +
       `✅ *Withdraw Berhasil*\n` +
      `User: ${user ? user.username : 'Unknown'}\n` +
      `Jumlah: Rp ${wd.amount.toLocaleString()}\n` +
      `Fee Admin: Rp ${wd.fee.toLocaleString()}\n` +
      `Total Ditarik: Rp ${(wd.amount + wd.fee).toLocaleString()}\n` +
      `Metode: ${wd.method || 'E-Wallet'}\n` +
      `No. Rekening: ${maskedAccountNumber}\n` +
      `Nama Rekening: ${maskedAccountName}\n` +
      `Status: ✅ Berhasil\n\n` +
      `_${new Date().toLocaleString('id-ID')}_`,
      channelReplyMarkup
    );
    
    req.session.successMsg = 'Penarikan berhasil disetujui.';
  }
  res.redirect('/admin/withdraw');
});

app.post('/admin/withdraw/reject/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'rejected';
    wd.adminNote = req.body.note || '';
    await updateById('withdrawals', wd._id, { $set: wd });
    
    const user = await findById('users', wd.userId);
    user.balance += wd.amount + wd.fee;
    await updateById('users', wd.userId, { $set: user });
    
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'rejected';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    
    req.session.successMsg = 'Penarikan ditolak dan saldo dikembalikan.';
  }
  res.redirect('/admin/withdraw');
});

app.get('/admin/transactions', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let transactions = await readDB('transactions');
  
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => 
      u.email.toLowerCase().includes(search.toLowerCase()) || 
      u.username.toLowerCase().includes(search.toLowerCase())
    ).map(u => u._id);
    transactions = transactions.filter(t => 
      matchedUsers.includes(t.userId) || 
      (t.reference && t.reference.toLowerCase().includes(search.toLowerCase()))
    );
  }
  
  for (const t of transactions) {
    const user = await findById('users', t.userId);
    if (user) {
      t.username = user.username;
      t.email = user.email;
    }
  }
  transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_transactions', { transactions, search });
});

app.get('/admin/account', isAuth, isAdmin, async (req, res) => {
  const admin = await findById('users', req.session.userId);
  res.render('admin_account', { admin });
});

app.post('/admin/account', isAuth, isAdmin, async (req, res) => {
  const { username, password, newPassword } = req.body;
  const admin = await findById('users', req.session.userId);
  if (!password || !verifyPassword(password, admin.password)) {
    req.session.errorMsg = 'Password saat ini salah';
    return res.redirect('/admin/account');
  }
  if (username && username !== admin.username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect('/admin/account');
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect('/admin/account');
    }
    const existing = await findOne('users', { username: username.toLowerCase() });
    if (existing && existing._id !== admin._id) {
      req.session.errorMsg = 'Username sudah digunakan oleh pengguna lain';
      return res.redirect('/admin/account');
    }
  }
  try {
    if (username && username !== admin.username) admin.username = username.toLowerCase();
    if (newPassword && newPassword.trim()) admin.password = hashPassword(newPassword);
    await updateById('users', req.session.userId, { $set: admin });
    req.session.successMsg = 'Data akun berhasil diperbarui';
  } catch (e) {
    req.session.errorMsg = 'Gagal memperbarui akun';
  }
  res.redirect('/admin/account');
});

app.post('/admin/settings/reset', isAuth, isAdmin, async (req, res) => {
  try {
    const users = await readDB('users');
    const adminUser = users.find(u => u.role === 'admin');
    
    await writeDB('users', adminUser ? [adminUser] : []);
    await writeDB('invoices', []);
    await writeDB('transactions', []);
    await writeDB('withdrawals', []);
    await writeDB('apiKeys', []);
    await writeDB('stats', [{
      totalDepositAmount: 0,
      totalDepositFee: 0,
      totalWithdrawAmount: 0,
      totalWithdrawFee: 0,
      totalUsers: 0,
      totalTransactions: 0
    }]);

    req.session.successMsg = 'Database berhasil direset. Semua data pengguna, invoice, transaksi, dan withdrawal telah dihapus.';
  } catch (error) {
    console.error('Reset database error:', error);
    req.session.errorMsg = 'Gagal mereset database. Silakan coba lagi.';
  }
  res.redirect('/admin/settings');
});

app.get('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  res.render('admin_settings', { settings });
});

app.post('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const { 
    name, title, description, channelWhatsApp,
    minDeposit, minWithdraw, feeWithdraw, feeDeposit, maxFee, 
    checkInterval, autoCheckEnabled, autoBackupEnabled, autoRestartEnabled,
    backupType, backupInterval, restartTime, backupTime,
    smtpUser, smtpPass, telegramBotToken, telegramAdminChatId, logoUrl,
    pakasirApiUrl, pakasirProject, pakasirApiKey
  } = req.body;
  
  const settings = await getSettings();
  settings.name = name;
  settings.title = title;
  settings.description = description;
  settings.channelWhatsApp = channelWhatsApp;
  settings.minDeposit = parseInt(minDeposit);
  settings.minWithdraw = parseInt(minWithdraw);
  settings.feeWithdraw = parseInt(feeWithdraw);
  settings.feeDeposit = parseInt(feeDeposit) || 0;
  settings.maxFee = parseInt(maxFee);
  settings.checkInterval = parseInt(checkInterval);
  settings.autoCheckEnabled = autoCheckEnabled === 'on';
  settings.autoBackupEnabled = autoBackupEnabled === 'on';
  settings.autoRestartEnabled = autoRestartEnabled === 'on';
  settings.backupType = backupType || 'database';
  settings.backupInterval = parseInt(backupInterval) || 5;
  settings.restartTime = restartTime || '03:00';
  settings.backupTime = backupTime || '00:00';
  settings.smtpUser = smtpUser;
  settings.smtpPass = smtpPass;
  settings.telegramBotToken = telegramBotToken;
  settings.telegramAdminChatId = telegramAdminChatId;
  settings.logoUrl = logoUrl;
  
  if (pakasirApiUrl) settings.pakasirApiUrl = pakasirApiUrl;
  if (pakasirProject) settings.pakasirProject = pakasirProject;
  if (pakasirApiKey !== undefined) settings.pakasirApiKey = pakasirApiKey || '';
  
  await updateById('settings', settings._id, { $set: settings });
  startChecker();
  startTelegramPolling();
  scheduleAutoBackup();
  scheduleAutoRestart();
  
  const adminChatId = settings.telegramAdminChatId;
  if (adminChatId && settings.telegramBotToken) {
    await sendTelegramMessage(
      adminChatId,
      `⚙️ *SETTINGS UPDATED*\n\n` +
      `Pengaturan telah diperbarui oleh Admin.\n` +
      `⏰ Waktu: ${new Date().toLocaleString('id-ID')}`
    );
  }
  
  req.session.successMsg = 'Pengaturan berhasil diperbarui dan sistem disinkronisasi.';
  res.redirect('/admin/settings');
});

// ===== ENDPOINT TEST PAKASIR =====
app.post('/admin/pakasir/test', isAuth, isAdmin, async (req, res) => {
  const { project, apiKey, amount } = req.body;
  
  try {
    const testAmount = parseInt(amount) || 1000;
    const testOrderId = 'TEST_' + Date.now().toString(36).toUpperCase();
    
    const url = `${DEFAULT_PAKASIR_API_URL}/transactioncreate/qris`;
    
    const payload = {
      project: project || DEFAULT_PAKASIR_PROJECT,
      order_id: testOrderId,
      amount: testAmount,
      api_key: apiKey || ''
    };
    
    const response = await axios.post(url, payload, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });
    
    if (response.data && response.data.payment) {
      res.json({ 
        success: true, 
        data: response.data.payment,
        message: 'Koneksi Pakasir berhasil!'
      });
    } else {
      res.json({ 
        success: false, 
        message: response.data?.message || 'Gagal koneksi ke Pakasir' 
      });
    }
  } catch (error) {
    console.error('[PAKASIR] Test error:', error.response?.data || error.message);
    res.json({ 
      success: false, 
      message: error.response?.data?.message || error.message 
    });
  }
});

app.get('/docs', async (req, res) => {
  let userApiKey = '';
  if (req.session.userId) {
    const key = await findOne('apiKeys', { userId: req.session.userId });
    if (key) userApiKey = key.key;
  }
  res.render('docs', { userApiKey });
});

async function apiAuth(req, res, next) {
  const apiKey = req.headers['x-api-key'] || req.query.api_key || req.query.apikey;
  if (!apiKey) return res.status(401).json({ error: 'API key diperlukan' });
  const keyDoc = await findOne('apiKeys', { key: apiKey });
  if (!keyDoc) return res.status(401).json({ error: 'API key tidak valid' });
  req.apiUser = keyDoc.userId;
  next();
}

app.get('/api/v1/balance', apiAuth, async (req, res) => {
  const user = await findById('users', req.apiUser);
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan' });
  res.json({ balance: user.balance });
});

app.get('/api/v1/invoice', apiAuth, async (req, res) => {
  const settings = await getSettings();
  const amount = parseInt(req.query.amount);
  const userId = req.apiUser;
  const feeDeposit = settings.feeDeposit || 0;
  const totalAmount = amount + feeDeposit;
  
  if (!amount || isNaN(amount) || amount < settings.minDeposit) {
    return res.status(400).json({ error: `Nominal minimal Rp ${settings.minDeposit}` });
  }
  
  try {
    const orderId = generateCustomId('PAK');
    const qrisResult = await createPakasirQRIS(totalAmount, orderId);
    
    if (!qrisResult.success) {
      throw new Error(qrisResult.error || 'Gagal membuat QRIS');
    }
    
    const expiredAt = new Date(qrisResult.expired || Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId,
      amount: amount,
      fee: feeDeposit,
      total: totalAmount,
      trxid: qrisResult.trxid || orderId,
      qris_image: '',
      qr_string: qrisResult.qr_string || '',
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date(),
      paymentMethod: 'Qris Payment',
      paymentProvider: 'pakasir',
      providerData: {
        order_id: orderId,
        total_payment: qrisResult.total_payment,
        fee: qrisResult.fee
      }
    });
    
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId,
      type: 'deposit',
      amount: amount,
      fee: feeDeposit,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date(),
      paymentMethod: 'Qris Payment',
      paymentProvider: 'pakasir'
    });
    
    return res.json({
      success: true,
      invoice_id: invoice._id,
      amount: invoice.amount,
      fee: invoice.fee,
      total: invoice.total,
      qr_string: invoice.qr_string,
      expired_at: invoice.expiredAt,
      payment_method: 'Qris Payment'
    });
    
  } catch (e) {
    console.error('API create invoice error:', e.response?.data || e.message);
    return res.status(500).json({ error: 'Gagal membuat invoice' });
  }
});

app.get('/api/v1/invoice/status', apiAuth, async (req, res) => {
  const invoiceId = req.query.id || req.query.invoice_id;
  if (!invoiceId) return res.status(400).json({ error: 'Invoice ID diperlukan' });
  
  const invoice = await findById('invoices', invoiceId);
  if (!invoice || invoice.userId !== req.apiUser) {
    return res.status(404).json({ error: 'Invoice tidak ditemukan' });
  }
  
  res.json({
    invoice_id: invoice._id,
    amount: invoice.amount,
    fee: invoice.fee,
    total: invoice.total,
    status: invoice.status,
    qr_string: invoice.qr_string,
    expired_at: invoice.expiredAt,
    created_at: invoice.createdAt,
    payment_method: invoice.paymentMethod || 'Qris Payment'
  });
});

app.get('/admin/backup', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const hasTelegram = !!(settings.telegramBotToken && settings.telegramAdminChatId);
  res.render('admin_backup', { hasTelegram, settings });
});

app.post('/admin/backup/create', isAuth, isAdmin, async (req, res) => {
  try {
    const { backupType } = req.body;
    const result = await performBackup(backupType || 'database');
    
    if (result.success) {
      req.session.successMsg = `Backup berhasil dibuat! File: ${result.fileName}`;
    } else {
      req.session.errorMsg = `Backup gagal: ${result.error}`;
    }
  } catch (error) {
    req.session.errorMsg = `Backup gagal: ${error.message}`;
  }
  
  res.redirect('/admin/backup');
});

app.get('/otp', isAuth, async (req, res) => {
  try {
    console.log('[DEBUG] Loading OTP dashboard...');
    const servicesResult = await getRumahOTPServices();
    const orders = await getOTPOrders(req.session.userId);
    const user = res.locals.user;
    
    res.render('dashboard_otp', {
      services: servicesResult.success ? servicesResult.data : [],
      servicesError: servicesResult.error,
      orders: orders.slice(0, 5),
      user: user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    console.error('[ERROR] OTP dashboard error:', error);
    req.session.errorMsg = 'Gagal memuat halaman OTP';
    res.redirect('/dashboard');
  }
});

app.get('/otp/countries', isAuth, async (req, res) => {
  try {
    const { service_id, service_name, service_img } = req.query;
    console.log('[DEBUG] Fetching countries for service:', service_id);
    
    const countries = await getRumahOTPCountries(service_id);
    
    res.render('negara_otp', {
      serviceId: service_id,
      serviceName: service_name || 'Unknown',
      serviceImg: service_img || '',
      countries: countries.success ? countries.data : [],
      user: res.locals.user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    console.error('[ERROR] Countries page error:', error);
    req.session.errorMsg = 'Gagal memuat daftar negara';
    res.redirect('/otp');
  }
});

app.get('/otp/operators', isAuth, async (req, res) => {
  try {
    const { 
      country_id, 
      country_name, 
      country_price, 
      provider_id, 
      service_id, 
      service_name, 
      service_img,
      server_id, 
      rate, 
      stock
    } = req.query;
    
    console.log('[DEBUG] Operator page - country_price:', country_price, 'type:', typeof country_price);
    
    const operators = await getRumahOTPOperators(country_name, provider_id);
    
    res.render('operator_otp', {
      serviceId: service_id,
      serviceName: service_name || 'Unknown',
      serviceImg: service_img || '',
      countryId: country_id,
      countryName: country_name || 'Unknown',
      countryPrice: country_price || '0',
      providerId: provider_id,
      serverId: server_id || '1',
      rate: rate || 0,
      stock: stock || 0,
      operators: operators.success ? operators.data : [],
      user: res.locals.user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    console.error('[ERROR] Operators page error:', error);
    req.session.errorMsg = 'Gagal memuat daftar operator';
    res.redirect('/otp');
  }
});

app.post('/otp/order', isAuth, async (req, res) => {
  try {
    const { 
      service_id, service_name, service_img, 
      country_id, country_name, country_price, 
      provider_id, operator_id, operator_name 
    } = req.body;
    
    console.log('[DEBUG] Order request - country_price:', country_price, 'operator_id:', operator_id);
    
    const user = res.locals.user;
    const basePrice = parseInt(country_price) || 0;
    const totalPrice = basePrice + OTP_ADMIN_FEE;
    
    console.log('[DEBUG] basePrice:', basePrice, 'totalPrice:', totalPrice, 'userBalance:', user.balance);
    
    if (user.balance < totalPrice) {
      req.session.errorMsg = `Saldo tidak cukup! Total: Rp ${totalPrice.toLocaleString()}`;
      return res.redirect(`/otp/operators?country_id=${country_id}&country_name=${encodeURIComponent(country_name)}&country_price=${basePrice}&provider_id=${provider_id}&service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
    }
    
    const orderResult = await orderRumahOTPNumber(country_id, provider_id, operator_id);
    
    if (!orderResult.success) {
      let errorMessage = 'Gagal memesan nomor';
      
      if (orderResult.error) {
        if (typeof orderResult.error === 'string') {
          errorMessage = orderResult.error;
        } else if (orderResult.error.message) {
          errorMessage = orderResult.error.message;
        } else if (typeof orderResult.error === 'object') {
          errorMessage = JSON.stringify(orderResult.error);
        }
      }
      
      console.log('[DEBUG] Error message:', errorMessage);
      
      const isStockError = typeof errorMessage === 'string' && 
        (errorMessage.toLowerCase().includes('stock') || 
         errorMessage.toLowerCase().includes('habis') ||
         errorMessage.toLowerCase().includes('stok'));
      
      if (isStockError) {
        req.session.errorMsg = 'Maaf, stock penyedia sedang habis! Silakan pilih operator lain atau tunggu beberapa menit.';
        return res.redirect(`/otp/operators?country_id=${country_id}&country_name=${encodeURIComponent(country_name)}&country_price=${basePrice}&provider_id=${provider_id}&service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
      }
      
      const isBalanceError = typeof errorMessage === 'string' && 
        errorMessage.toLowerCase().includes('balance');
      
      if (isBalanceError) {
        req.session.errorMsg = 'Saldo provider sedang kosong, silakan coba lagi nanti.';
        return res.redirect(`/otp/countries?service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
      }
      
      req.session.errorMsg = `Maaf, stock penyedia sedang habis! Silakan pilih operator lain atau tunggu beberapa menit.`;
      return res.redirect(`/otp/operators?country_id=${country_id}&country_name=${encodeURIComponent(country_name)}&country_price=${basePrice}&provider_id=${provider_id}&service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
    }
    
    user.balance -= totalPrice;
    await updateById('users', user._id, { $set: user });
    
    const newOrder = {
      _id: generateCustomId('OTP'),
      userId: user._id,
      serviceName: service_name,
      serviceImg: service_img,
      countryName: country_name,
      countryId: country_id,
      providerId: provider_id,
      serverId: operator_id,
      operatorName: operator_name,
      phoneNumber: orderResult.data.phone_number,
      orderId: orderResult.data.order_id,
      price: basePrice,
      adminFee: OTP_ADMIN_FEE,
      totalPrice: totalPrice,
      status: 'waiting',
      createdAt: new Date(),
      expiredAt: orderResult.data.expired_at ? new Date(orderResult.data.expired_at) : new Date(Date.now() + 10 * 60000)
    };
    
    await saveOTPOrder(newOrder);
    
    await sendAdminNotification('new_otp_order', { 
      username: user.username, 
      service: service_name, 
      country: country_name, 
      operator: operator_name, 
      price: totalPrice 
    });
    
    const channelReplyMarkup = {
      inline_keyboard: [
        [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
      ]
    };
    
    let maskedPhone = orderResult.data.phone_number || '-';
    if (maskedPhone !== '-' && maskedPhone.length > 4) {
      const last4 = maskedPhone.slice(-4);
      maskedPhone = '••••••' + last4;
    } else if (maskedPhone !== '-' && maskedPhone.length <= 4) {
      maskedPhone = '••••';
    }
    
    const photoUrl = 'https://cdn.yupra.my.id/yp/tftx606i.png';
    
    await sendTelegramChannelPhoto(
      photoUrl,
      `📱 *ORDER NOKOS BERHASIL*\n\n` +
      `🌐 *AzxPedia*\n\n` +
      `👤 *User:* ${user.username}\n` +
      `📱 *Layanan:* ${service_name}\n` +
      `🌍 *Negara:* ${country_name}\n` +
      `📡 *Operator:* ${operator_name}\n` +
      `💰 *Harga:* Rp ${totalPrice.toLocaleString()}\n` +
      `📱 *Nomor:* ${maskedPhone}\n` +
      `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n` +
      `📌 *Status:* ⏳ Menunggu OTP`,
      channelReplyMarkup
    );
    
    req.session.successMsg = 'Pesanan berhasil dibuat! Silakan tunggu OTP masuk.';
    res.redirect(`/otp/order/${newOrder._id}`);
    
  } catch (error) {
    console.error('[ERROR] Order error:', error);
    req.session.errorMsg = error.message || 'Gagal memesan OTP, silakan coba lagi.';
    res.redirect('/otp');
  }
});

app.get('/otp/order/:id', isAuth, async (req, res) => {
  try {
    let order = (await getOTPOrders()).find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      req.session.errorMsg = 'Order tidak ditemukan';
      return res.redirect('/otp');
    }
    
    if (order.status === 'waiting' && order.orderId) {
      const statusResult = await checkRumahOTPStatus(order.orderId);
      if (statusResult.success && statusResult.data) {
        if (statusResult.data.status === 'completed' && statusResult.data.otp_code) {
          order.otpCode = statusResult.data.otp_code;
          order.otpMessage = statusResult.data.otp_msg;
          order.status = 'success';
          await updateOTPOrder(order._id, { 
            otpCode: statusResult.data.otp_code, 
            otpMessage: statusResult.data.otp_msg, 
            status: 'success' 
          });
          
          const user = await findById('users', order.userId);
          const channelReplyMarkup = {
            inline_keyboard: [
              [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
            ]
          };
          
          let maskedPhone = order.phoneNumber || '-';
          if (maskedPhone !== '-' && maskedPhone.length > 4) {
            const last4 = maskedPhone.slice(-4);
            maskedPhone = '••••••' + last4;
          } else if (maskedPhone !== '-' && maskedPhone.length <= 4) {
            maskedPhone = '••••';
          }
          
          await sendTelegramChannelMessage(
            `✅ *OTP BERHASIL DITERIMA*\n\n` +
            `👤 *User:* ${user ? user.username : 'Unknown'}\n` +
            `📱 *Layanan:* ${order.serviceName}\n` +
            `🌍 *Negara:* ${order.countryName}\n` +
            `📡 *Operator:* ${order.operatorName}\n` +
            `💰 *Harga:* Rp ${order.totalPrice.toLocaleString()}\n` +
            `📱 *Nomor:* ${maskedPhone}\n` +
            `🔑 *Kode OTP:* ${order.otpCode || '-'}\n` +
            `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}`,
            channelReplyMarkup
          );
          
          await sendAdminNotification('otp_order_success', {
            username: user ? user.username : 'Unknown',
            service: order.serviceName,
            country: order.countryName,
            operator: order.operatorName,
            price: order.totalPrice,
            phoneNumber: order.phoneNumber,
            otpCode: order.otpCode
          });
          
        } else if (statusResult.data.status === 'expired' || statusResult.data.status === 'canceled') {
          order.status = 'expired';
          await updateOTPOrder(order._id, { status: 'expired' });
          const user = await findById('users', order.userId);
          if (user) { 
            user.balance += order.totalPrice; 
            await updateById('users', user._id, { $set: user }); 
          }
        }
      }
      if (new Date() > new Date(order.expiredAt) && order.status === 'waiting') {
        order.status = 'expired';
        await updateOTPOrder(order._id, { status: 'expired' });
        const user = await findById('users', order.userId);
        if (user) { 
          user.balance += order.totalPrice; 
          await updateById('users', user._id, { $set: user }); 
        }
      }
    }
    res.render('order_otp', { order, user: res.locals.user });
  } catch (error) {
    console.error('[ERROR] Order detail error:', error);
    req.session.errorMsg = 'Gagal memuat detail order';
    res.redirect('/otp');
  }
});

app.get('/otp/api/check/:id', isAuth, async (req, res) => {
  try {
    const orders = await getOTPOrders();
    const order = orders.find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      return res.json({ success: false, message: 'Order tidak ditemukan' });
    }
    
    let updated = false;
    let newStatus = order.status;
    
    if (order.status === 'waiting' && order.orderId) {
      console.log(`[API] Checking order ${order.orderId} from RumahOTP...`);
      const statusResult = await checkRumahOTPStatus(order.orderId);
      console.log(`[API] Status result:`, JSON.stringify(statusResult));
      
      if (statusResult.success && statusResult.data) {
        const apiStatus = statusResult.data.status;
        const otpCode = statusResult.data.otp_code;
        
        if ((apiStatus === 'received' || apiStatus === 'completed') && otpCode) {
          console.log(`[API] OTP FOUND! Status: ${apiStatus}, Code: ${otpCode}`);
          await updateOTPOrder(order._id, { 
            otpCode: otpCode, 
            otpMessage: statusResult.data.otp_msg, 
            status: 'success' 
          });
          newStatus = 'success';
          updated = true;
          
          const user = await findById('users', order.userId);
          
          let maskedPhone = order.phoneNumber || '-';
          if (maskedPhone !== '-' && maskedPhone.length > 4) {
            const last4 = maskedPhone.slice(-4);
            maskedPhone = '••••••' + last4;
          } else if (maskedPhone !== '-' && maskedPhone.length <= 4) {
            maskedPhone = '••••';
          }
          
          let maskedOtp = otpCode || '-';
          if (maskedOtp !== '-' && maskedOtp.length > 4) {
            const last4 = maskedOtp.slice(-4);
            maskedOtp = '••••••' + last4;
          } else if (maskedOtp !== '-' && maskedOtp.length <= 4) {
            maskedOtp = '••••';
          }
          
          const channelReplyMarkup = {
            inline_keyboard: [
              [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
            ]
          };
          
          const photoUrl = 'https://cdn.yupra.my.id/yp/tftx606i.png';
          
          await sendTelegramChannelPhoto(
            photoUrl,
            `✅ *OTP BERHASIL DITERIMA*\n\n` +
            `🌐 *AzxPedia*\n\n` +
            `👤 *User:* ${user ? user.username : 'Unknown'}\n` +
            `📱 *Layanan:* ${order.serviceName}\n` +
            `🌍 *Negara:* ${order.countryName}\n` +
            `📡 *Operator:* ${order.operatorName}\n` +
            `💰 *Harga:* Rp ${order.totalPrice.toLocaleString()}\n` +
            `📱 *Nomor:* ${maskedPhone}\n` +
            `🔑 *Kode OTP:* ${maskedOtp}\n` +
            `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}`,
            channelReplyMarkup
          );
          
          await sendAdminNotification('otp_order_success', {
            username: user ? user.username : 'Unknown',
            service: order.serviceName,
            country: order.countryName,
            operator: order.operatorName,
            price: order.totalPrice,
            phoneNumber: order.phoneNumber,
            otpCode: otpCode
          });
          
        } else if (apiStatus === 'expired' || apiStatus === 'canceled') {
          console.log(`[API] Order expired/canceled`);
          await updateOTPOrder(order._id, { status: 'expired' });
          newStatus = 'expired';
          updated = true;
          
          const user = await findById('users', order.userId);
          if (user) { 
            user.balance += order.totalPrice; 
            await updateById('users', user._id, { $set: user }); 
            console.log(`[API] Refunded Rp ${order.totalPrice} to user ${user.username}`);
          }
        }
      }
    }
    
    res.json({ success: true, status: newStatus, updated: updated });
  } catch (error) {
    console.error('[ERROR] API check error:', error);
    res.json({ success: false, message: error.message });
  }
});

app.post('/otp/cancel/:id', isAuth, async (req, res) => {
  try {
    const orders = await getOTPOrders();
    const order = orders.find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      return res.json({ success: false, message: 'Order tidak ditemukan' });
    }
    if (order.status !== 'waiting') {
      return res.json({ success: false, message: 'Order tidak dapat dibatalkan' });
    }
    
    await cancelRumahOTPOrder(order.orderId);
    const user = await findById('users', order.userId);
    if (user) { 
      user.balance += order.totalPrice; 
      await updateById('users', user._id, { $set: user }); 
    }
    await updateOTPOrder(order._id, { status: 'cancelled' });
    res.json({ success: true, message: 'Order dibatalkan, saldo dikembalikan' });
  } catch (error) {
    console.error('[ERROR] Cancel order error:', error);
    res.json({ success: false, message: 'Gagal membatalkan order' });
  }
});

app.get('/otp/history', isAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 15;
    const filter = req.query.filter || 'all';
    const search = req.query.search || '';
    
    let orders = await getOTPOrders(req.session.userId);
    
    if (filter !== 'all') {
      orders = orders.filter(o => o.status === filter);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      orders = orders.filter(o => 
        o._id.toLowerCase().includes(searchLower) || 
        o.serviceName.toLowerCase().includes(searchLower) ||
        o.countryName.toLowerCase().includes(searchLower)
      );
    }
    
    const totalOrders = orders.length;
    const totalPages = Math.ceil(totalOrders / limit);
    const startIndex = (page - 1) * limit;
    const paginatedOrders = orders.slice(startIndex, startIndex + limit);
    
    const successCount = orders.filter(o => o.status === 'success').length;
    const waitingCount = orders.filter(o => o.status === 'waiting').length;
    const expiredCount = orders.filter(o => o.status === 'expired').length;
    
    res.render('otp_history', {
      orders: paginatedOrders,
      totalOrders: totalOrders,
      successCount: successCount,
      waitingCount: waitingCount,
      expiredCount: expiredCount,
      currentPage: page,
      totalPages: totalPages,
      limit: limit,
      filter: filter,
      search: search,
      user: res.locals.user
    });
  } catch (error) {
    console.error('[ERROR] OTP history error:', error);
    req.session.errorMsg = 'Gagal memuat riwayat pesanan';
    res.redirect('/otp');
  }
});

app.get('/admin/otp', isAuth, isAdmin, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const filter = req.query.filter || 'all';
    const search = req.query.search || '';
    
    let orders = await getOTPOrders();
    
    const users = await readDB('users');
    orders = orders.map(order => {
      const user = users.find(u => u._id === order.userId);
      return {
        ...order,
        username: user?.username || 'Unknown',
        userEmail: user?.email || '-'
      };
    });
    
    if (filter !== 'all') {
      orders = orders.filter(o => o.status === filter);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      orders = orders.filter(o => 
        o._id.toLowerCase().includes(searchLower) ||
        o.serviceName.toLowerCase().includes(searchLower) ||
        o.countryName.toLowerCase().includes(searchLower) ||
        o.username?.toLowerCase().includes(searchLower) ||
        o.userEmail?.toLowerCase().includes(searchLower)
      );
    }
    
    const totalOrders = orders.length;
    
    const totalGrossRevenue = orders
      .filter(o => o.status === 'success')
      .reduce((sum, o) => sum + (o.totalPrice || 0), 0);
    
    const totalNetRevenue = orders
      .filter(o => o.status === 'success')
      .reduce((sum, o) => sum + (o.adminFee || 0), 0);
    
    const successCount = orders.filter(o => o.status === 'success').length;
    const waitingCount = orders.filter(o => o.status === 'waiting').length;
    const expiredCount = orders.filter(o => o.status === 'expired').length;
    
    const providerBalance = await getRumahOTPBalance();
    
    const totalPages = Math.ceil(totalOrders / limit);
    const startIndex = (page - 1) * limit;
    const paginatedOrders = orders.slice(startIndex, startIndex + limit);
    
    res.render('admin_otp', {
      orders: paginatedOrders,
      stats: {
        totalOrders: totalOrders,
        totalGrossRevenue: totalGrossRevenue,
        totalNetRevenue: totalNetRevenue,
        successCount: successCount,
        waitingCount: waitingCount,
        expiredCount: expiredCount
      },
      providerBalance: providerBalance.success ? providerBalance.data : null,
      providerBalanceError: providerBalance.error,
      currentPage: page,
      totalPages: totalPages,
      limit: limit,
      filter: filter,
      search: search,
      totalOrders: totalOrders,
      adminFee: OTP_ADMIN_FEE,
      user: res.locals.user
    });
  } catch (error) {
    console.error('[ERROR] Admin OTP error:', error);
    req.session.errorMsg = 'Gagal memuat data OTP';
    res.redirect('/admin/dashboard');
  }
});

app.get('/sitemap.xml', async (req, res) => {
  const sitemapPath = path.join(__dirname, 'public', 'sitemap.xml');
  res.sendFile(sitemapPath);
});

app.get('/robots.txt', async (req, res) => {
  const robotsPath = path.join(__dirname, 'public', 'robots.txt');
  res.sendFile(robotsPath);
});

app.get('/admin/notifications', isAuth, isAdmin, async (req, res) => {
  const notifications = await getNotifications();
  res.render('admin_notifications', { notifications, user: res.locals.user });
});

app.post('/admin/notifications/create', isAuth, isAdmin, async (req, res) => {
  const { title, message, imageUrl, target, displayType } = req.body;
  
  const newNotif = {
    _id: generateCustomId('NOTIF'),
    title: title || 'Pengumuman',
    message: message || '',
    imageUrl: imageUrl || null,
    target: target || 'all',
    displayType: displayType || 'once',
    isActive: true,
    seenBy: [],
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  await saveNotification(newNotif);
  req.session.successMsg = 'Notifikasi berhasil dibuat!';
  res.redirect('/admin/notifications');
});

app.post('/admin/notifications/update/:id', isAuth, isAdmin, async (req, res) => {
  const { title, message, imageUrl, target, displayType, isActive } = req.body;
  await updateNotification(req.params.id, {
    title,
    message,
    imageUrl,
    target,
    displayType,
    isActive: isActive === 'on',
    updatedAt: new Date()
  });
  req.session.successMsg = 'Notifikasi berhasil diperbarui!';
  res.redirect('/admin/notifications');
});

app.post('/admin/notifications/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteNotification(req.params.id);
  req.session.successMsg = 'Notifikasi berhasil dihapus!';
  res.redirect('/admin/notifications');
});

app.get('/api/notifications/active', isAuth, async (req, res) => {
  const notifications = await getNotifications();
  const userNotifs = notifications.filter(n => {
    if (!n.isActive) return false;
    if (n.target !== 'all' && n.target !== req.session.userId) return false;
    if (n.displayType === 'once' && n.seenBy && n.seenBy.includes(req.session.userId)) return false;
    return true;
  });
  res.json({ success: true, notifications: userNotifs });
});

app.post('/api/notifications/seen/:id', isAuth, async (req, res) => {
  await markNotificationAsSeen(req.params.id, req.session.userId);
  res.json({ success: true });
});

app.get('/events', isAuth, async (req, res) => {
  try {
    const activeEvent = await getActiveEvent();
    const hasClaimed = activeEvent ? await hasUserClaimedEvent(req.session.userId, activeEvent._id) : false;
    
    console.log('[DEBUG] activeEvent:', activeEvent);
    
    res.render('events', { 
      activeEvent: activeEvent || null,
      hasClaimed: hasClaimed, 
      user: res.locals.user 
    });
  } catch (error) {
    console.error('[ERROR] Events page error:', error);
    req.session.errorMsg = 'Gagal memuat halaman event';
    res.redirect('/dashboard');
  }
});

app.post('/events/claim', isAuth, async (req, res) => {
  const { eventId, answer } = req.body;
  const events = await readDB('events');
  const event = events.find(e => e._id === eventId);
  
  if (!event) {
    return res.json({ success: false, message: 'Event tidak ditemukan' });
  }
  
  if (!event.isActive || new Date(event.expiredAt) < new Date()) {
    return res.json({ success: false, message: 'Event sudah berakhir' });
  }
  
  const hasClaimed = await hasUserClaimedEvent(req.session.userId, eventId);
  if (hasClaimed) {
    return res.json({ success: false, message: 'Anda sudah pernah mengklaim hadiah event ini' });
  }
  
  if (answer.toLowerCase().trim() !== event.answer.toLowerCase().trim()) {
    return res.json({ success: false, message: 'Jawaban salah! Silakan coba lagi.' });
  }
  
  const user = await findById('users', req.session.userId);
  user.balance += event.reward;
  await updateById('users', user._id, { $set: user });
  
  await addUserToEventClaimed(eventId, req.session.userId);
  
  await createWithRetry('transactions', {
    _id: generateCustomId(startId.transaction),
    userId: user._id,
    type: 'deposit',
    amount: event.reward,
    fee: 0,
    status: 'paid',
    reference: `EVENT_${event._id}`,
    createdAt: new Date()
  });
  
  res.json({ success: true, message: `Selamat! Anda mendapat Rp ${event.reward.toLocaleString()}`, reward: event.reward });
});

app.get('/admin/events', isAuth, isAdmin, async (req, res) => {
  const events = await getEvents();
  res.render('admin_events', { events, user: res.locals.user });
});

app.post('/admin/events/create', isAuth, isAdmin, async (req, res) => {
  const { title, question, answer, reward, expiredAt } = req.body;
  const newEvent = {
    _id: generateCustomId('EVENT'),
    title,
    question,
    answer: answer.toLowerCase().trim(),
    reward: parseInt(reward),
    isActive: true,
    claimedBy: [],
    createdAt: new Date(),
    expiredAt: new Date(expiredAt)
  };
  await saveEvent(newEvent);
  
  const channelReplyMarkup = {
    inline_keyboard: [
      [{ text: '🎉 Klaim Event Sekarang', url: 'https://app.azxpedia.my.id/events' }]
    ]
  };
  
  const photoUrl = 'https://cdn.yupra.my.id/yp/tftx606i.png';
  
  await sendTelegramChannelPhoto(
    photoUrl,
    `🎉 *EVENT BARU DIMULAI!*\n\n` +
    `🌐 *AzxPedia*\n\n` +
    `Judul Event: ${title}\n` +
    `Pertanyaan: ${question}\n` +
    `Hadiah: Rp ${parseInt(reward).toLocaleString()}\n` +
    `Berlaku Sampai: ${new Date(expiredAt).toLocaleString('id-ID')}\n\n` +
    `_Ayo Login dan Klaim event nya sekarang!_`,
    channelReplyMarkup
  );
  
  req.session.successMsg = 'Event berhasil dibuat!';
  res.redirect('/admin/events');
});

app.post('/admin/events/toggle/:id', isAuth, isAdmin, async (req, res) => {
  const events = await readDB('events');
  const event = events.find(e => e._id === req.params.id);
  if (event) {
    event.isActive = !event.isActive;
    await updateEvent(req.params.id, { isActive: event.isActive });
    req.session.successMsg = `Event ${event.isActive ? 'diaktifkan' : 'dinonaktifkan'}`;
  }
  res.redirect('/admin/events');
});

app.post('/admin/events/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteEvent(req.params.id);
  req.session.successMsg = 'Event berhasil dihapus!';
  res.redirect('/admin/events');
});

app.get('/chat', isAuth, async (req, res) => {
  const chatSettings = await getChatSettings();
  const messages = await getChatMessages(100);
  const isBlocked = chatSettings.blockedUsers.includes(req.session.userId);
  res.render('chat', { messages, chatSettings, isBlocked, user: res.locals.user });
});

app.post('/chat/send', isAuth, async (req, res) => {
  const { message } = req.body;
  if (!message || message.trim() === '') {
    return res.json({ success: false, message: 'Pesan tidak boleh kosong' });
  }
  
  const chatSettings = await getChatSettings();
  const isBlocked = chatSettings.blockedUsers.includes(req.session.userId);
  
  if (isBlocked && res.locals.user.role !== 'admin') {
    return res.json({ success: false, message: 'Anda diblokir dari chat' });
  }
  
  if (chatSettings.chatMode === 'admin' && res.locals.user.role !== 'admin') {
    return res.json({ success: false, message: 'Mode chat hanya untuk admin saat ini' });
  }
  
  const user = await findById('users', req.session.userId);
  const newMessage = {
    _id: generateCustomId('CHAT'),
    userId: user._id,
    username: user.username,
    message: message.trim(),
    role: user.role,
    createdAt: new Date()
  };
  
  await saveChatMessage(newMessage);
  res.json({ success: true, message: newMessage });
});

app.get('/chat/messages', isAuth, async (req, res) => {
  const messages = await getChatMessages(100);
  res.json({ success: true, messages: deduplicateMessages(messages) });
});

app.get('/admin/chat', isAuth, isAdmin, async (req, res) => {
  const messages = await getChatMessages(200);
  const users = await readDB('users');
  const chatSettings = await getChatSettings();
  res.render('admin_chat', { messages, users, chatSettings, user: res.locals.user });
});

app.post('/admin/chat/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteChatMessage(req.params.id);
  res.json({ success: true });
});

app.post('/admin/chat/clear', isAuth, isAdmin, async (req, res) => {
  await deleteAllChatMessages();
  res.json({ success: true });
});

app.post('/admin/chat/settings', isAuth, isAdmin, async (req, res) => {
  const { chatMode, blockedUsers } = req.body;
  const blockedArray = blockedUsers ? blockedUsers.split(',').map(id => id.trim()) : [];
  await updateChatSettings(chatMode, blockedArray);
  req.session.successMsg = 'Pengaturan chat diperbarui!';
  res.redirect('/admin/chat');
});

app.post('/admin/chat/block/:userId', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const blockedUsers = settings.blockedUsers || [];
  if (!blockedUsers.includes(req.params.userId)) {
    blockedUsers.push(req.params.userId);
    await updateChatSettings(settings.chatMode, blockedUsers);
  }
  res.json({ success: true });
});

app.post('/admin/chat/unblock/:userId', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const blockedUsers = (settings.blockedUsers || []).filter(id => id !== req.params.userId);
  await updateChatSettings(settings.chatMode, blockedUsers);
  res.json({ success: true });
});

// ===== PAKASIR CHECK TRANSACTION =====
app.post('/admin/pakasir/check', isAuth, isAdmin, async (req, res) => {
  try {
    const { order_id, amount } = req.body;
    
    if (!order_id || !amount) {
      return res.status(400).json({ 
        success: false, 
        error: 'order_id dan amount wajib diisi' 
      });
    }
    
    const result = await checkPakasirTransaction(order_id, amount);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

let checkerInterval;
let lastCheckedTime = null;

async function checkMutasi() {
  try {
    const settings = await getSettings();
    if (!settings.autoCheckEnabled) {
      console.log('[MUTASI] Auto check disabled');
      return;
    }
    
    const invoices = await readDB('invoices');
    const pendingInvoices = invoices.filter(i => i.status === 'pending');
    const now = new Date();
    
    console.log(`[MUTASI] ===== CHECKING ${pendingInvoices.length} PENDING INVOICES =====`);
    
    for (const inv of pendingInvoices) {
      if (now > new Date(inv.expiredAt)) {
        inv.status = 'expired';
        await updateById('invoices', inv._id, { $set: inv });
        console.log(`[MUTASI] Invoice ${inv._id} expired`);
        
        if (inv.paymentProvider === 'pakasir' && inv.providerData?.order_id) {
          await cancelPakasirTransaction(inv.providerData.order_id, inv.total);
        }
      }
    }
    
    const updatedInvoices = await readDB('invoices');
    const activePending = updatedInvoices.filter(i => i.status === 'pending' && now < new Date(i.expiredAt));
    
    if (activePending.length === 0) {
      console.log('[MUTASI] No active pending invoices');
      return;
    }
    
    console.log(`[MUTASI] ${activePending.length} active pending invoices`);
    
    const pakasirInvoices = activePending.filter(i => i.paymentProvider === 'pakasir');
    
    if (pakasirInvoices.length === 0) {
      console.log('[MUTASI] No Pakasir invoices pending');
      return;
    }
    
    console.log(`[MUTASI] Checking ${pakasirInvoices.length} Pakasir invoices...`);
    
    for (const inv of pakasirInvoices) {
      const orderId = inv.providerData?.order_id;
      if (!orderId) {
        console.log(`[MUTASI] Invoice ${inv._id} has no order_id`);
        continue;
      }
      
      console.log(`[MUTASI] Checking Pakasir transaction: ${orderId}`);
      
      const result = await checkPakasirTransaction(orderId, inv.total);
      
      if (result.success && result.data) {
        const txData = result.data;
        console.log(`[MUTASI] Transaction status: ${txData.status}`);
        
        if (txData.status === 'completed') {
          console.log(`[MUTASI] ✅ Invoice ${inv._id} PAID!`);
          
          inv.status = 'paid';
          inv.mutationId = orderId;
          inv.paymentDetail = {
            status: txData.status,
            payment_method: txData.payment_method,
            completed_at: txData.completed_at,
            provider: 'pakasir'
          };
          await updateById('invoices', inv._id, { $set: inv });
          
          const user = await findById('users', inv.userId);
          if (user) {
            user.balance = (user.balance || 0) + inv.amount;
            await updateById('users', inv.userId, { $set: user });
            console.log(`[MUTASI] User ${user.username} balance updated: +${inv.amount}`);
          }
          
          const transactions = await readDB('transactions');
          const tx = transactions.find(t => t.reference === inv._id.toString() && t.type === 'deposit' && t.status === 'pending');
          if (tx) {
            tx.status = 'paid';
            tx.paymentDetail = {
              status: txData.status,
              payment_method: txData.payment_method,
              completed_at: txData.completed_at,
              provider: 'pakasir'
            };
            await updateById('transactions', tx._id, { $set: tx });
          }
          
          const channelReplyMarkup = {
            inline_keyboard: [
              [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
            ]
          };
          
          const photoUrl = 'https://cdn.yupra.my.id/yp/u61fubbu.png';
          
          await sendTelegramChannelPhoto(
            photoUrl,
            `🌐 **\n\n` + 
            `✅ *Deposit Berhasil*\n` +
            `User: ${user ? user.username : 'Unknown'}\n` +
            `ID Invoice: ${inv._id}\n` +
            `Order ID: ${orderId}\n` +
            `Jumlah: Rp ${inv.amount.toLocaleString()}\n` +
            `Fee: Rp ${inv.fee.toLocaleString()}\n` +
            `Total: Rp ${inv.total.toLocaleString()}\n` +
            `Metode: Qris Payment\n` +
            `Status: ✅ Sukses\n\n` +
            `_${new Date().toLocaleString('id-ID')}_`,
            channelReplyMarkup
          );
          
          await updateOne('stats', {}, { 
            $inc: { 
              totalDepositAmount: inv.amount, 
              totalDepositFee: inv.fee || 0, 
              totalTransactions: 1 
            } 
          });
          
          const adminChatId = await getAdminChatId();
          if (adminChatId && user) {
            const timeString = new Date().toLocaleString('id-ID', {
              timeZone: 'Asia/Jakarta', 
              day: '2-digit', 
              month: 'long', 
              year: 'numeric',
              hour: '2-digit', 
              minute: '2-digit'
            });
            const message = `🌐 *Notifikasi - ${settings.name}*\n\n` +
              `👤 *Informasi User*\n` +
              `• User: ${user.username} (${user.email})\n` +
              `• Saldo Saat Ini: Rp ${user.balance.toLocaleString('id-ID')}\n\n` +
              `💰 *Informasi Deposit*\n` +
              `• Jumlah: Rp ${inv.amount.toLocaleString('id-ID')}\n` +
              `• Fee: Rp ${inv.fee.toLocaleString('id-ID')}\n` +
              `• Total: Rp ${inv.total.toLocaleString('id-ID')}\n` +
              `• ID Invoice: ${inv._id}\n` +
              `• Order ID: ${orderId}\n` +
              `• Metode: Qris Payment\n` +
              `• Waktu: ${timeString}\n` +
              `• Status: ✅ Paid`;
            await sendTelegramMessage(adminChatId, message);
          }
        } else if (txData.status === 'expired' || txData.status === 'failed') {
          inv.status = 'expired';
          await updateById('invoices', inv._id, { $set: inv });
          console.log(`[MUTASI] Invoice ${inv._id} expired (status: ${txData.status})`);
        }
      } else {
        console.log(`[MUTASI] Failed to check transaction ${orderId}:`, result.error);
      }
    }
    
    console.log('[MUTASI] ===== CHECK COMPLETE =====');
    
  } catch (err) {
    console.error('[MUTASI] Error:', err.response?.data || err.message);
    console.error('[MUTASI] Full error:', err);
  }
}

// ===== TEST AI CONNECTION =====
app.post('/admin/ai/test', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await getSettings();
    const testMessage = req.body.message || 'Halo, siapa kamu?';
    
    if (settings.aiEnabled === false) {
      return res.json({ 
        success: false, 
        message: 'AI sedang dimatikan. Aktifkan terlebih dahulu di Settings.' 
      });
    }

    const response = await axios.get(AI_API_URL, {
      params: {
        prompt: testMessage,
        system: CS_SYSTEM_PROMPT,
        temperature: 0.7
      },
      timeout: 30000
    });

    if (response.data && response.data.status === true && response.data.data) {
      res.json({ 
        success: true, 
        message: '✅ Koneksi AI berhasil!',
        response: response.data.data.response,
        model: 'GPT-OSS 120B'
      });
    } else {
      res.json({ 
        success: false, 
        message: '❌ Gagal koneksi: ' + (response.data?.message || 'Unknown error')
      });
    }
  } catch (error) {
    console.error('[AI] Test error:', error);
    res.json({ 
      success: false, 
      message: '❌ Gagal koneksi: ' + error.message 
    });
  }
});

async function updateStatsOnStartup() {
  const transactions = await readDB('transactions');
  
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;
  
  const stats = await findOne('stats', {});
  if (stats) {
    stats.totalDepositAmount = dAmount;
    stats.totalDepositFee = dFee;
    stats.totalWithdrawAmount = wAmount;
    stats.totalWithdrawFee = wFee;
    stats.totalUsers = totalUsers;
    stats.totalTransactions = totalTransactions;
    await updateById('stats', stats._id, { $set: stats });
  } else {
    await insertOne('stats', {
      _id: 'stats_1',
      totalDepositAmount: dAmount,
      totalDepositFee: dFee,
      totalWithdrawAmount: wAmount,
      totalWithdrawFee: wFee,
      totalUsers,
      totalTransactions
    });
  }
}

function startChecker() {
  if (checkerInterval) clearInterval(checkerInterval);
  getSettings().then(s => {
    if (s.autoCheckEnabled) {
      checkerInterval = setInterval(checkMutasi, s.checkInterval * 1000);
      checkMutasi();
    }
  });
}

setTimeout(async () => {
  await seed();
  await updateStatsOnStartup();
  startChecker();
  startTelegramPolling();
  scheduleAutoBackup();
  scheduleAutoRestart();
}, 2000);

app.listen(PORT, () => console.log(`Server berjalan di http://localhost:${PORT}`));