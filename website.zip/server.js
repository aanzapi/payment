// FILE: server.js
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const unzipper = require('unzipper');
const archiver = require('archiver');
const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);

const app = express();
const PORT = 3000;

// Database paths
const DB_PATH = path.join(__dirname, 'database');
const USERS_FILE = path.join(DB_PATH, 'users.json');
const BUILDS_FILE = path.join(DB_PATH, 'builds.json');
const SETTINGS_FILE = path.join(DB_PATH, 'settings.json');

// Ensure directories exist
fs.ensureDirSync(DB_PATH);
fs.ensureDirSync(path.join(__dirname, 'uploads'));
fs.ensureDirSync(path.join(__dirname, 'projects'));
fs.ensureDirSync(path.join(__dirname, 'output'));
fs.ensureDirSync(path.join(__dirname, 'logs'));
fs.ensureDirSync(path.join(__dirname, 'temp'));
fs.ensureDirSync(path.join(__dirname, 'public/css'));
fs.ensureDirSync(path.join(__dirname, 'public/js'));

// Initialize databases
if (!fs.existsSync(USERS_FILE)) {
  const defaultUsers = [
    { username: 'admin', password: '$2b$10$N9qo8uLOickgx2ZMRZoMy.Mr/.7Lq8Xv2vz5LzX5X5X5X5X5X5X5O', role: 'admin' }
  ];
  fs.writeJsonSync(USERS_FILE, defaultUsers);
}

if (!fs.existsSync(BUILDS_FILE)) {
  fs.writeJsonSync(BUILDS_FILE, []);
}

if (!fs.existsSync(SETTINGS_FILE)) {
  const defaultSettings = {
    maxUploadSize: 50 * 1024 * 1024,
    autoDelete: true,
    buildLimit: 10
  };
  fs.writeJsonSync(SETTINGS_FILE, defaultSettings);
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'azxcrasher-super-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Multer configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.]/g, '_');
    cb(null, `${uuidv4()}-${safeName}`);
  }
});

const settings = fs.readJsonSync(SETTINGS_FILE);

const upload = multer({
  storage: storage,
  limits: { fileSize: settings.maxUploadSize },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
      cb(null, true);
    } else {
      cb(new Error('Hanya file ZIP yang diperbolehkan'));
    }
  }
});

// Auth middleware
const authMiddleware = (req, res, next) => {
  if (req.session && req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
};

// Helper functions
const readDB = (file) => {
  try {
    return fs.readJsonSync(file);
  } catch {
    return [];
  }
};

const writeDB = (file, data) => {
  fs.writeJsonSync(file, data, { spaces: 2 });
};

// Build queue
class BuildQueue {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
  }

  add(buildId) {
    this.queue.push(buildId);
    this.process();
  }

  async process() {
    if (this.isProcessing || this.queue.length === 0) return;
    
    this.isProcessing = true;
    const buildId = this.queue.shift();
    
    try {
      await this.executeBuild(buildId);
    } catch (error) {
      console.error('Build error:', error);
    } finally {
      this.isProcessing = false;
      this.process();
    }
  }

  async executeBuild(buildId) {
    const builds = readDB(BUILDS_FILE);
    const build = builds.find(b => b.id === buildId);
    
    if (!build) return;

    // Update status
    build.status = 'building';
    writeDB(BUILDS_FILE, builds);

    const startTime = Date.now();
    const projectPath = path.join(__dirname, 'projects', buildId);
    const logPath = path.join(__dirname, 'logs', `${buildId}.log`);
    const outputPath = path.join(__dirname, 'output');

    try {
      // Extract zip
      const zipPath = path.join(__dirname, 'uploads', build.uploadedFile);
      await fs.ensureDir(projectPath);
      
      // Extract
      await new Promise((resolve, reject) => {
        fs.createReadStream(zipPath)
          .pipe(unzipper.Extract({ path: projectPath }))
          .on('close', resolve)
          .on('error', reject);
      });

      // Check pubspec.yaml
      const pubspecPath = path.join(projectPath, 'pubspec.yaml');
      if (!fs.existsSync(pubspecPath)) {
        throw new Error('pubspec.yaml tidak ditemukan');
      }

      // Run flutter pub get
      await execAsync('flutter pub get', { cwd: projectPath });

      // Run flutter build apk
      const { stdout, stderr } = await execAsync('flutter build apk --release', { 
        cwd: projectPath,
        maxBuffer: 10 * 1024 * 1024
      });

      // Save log
      fs.writeFileSync(logPath, stdout + '\n' + stderr);

      // Copy APK
      const apkSource = path.join(projectPath, 'build/app/outputs/flutter-apk/app-release.apk');
      if (fs.existsSync(apkSource)) {
        const apkDest = path.join(outputPath, `${buildId}.apk`);
        await fs.copy(apkSource, apkDest);
        build.apkPath = apkDest;
        build.status = 'success';
      } else {
        throw new Error('APK tidak ditemukan');
      }

    } catch (error) {
      build.status = 'failed';
      fs.writeFileSync(logPath, error.message);
      console.error('Build failed:', error);
    }

    build.buildDuration = Date.now() - startTime;
    build.logPath = logPath;
    writeDB(BUILDS_FILE, builds);

    // Cleanup
    if (settings.autoDelete) {
      await fs.remove(projectPath);
      await fs.remove(zipPath);
    }
  }
}

const buildQueue = new BuildQueue();

// Routes
app.get('/login', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect('/dashboard');
  }
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const users = readDB(USERS_FILE);
  const user = users.find(u => u.username === username);

  if (!user) {
    return res.render('login', { error: 'Username tidak ditemukan' });
  }

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    return res.render('login', { error: 'Password salah' });
  }

  req.session.user = { username: user.username, role: user.role };
  res.redirect('/dashboard');
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

app.get('/dashboard', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const total = builds.length;
  const success = builds.filter(b => b.status === 'success').length;
  const failed = builds.filter(b => b.status === 'failed').length;
  const waiting = builds.filter(b => b.status === 'waiting' || b.status === 'building').length;

  // Get latest 10 builds
  const recentBuilds = builds.slice(-10).reverse();

  res.render('dashboard', {
    user: req.session.user,
    stats: { total, success, failed, waiting },
    builds: recentBuilds
  });
});

app.post('/upload', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Tidak ada file yang diupload' });
    }

    const builds = readDB(BUILDS_FILE);
    const settings = readJsonSync(SETTINGS_FILE);

    // Check build limit
    const activeBuilds = builds.filter(b => b.status === 'waiting' || b.status === 'building');
    if (activeBuilds.length >= settings.buildLimit) {
      await fs.remove(req.file.path);
      return res.status(429).json({ error: 'Build limit tercapai' });
    }

    const buildId = uuidv4();
    const build = {
      id: buildId,
      projectName: req.body.projectName || 'Untitled',
      status: 'waiting',
      createdAt: new Date().toISOString(),
      buildDuration: 0,
      apkPath: null,
      logPath: null,
      uploadedFile: req.file.filename
    };

    builds.push(build);
    writeDB(BUILDS_FILE, builds);

    // Add to queue
    buildQueue.add(buildId);

    res.json({ success: true, buildId });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/builds', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  res.json(builds);
});

app.get('/history', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const sortedBuilds = builds.slice().reverse();
  
  res.render('history', {
    user: req.session.user,
    builds: sortedBuilds
  });
});

app.get('/download/apk/:id', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const build = builds.find(b => b.id === req.params.id);

  if (!build || build.status !== 'success' || !build.apkPath) {
    return res.status(404).json({ error: 'APK tidak ditemukan' });
  }

  const apkPath = build.apkPath;
  if (!fs.existsSync(apkPath)) {
    return res.status(404).json({ error: 'File APK tidak ditemukan' });
  }

  res.download(apkPath, `${build.projectName}.apk`);
});

app.get('/download/log/:id', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const build = builds.find(b => b.id === req.params.id);

  if (!build || !build.logPath) {
    return res.status(404).json({ error: 'Log tidak ditemukan' });
  }

  const logPath = build.logPath;
  if (!fs.existsSync(logPath)) {
    return res.status(404).json({ error: 'File log tidak ditemukan' });
  }

  res.download(logPath, `build-${build.id}.log`);
});

app.post('/delete-build/:id', authMiddleware, async (req, res) => {
  const builds = readDB(BUILDS_FILE);
  const index = builds.findIndex(b => b.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({ error: 'Build tidak ditemukan' });
  }

  const build = builds[index];
  
  // Delete files
  if (build.apkPath && fs.existsSync(build.apkPath)) {
    await fs.remove(build.apkPath);
  }
  if (build.logPath && fs.existsSync(build.logPath)) {
    await fs.remove(build.logPath);
  }
  
  const projectPath = path.join(__dirname, 'projects', build.id);
  if (fs.existsSync(projectPath)) {
    await fs.remove(projectPath);
  }

  const uploadPath = path.join(__dirname, 'uploads', build.uploadedFile);
  if (fs.existsSync(uploadPath)) {
    await fs.remove(uploadPath);
  }

  builds.splice(index, 1);
  writeDB(BUILDS_FILE, builds);

  res.json({ success: true });
});

// Serve static files
app.use('/css', express.static(path.join(__dirname, 'public/css')));
app.use('/js', express.static(path.join(__dirname, 'public/js')));

// Start server
app.listen(PORT, () => {
  console.log(`AzXCrasher Builder V1 running on port ${PORT}`);
});