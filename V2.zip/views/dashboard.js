// FILE: views/dashboard.ejs (upgrade with log streaming & mobile responsive)
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>AzXCrasher Builder V2 - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Inter', sans-serif; }
        .glass {
            background: rgba(17, 24, 39, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .glass-light {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }
        body {
            background: #0a0a0f;
            min-height: 100vh;
        }
        .sidebar {
            background: rgba(17, 24, 39, 0.9);
            backdrop-filter: blur(20px);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            transition: transform 0.3s ease;
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-success { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
        .status-failed { background: rgba(239, 68, 68, 0.15); color: #ef4444; }
        .status-building { background: rgba(59, 130, 246, 0.15); color: #3b82f6; animation: pulse 1.5s infinite; }
        .status-waiting { background: rgba(234, 179, 8, 0.15); color: #eab308; }
        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(0.95); }
        }
        .upload-zone {
            border: 2px dashed rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        .upload-zone:hover {
            border-color: rgba(99, 102, 241, 0.5);
            background: rgba(99, 102, 241, 0.05);
        }
        .upload-zone.dragover {
            border-color: #6366f1;
            background: rgba(99, 102, 241, 0.1);
        }
        .log-container {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 16px;
            max-height: 400px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            color: #a0aec0;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .log-container::-webkit-scrollbar {
            width: 6px;
        }
        .log-container::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 3px;
        }
        .log-container::-webkit-scrollbar-thumb {
            background: rgba(99, 102, 241, 0.5);
            border-radius: 3px;
        }
        .log-line {
            padding: 2px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.02);
        }
        .log-line.success { color: #22c55e; }
        .log-line.error { color: #ef4444; }
        .log-line.info { color: #3b82f6; }
        .log-line.warning { color: #eab308; }
        .mobile-menu-btn {
            display: none;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                left: 0;
                top: 0;
                height: 100%;
                width: 280px;
                transform: translateX(-100%);
                z-index: 1000;
                transition: transform 0.3s ease;
            }
            .sidebar.open {
                transform: translateX(0);
            }
            .sidebar-overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999;
            }
            .sidebar-overlay.show {
                display: block;
            }
            .mobile-menu-btn {
                display: block;
            }
            .ml-64 {
                margin-left: 0 !important;
            }
            .stats-grid {
                grid-template-columns: 1fr 1fr !important;
                gap: 12px !important;
            }
            .upload-section {
                padding: 16px !important;
            }
            .table-container {
                overflow-x: auto;
            }
            .table-container table {
                min-width: 600px;
            }
            .log-container {
                max-height: 250px;
                font-size: 10px;
            }
        }
        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr 1fr !important;
                gap: 8px !important;
            }
            .stat-card {
                padding: 12px !important;
            }
            .stat-card p.text-3xl {
                font-size: 1.5rem !important;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div class="sidebar fixed left-0 top-0 h-full w-64 p-6 z-50" id="sidebar">
            <div class="flex items-center justify-between mb-8">
                <div>
                    <h1 class="text-xl font-bold text-white">AzXCrasher</h1>
                    <p class="text-gray-500 text-xs mt-1">Builder V2</p>
                </div>
                <button onclick="toggleSidebar()" class="md:hidden text-gray-400 hover:text-white">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>

            <nav class="space-y-2">
                <a href="/dashboard" class="flex items-center space-x-3 px-4 py-3 bg-indigo-600/20 text-indigo-400 rounded-lg transition-all">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="/history" class="flex items-center space-x-3 px-4 py-3 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    <span>History</span>
                </a>
                <a href="/logout" class="flex items-center space-x-3 px-4 py-3 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors mt-8">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    <span>Logout</span>
                </a>
            </nav>

            <div class="absolute bottom-6 left-6 right-6">
                <div class="glass rounded-lg p-4">
                    <p class="text-gray-400 text-xs">Signed in as</p>
                    <p class="text-white text-sm font-medium"><%= user.username %></p>
                    <span class="text-xs text-gray-500"><%= user.role %></span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-4 md:p-8 ml-0 md:ml-64">
            <!-- Mobile Header -->
            <div class="flex items-center justify-between mb-6 md:hidden">
                <button onclick="toggleSidebar()" class="text-white p-2">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
                <h1 class="text-lg font-bold text-white">AzXCrasher</h1>
                <div></div>
            </div>

            <div class="max-w-7xl mx-auto">
                <!-- Header -->
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                    <div>
                        <h2 class="text-2xl font-bold text-white">Dashboard</h2>
                        <p class="text-gray-400 text-sm">Monitor your Flutter builds</p>
                    </div>
                    <div class="flex items-center space-x-3 w-full md:w-auto">
                        <span class="text-gray-400 text-xs md:text-sm" id="lastUpdate">Last update: just now</span>
                        <button onclick="refreshBuilds()" class="px-3 py-1.5 md:px-4 md:py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs md:text-sm flex-shrink-0">
                            Refresh
                        </button>
                    </div>
                </div>

                <!-- Stats -->
                <div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6 mb-6 stats-grid">
                    <div class="glass rounded-xl p-4 md:p-6 card-hover stat-card">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-xs md:text-sm">Total Builds</p>
                                <p class="text-2xl md:text-3xl font-bold text-white mt-1" id="totalBuilds"><%= stats.total %></p>
                            </div>
                            <div class="w-10 h-10 md:w-12 md:h-12 bg-indigo-600/20 rounded-lg flex items-center justify-center">
                                <svg class="w-5 h-5 md:w-6 md:h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="glass rounded-xl p-4 md:p-6 card-hover stat-card">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-xs md:text-sm">Success</p>
                                <p class="text-2xl md:text-3xl font-bold text-green-400 mt-1" id="successBuilds"><%= stats.success %></p>
                            </div>
                            <div class="w-10 h-10 md:w-12 md:h-12 bg-green-600/20 rounded-lg flex items-center justify-center">
                                <svg class="w-5 h-5 md:w-6 md:h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="glass rounded-xl p-4 md:p-6 card-hover stat-card">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-xs md:text-sm">Failed</p>
                                <p class="text-2xl md:text-3xl font-bold text-red-400 mt-1" id="failedBuilds"><%= stats.failed %></p>
                            </div>
                            <div class="w-10 h-10 md:w-12 md:h-12 bg-red-600/20 rounded-lg flex items-center justify-center">
                                <svg class="w-5 h-5 md:w-6 md:h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="glass rounded-xl p-4 md:p-6 card-hover stat-card">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-400 text-xs md:text-sm">In Queue</p>
                                <p class="text-2xl md:text-3xl font-bold text-yellow-400 mt-1" id="waitingBuilds"><%= stats.waiting %></p>
                            </div>
                            <div class="w-10 h-10 md:w-12 md:h-12 bg-yellow-600/20 rounded-lg flex items-center justify-center">
                                <svg class="w-5 h-5 md:w-6 md:h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upload Section -->
                <div class="glass rounded-xl p-4 md:p-8 mb-6 upload-section">
                    <h3 class="text-lg font-semibold text-white mb-4">Upload New Project</h3>
                    <form id="uploadForm" enctype="multipart/form-data">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-gray-300 text-sm font-medium mb-2">Project Name</label>
                                <input 
                                    type="text" 
                                    name="projectName" 
                                    id="projectName"
                                    class="w-full px-4 py-2 bg-gray-800/50 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-indigo-500 transition-colors text-sm md:text-base"
                                    placeholder="My Flutter App"
                                    required
                                >
                            </div>
                            <div>
                                <div class="upload-zone rounded-lg p-6 md:p-8 text-center cursor-pointer" id="uploadZone">
                                    <input type="file" name="file" id="fileInput" accept=".zip" class="hidden" required>
                                    <div class="flex flex-col items-center">
                                        <svg class="w-10 h-10 md:w-12 md:h-12 text-gray-500 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                        </svg>
                                        <p class="text-gray-400 text-sm md:text-base">Drop your Flutter project ZIP here</p>
                                        <p class="text-gray-600 text-xs md:text-sm mt-1">or click to browse</p>
                                        <p class="text-gray-600 text-xs mt-2" id="fileName">No file selected</p>
                                    </div>
                                </div>
                            </div>
                            <button 
                                type="submit"
                                class="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition-all duration-300 text-sm md:text-base"
                            >
                                Start Build
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Recent Builds -->
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-white mb-4">Recent Builds</h3>
                    <div class="glass rounded-xl overflow-hidden table-container">
                        <div class="overflow-x-auto">
                            <table class="w-full">
                                <thead>
                                    <tr class="border-b border-gray-800">
                                        <th class="px-3 md:px-6 py-3 md:py-4 text-left text-xs font-medium text-gray-500 uppercase">Project</th>
                                        <th class="px-3 md:px-6 py-3 md:py-4 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                        <th class="px-3 md:px-6 py-3 md:py-4 text-left text-xs font-medium text-gray-500 uppercase hidden sm:table-cell">Date</th>
                                        <th class="px-3 md:px-6 py-3 md:py-4 text-left text-xs font-medium text-gray-500 uppercase hidden md:table-cell">Duration</th>
                                        <th class="px-3 md:px-6 py-3 md:py-4 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="buildsTable">
                                    <% if (builds && builds.length > 0) { %>
                                        <% builds.forEach(build => { %>
                                            <tr class="border-b border-gray-800/50" id="build-row-<%= build.id %>">
                                                <td class="px-3 md:px-6 py-3 md:py-4 text-sm text-white"><%= build.projectName %></td>
                                                <td class="px-3 md:px-6 py-3 md:py-4">
                                                    <span class="status-badge status-<%= build.status %>" id="status-<%= build.id %>">
                                                        <%= build.status %>
                                                    </span>
                                                </td>
                                                <td class="px-3 md:px-6 py-3 md:py-4 text-sm text-gray-400 hidden sm:table-cell">
                                                    <%= new Date(build.createdAt).toLocaleString() %>
                                                </td>
                                                <td class="px-3 md:px-6 py-3 md:py-4 text-sm text-gray-400 hidden md:table-cell">
                                                    <% if (build.buildDuration > 0) { %>
                                                        <%= Math.round(build.buildDuration / 1000) %>s
                                                    <% } else { %>
                                                        -
                                                    <% } %>
                                                </td>
                                                <td class="px-3 md:px-6 py-3 md:py-4">
                                                    <div class="flex flex-wrap gap-1 md:gap-2">
                                                        <% if (build.status === 'success') { %>
                                                            <a href="/download/apk/<%= build.id %>" class="text-indigo-400 hover:text-indigo-300 text-xs md:text-sm">APK</a>
                                                        <% } %>
                                                        <% if (build.status === 'failed' || build.status === 'success') { %>
                                                            <a href="/download/log/<%= build.id %>" class="text-gray-400 hover:text-gray-300 text-xs md:text-sm">Log</a>
                                                        <% } %>
                                                        <% if (build.status === 'building' || build.status === 'waiting') { %>
                                                            <button onclick="viewLog('<%= build.id %>')" class="text-blue-400 hover:text-blue-300 text-xs md:text-sm">Logs</button>
                                                        <% } %>
                                                    </div>
                                                </td>
                                            </tr>
                                        <% }) %>
                                    <% } else { %>
                                        <tr>
                                            <td colspan="5" class="px-6 py-8 text-center text-gray-500">No builds yet</td>
                                        </tr>
                                    <% } %>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Live Log Viewer -->
                <div>
                    <h3 class="text-lg font-semibold text-white mb-4">Live Build Log</h3>
                    <div class="glass rounded-xl p-4">
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-sm text-gray-400" id="logStatus">Waiting for build...</span>
                            <button onclick="clearLog()" class="text-xs text-gray-500 hover:text-gray-300">Clear</button>
                        </div>
                        <div class="log-container" id="logContainer">
                            <div class="log-line info">🟢 Ready for logs</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentBuildId = null;
        let eventSource = null;
        let logLines = [];

        // Sidebar toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            sidebar.classList.toggle('open');
            overlay.classList.toggle('show');
        }

        // Upload form
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        const fileName = document.getElementById('fileName');
        const uploadForm = document.getElementById('uploadForm');

        uploadZone.addEventListener('click', () => fileInput.click());

        fileInput.addEventListener('change', (e) => {
            if (e.target.files[0]) {
                fileName.textContent = e.target.files[0].name;
            }
        });

        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.classList.add('dragover');
        });

        uploadZone.addEventListener('dragleave', () => {
            uploadZone.classList.remove('dragover');
        });

        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
            if (e.dataTransfer.files[0]) {
                fileInput.files = e.dataTransfer.files;
                fileName.textContent = e.dataTransfer.files[0].name;
            }
        });

        uploadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(uploadForm);
            const file = fileInput.files[0];

            if (!file) {
                alert('Please select a file');
                return;
            }

            if (!file.name.endsWith('.zip')) {
                alert('Please upload a ZIP file');
                return;
            }

            const submitBtn = uploadForm.querySelector('button[type="submit"]');
            submitBtn.textContent = 'Uploading...';
            submitBtn.disabled = true;

            try {
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (response.ok) {
                    alert('Build started successfully!');
                    uploadForm.reset();
                    fileName.textContent = 'No file selected';
                    refreshBuilds();
                    // Connect to log stream
                    connectToLogStream(result.buildId);
                } else {
                    alert('Error: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                alert('Upload failed: ' + error.message);
            } finally {
                submitBtn.textContent = 'Start Build';
                submitBtn.disabled = false;
            }
        });

        // Connect to log stream
        function connectToLogStream(buildId) {
            if (eventSource) {
                eventSource.close();
            }
            
            currentBuildId = buildId;
            logLines = [];
            document.getElementById('logContainer').innerHTML = '';
            document.getElementById('logStatus').textContent = '📡 Connecting to build stream...';

            eventSource = new EventSource(`/stream/${buildId}`);
            
            eventSource.onmessage = function(event) {
                const data = JSON.parse(event.data);
                addLogLine(data.message, 'info');
                document.getElementById('logStatus').textContent = `📡 Streaming build ${buildId.substring(0, 8)}...`;
            };

            eventSource.onerror = function() {
                document.getElementById('logStatus').textContent = '⚠️ Stream disconnected';
                eventSource.close();
            };

            eventSource.addEventListener('close', function() {
                document.getElementById('logStatus').textContent = '✅ Build complete';
                eventSource.close();
            });
        }

        function addLogLine(message, type = 'info') {
            const container = document.getElementById('logContainer');
            const line = document.createElement('div');
            line.className = `log-line ${type}`;
            line.textContent = message;
            container.appendChild(line);
            container.scrollTop = container.scrollHeight;
        }

        function clearLog() {
            document.getElementById('logContainer').innerHTML = '';
            document.getElementById('logStatus').textContent = 'Log cleared';
        }

        function viewLog(buildId) {
            connectToLogStream(buildId);
        }

        // Refresh builds
        let refreshInterval = setInterval(refreshBuilds, 5000);

        function refreshBuilds() {
            fetch('/api/builds')
                .then(res => res.json())
                .then(data => {
                    const total = data.length;
                    const success = data.filter(b => b.status === 'success').length;
                    const failed = data.filter(b => b.status === 'failed').length;
                    const waiting = data.filter(b => b.status === 'waiting' || b.status === 'building').length;

                    document.getElementById('totalBuilds').textContent = total;
                    document.getElementById('successBuilds').textContent = success;
                    document.getElementById('failedBuilds').textContent = failed;
                    document.getElementById('waitingBuilds').textContent = waiting;

                    const tableBody = document.getElementById('buildsTable');
                    const recentBuilds = data.slice(-10).reverse();
                    
                    if (recentBuilds.length === 0) {
                        tableBody.innerHTML = `
                            <tr>
                                <td colspan="5" class="px-6 py-8 text-center text-gray-500">No builds yet</td>
                            </tr>
                        `;
                        return;
                    }

                    tableBody.innerHTML = recentBuilds.map(build => `
                        <tr class="border-b border-gray-800/50" id="build-row-${build.id}">
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm text-white">${build.projectName}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4">
                                <span class="status-badge status-${build.status}" id="status-${build.id}">${build.status}</span>
                            </td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm text-gray-400 hidden sm:table-cell">${new Date(build.createdAt).toLocaleString()}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm text-gray-400 hidden md:table-cell">
                                ${build.buildDuration > 0 ? Math.round(build.buildDuration / 1000) + 's' : '-'}
                            </td>
                            <td class="px-3 md:px-6 py-3 md:py-4">
                                <div class="flex flex-wrap gap-1 md:gap-2">
                                    ${build.status === 'success' ? 
                                        `<a href="/download/apk/${build.id}" class="text-indigo-400 hover:text-indigo-300 text-xs md:text-sm">APK</a>` : 
                                        ''
                                    }
                                    ${build.status === 'failed' || build.status === 'success' ?
                                        `<a href="/download/log/${build.id}" class="text-gray-400 hover:text-gray-300 text-xs md:text-sm">Log</a>` :
                                        ''
                                    }
                                    ${build.status === 'building' || build.status === 'waiting' ?
                                        `<button onclick="viewLog('${build.id}')" class="text-blue-400 hover:text-blue-300 text-xs md:text-sm">Logs</button>` :
                                        ''
                                    }
                                </div>
                            </td>
                        </tr>
                    `).join('');

                    document.getElementById('lastUpdate').textContent = 'Last update: just now';
                })
                .catch(err => console.error('Refresh error:', err));
        }

        // Close SSE on page unload
        window.addEventListener('beforeunload', function() {
            if (eventSource) {
                eventSource.close();
            }
        });

        // Initial refresh
        refreshBuilds();
    </script>
</body>
</html>