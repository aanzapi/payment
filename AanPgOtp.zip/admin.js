// admin.js - Script untuk membuat akun admin
// Jalankan dengan: node admin.js

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Konfigurasi admin
const ADMIN_CONFIG = {
  username: 'AanAdmin',
  email: 'aancuy@gmail.com',
  password: 'frkhnsptra23',
  role: 'admin',
  balance: 0,
  suspended: false,
  ewallet: '',
  accountNumber: '',
  accountName: ''
};

// Path ke file data
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// Fungsi hash password (sama dengan di server.js)
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

// Fungsi generate ID
function generateId() {
  return crypto.randomBytes(12).toString('hex');
}

// Main function
async function createAdmin() {
  try {
    // Pastikan folder data ada
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      console.log('� Folder data created');
    }

    // Baca file users.json
    let users = [];
    if (fs.existsSync(USERS_FILE)) {
      const data = fs.readFileSync(USERS_FILE, 'utf8');
      users = JSON.parse(data);
      console.log(`� Found ${users.length} existing users`);
    } else {
      console.log('� No existing users file, creating new one');
    }

    // Cek apakah admin sudah ada
    const existingAdmin = users.find(u => u.role === 'admin');
    if (existingAdmin) {
      console.log('⚠️ Admin already exists:');
      console.log(`   Username: ${existingAdmin.username}`);
      console.log(`   Email: ${existingAdmin.email}`);
      console.log(`   Role: ${existingAdmin.role}`);
      console.log('\n❌ Cannot create duplicate admin.');
      console.log('� If you want to update admin credentials, delete the existing admin first.');
      return;
    }

    // Cek apakah username sudah digunakan
    const existingUsername = users.find(u => u.username === ADMIN_CONFIG.username.toLowerCase());
    if (existingUsername) {
      console.log(`❌ Username "${ADMIN_CONFIG.username}" already exists.`);
      return;
    }

    // Cek apakah email sudah digunakan
    const existingEmail = users.find(u => u.email === ADMIN_CONFIG.email.toLowerCase());
    if (existingEmail) {
      console.log(`❌ Email "${ADMIN_CONFIG.email}" already exists.`);
      return;
    }

    // Buat admin baru
    const newAdmin = {
      _id: generateId(),
      username: ADMIN_CONFIG.username.toLowerCase(),
      email: ADMIN_CONFIG.email.toLowerCase(),
      password: hashPassword(ADMIN_CONFIG.password),
      role: ADMIN_CONFIG.role,
      balance: ADMIN_CONFIG.balance,
      suspended: ADMIN_CONFIG.suspended,
      ewallet: ADMIN_CONFIG.ewallet,
      accountNumber: ADMIN_CONFIG.accountNumber,
      accountName: ADMIN_CONFIG.accountName,
      createdAt: new Date()
    };

    // Tambahkan ke array
    users.push(newAdmin);

    // Simpan ke file
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    console.log('\n✅ ADMIN CREATED SUCCESSFULLY!');
    console.log('====================================');
    console.log(`� Username: ${ADMIN_CONFIG.username}`);
    console.log(`� Email: ${ADMIN_CONFIG.email}`);
    console.log(`� Password: ${ADMIN_CONFIG.password}`);
    console.log(`� ID: ${newAdmin._id}`);
    console.log(`� Created: ${newAdmin.createdAt.toLocaleString('id-ID')}`);
    console.log('====================================');
    console.log('\n� Please login with these credentials and change password immediately!');

  } catch (error) {
    console.error('❌ Error creating admin:', error.message);
    console.error(error.stack);
  }
}

// Jalankan
createAdmin();
