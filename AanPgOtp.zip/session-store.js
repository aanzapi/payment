// ession-store.js
const fs = require('fs');
const path = require('path');

class FileSessionStore {
  constructor() {
    this.sessionFile = path.join(__dirname, 'data', 'sessions.json');
    this.sessions = {};
    this.loadSessions();
  }

  loadSessions() {
    try {
      if (fs.existsSync(this.sessionFile)) {
        const data = fs.readFileSync(this.sessionFile, 'utf8');
        this.sessions = JSON.parse(data);
        console.log(`[SESSION] Loaded ${Object.keys(this.sessions).length} sessions`);
      } else {
        this.sessions = {};
        this.saveSessions();
      }
    } catch (error) {
      console.error('[SESSION] Error loading sessions:', error);
      this.sessions = {};
    }
  }

  saveSessions() {
    try {
      fs.writeFileSync(this.sessionFile, JSON.stringify(this.sessions, null, 2));
    } catch (error) {
      console.error('[SESSION] Error saving sessions:', error);
    }
  }

  get(sessionId) {
    return this.sessions[sessionId] || null;
  }

  set(sessionId, data) {
    this.sessions[sessionId] = data;
    this.saveSessions();
  }

  destroy(sessionId) {
    delete this.sessions[sessionId];
    this.saveSessions();
  }

  touch(sessionId) {
    if (this.sessions[sessionId]) {
      this.sessions[sessionId].lastAccess = Date.now();
      this.saveSessions();
    }
  }

  clearExpired(maxAge = 24 * 60 * 60 * 1000) {
    const now = Date.now();
    let expired = 0;
    for (const [id, data] of Object.entries(this.sessions)) {
      if (data.lastAccess && (now - data.lastAccess) > maxAge) {
        delete this.sessions[id];
        expired++;
      }
    }
    if (expired > 0) {
      this.saveSessions();
      console.log(`[SESSION] Cleared ${expired} expired sessions`);
    }
  }
}

module.exports = FileSessionStore;
