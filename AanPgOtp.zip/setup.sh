#!/bin/bash

# ============================================
# AZX Gateway - Full Setup Script
# ============================================

set -e

# Warna untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   AZX Gateway - Full Installation Script  ${NC}"
echo -e "${BLUE}============================================${NC}"

# ============================================
# 1. Cek Node.js
# ============================================
echo -e "\n${YELLOW}[1/6] Checking Node.js...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo -e "${GREEN}✓ Node.js already installed: $NODE_VERSION${NC}"
else
    echo -e "${YELLOW}⚠ Node.js not found. Installing Node.js 20.x...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
    echo -e "${GREEN}✓ Node.js installed successfully${NC}"
fi

# ============================================
# 2. Install NPM Dependencies
# ============================================
echo -e "\n${YELLOW}[2/6] Installing NPM dependencies...${NC}"
npm install
echo -e "${GREEN}✓ NPM dependencies installed${NC}"

# ============================================
# 3. Cek & Install Flutter
# ============================================
echo -e "\n${YELLOW}[3/6] Checking Flutter...${NC}"

FLUTTER_DIR="/opt/flutter"
FLUTTER_CMD="$FLUTTER_DIR/bin/flutter"

if command -v flutter &> /dev/null; then
    FLUTTER_VERSION=$(flutter --version | head -n1)
    echo -e "${GREEN}✓ Flutter already installed: $FLUTTER_VERSION${NC}"
elif [ -f "$FLUTTER_CMD" ]; then
    echo -e "${GREEN}✓ Flutter found at $FLUTTER_DIR${NC}"
    export PATH="$PATH:$FLUTTER_DIR/bin"
else
    echo -e "${YELLOW}⚠ Flutter not found. Installing Flutter...${NC}"
    
    # Install prerequisites
    sudo apt-get update
    sudo apt-get install -y curl git unzip xz-utils zip libglu1-mesa clang cmake ninja-build pkg-config libgtk-3-dev
    
    # Download Flutter
    sudo git clone https://github.com/flutter/flutter.git -b stable $FLUTTER_DIR
    sudo chmod -R 755 $FLUTTER_DIR
    
    export PATH="$PATH:$FLUTTER_DIR/bin"
    
    # Add to bashrc
    echo "export PATH=\"\$PATH:$FLUTTER_DIR/bin\"" >> ~/.bashrc
    
    echo -e "${GREEN}✓ Flutter installed successfully${NC}"
fi

# ============================================
# 4. Install Android SDK (for Flutter build)
# ============================================
echo -e "\n${YELLOW}[4/6] Checking Android SDK...${NC}"

ANDROID_SDK_DIR="/opt/android-sdk"
if [ -d "$ANDROID_SDK_DIR" ]; then
    echo -e "${GREEN}✓ Android SDK already installed${NC}"
else
    echo -e "${YELLOW}⚠ Android SDK not found. Installing...${NC}"
    
    sudo apt-get install -y openjdk-11-jdk wget unzip
    
    sudo mkdir -p $ANDROID_SDK_DIR
    sudo chmod 755 $ANDROID_SDK_DIR
    
    # Download command line tools
    cd /tmp
    wget https://dl.google.com/android/repository/commandlinetools-linux-latest.zip
    unzip commandlinetools-linux-latest.zip
    sudo mv cmdline-tools $ANDROID_SDK_DIR/
    
    # Set permissions
    sudo chmod -R 755 $ANDROID_SDK_DIR
    
    # Accept licenses
    echo -e "${YELLOW}Accepting Android SDK licenses...${NC}"
    yes | $ANDROID_SDK_DIR/cmdline-tools/bin/sdkmanager --licenses > /dev/null 2>&1 || true
    
    # Install platform tools
    $ANDROID_SDK_DIR/cmdline-tools/bin/sdkmanager "platform-tools" "platforms;android-33" "build-tools;33.0.0" > /dev/null 2>&1
    
    echo -e "${GREEN}✓ Android SDK installed${NC}"
fi

# ============================================
# 5. Setup Flutter Environment
# ============================================
echo -e "\n${YELLOW}[5/6] Setting up Flutter environment...${NC}"

# Set ANDROID_HOME
if [ -d "$ANDROID_SDK_DIR" ]; then
    export ANDROID_HOME=$ANDROID_SDK_DIR
    export PATH="$PATH:$ANDROID_HOME/platform-tools"
    echo "export ANDROID_HOME=$ANDROID_SDK_DIR" >> ~/.bashrc
    echo "export PATH=\"\$PATH:\$ANDROID_HOME/platform-tools\"" >> ~/.bashrc
fi

# Run flutter doctor to setup
if [ -f "$FLUTTER_CMD" ]; then
    echo -e "${YELLOW}Running flutter doctor...${NC}"
    $FLUTTER_CMD doctor > /dev/null 2>&1 || true
    $FLUTTER_CMD precache > /dev/null 2>&1
    
    # Accept Android licenses
    yes | $FLUTTER_CMD doctor --android-licenses > /dev/null 2>&1 || true
    
    echo -e "${GREEN}✓ Flutter environment configured${NC}"
fi

# ============================================
# 6. Create necessary directories
# ============================================
echo -e "\n${YELLOW}[6/6] Creating project directories...${NC}"

# Create data directory
mkdir -p data

# Create builds directory
mkdir -p builds/uploads
mkdir -p builds/results
mkdir -p builds/temp

# Create public directory
mkdir -p public

# Create views directory (if not exists)
mkdir -p views
mkdir -p views/partials

# Set permissions
chmod -R 755 data
chmod -R 755 builds

echo -e "${GREEN}✓ Directories created${NC}"

# ============================================
# Installation Complete
# ============================================
echo -e "\n${BLUE}============================================${NC}"
echo -e "${GREEN}✅ INSTALLATION COMPLETE!${NC}"
echo -e "${BLUE}============================================${NC}"
echo -e ""
echo -e "${YELLOW}To start the server:${NC}"
echo -e "  npm start"
echo -e ""
echo -e "${YELLOW}To run in development mode:${NC}"
echo -e "  npm run dev"
echo -e ""
echo -e "${YELLOW}Flutter path:${NC}"
echo -e "  $FLUTTER_DIR"
echo -e ""
echo -e "${YELLOW}To verify Flutter installation:${NC}"
echo -e "  $FLUTTER_CMD doctor"
echo -e ""
echo -e "${BLUE}============================================${NC}"