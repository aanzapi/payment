require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MemoryStore = require('memorystore')(session);
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const fs = require('fs');
const fsPromises = require('fs').promises;
const archiver = require('archiver');
const FormData = require('form-data');
const cron = require('node-cron');
const multer = require('multer');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const QRCode = require('qrcode');
const AdmZip = require('adm-zip');

const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;

// ===================== KONSTANTA =====================
const RUMAHOTP_API_KEY = 'rk-dev-sol08R6qixrUv2MU4jfSzaLostotmwgV';
const RUMAHOTP_BASE_URL = 'https://www.rumahotp.io/api/v2';
const OTP_ADMIN_FEE = 200;
const BUILD_COST = 1000;
const BUILD_LIMIT = 5;
const BUILD_EXPIRY_HOURS = 1;
const LIMIT_PACKAGES = [
  { limit: 5, price: 1000, pricePerLimit: 200 },
  { limit: 10, price: 1800, pricePerLimit: 180, discount: '10%' },
  { limit: 25, price: 4000, pricePerLimit: 160, discount: '20%' },
  { limit: 50, price: 7500, pricePerLimit: 150, discount: '25%' },
  { limit: 100, price: 14000, pricePerLimit: 140, discount: '30%' }
];
// ===================== DIREKTORI & DATABASE =====================
const DATA_DIR = path.join(__dirname, 'data');
const BUILDS_DIR = path.join(__dirname, 'builds');
const BUILDS_UPLOAD_DIR = path.join(BUILDS_DIR, 'uploads');
const BUILDS_RESULT_DIR = path.join(BUILDS_DIR, 'results');
const BUILDS_TEMP_DIR = path.join(BUILDS_DIR, 'temp');

const DB_FILES = {
  users: 'users.json',
  invoices: 'invoices.json',
  transactions: 'transactions.json',
  withdrawals: 'withdrawals.json',
  apiKeys: 'apikeys.json',
  settings: 'settings.json',
  stats: 'stats.json',
  otpOrders: 'otp_orders.json',
  notifications: 'notifications.json',
  events: 'events.json',
  chatMessages: 'chat_messages.json',
  flutterBuilds: 'flutter_builds.json'
};

// ===================== INISIALISASI FOLDER =====================
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(BUILDS_DIR)) fs.mkdirSync(BUILDS_DIR, { recursive: true });
if (!fs.existsSync(BUILDS_UPLOAD_DIR)) fs.mkdirSync(BUILDS_UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(BUILDS_RESULT_DIR)) fs.mkdirSync(BUILDS_RESULT_DIR, { recursive: true });
if (!fs.existsSync(BUILDS_TEMP_DIR)) fs.mkdirSync(BUILDS_TEMP_DIR, { recursive: true });

for (const [key, filename] of Object.entries(DB_FILES)) {
  const filepath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filepath)) fs.writeFileSync(filepath, JSON.stringify([], null, 2));
}

// ===================== FLUTTER CHECK =====================
const FLUTTER_PATH = '/opt/flutter/bin/flutter';
const hasFlutter = fs.existsSync(FLUTTER_PATH);
if (!hasFlutter) {
  console.warn('⚠️ Flutter tidak ditemukan! Fitur Flutter Builder tidak akan berfungsi.');
  console.warn('   Jalankan: ./setup_flutter_only.sh untuk menginstall Flutter');
}

// ===================== MULTER UPLOAD =====================
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, BUILDS_UPLOAD_DIR),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '.zip');
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) cb(null, true);
    else cb(new Error('Hanya file ZIP yang diperbolehkan'));
  }
});

// ===================== START ID =====================
const startId = {
  apikey: 'AZX',
  invoice: 'INV',
  withdraw: 'WD',
  transaction: 'TRX',
  otp: 'OTP',
  event: 'EVT',
  chat: 'CHT'
};

// ===================== FUNGSI DATABASE =====================
async function readDB(collection) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    const data = await fsPromises.readFile(filepath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${collection}:`, error);
    return [];
  }
}

async function writeDB(collection, data) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    await fsPromises.writeFile(filepath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Error writing ${collection}:`, error);
    return false;
  }
}

async function findOne(collection, query) {
  const data = await readDB(collection);
  return data.find(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  });
}

async function find(collection, query = {}) {
  const data = await readDB(collection);
  if (Object.keys(query).length === 0) return data;
  return data.filter(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  });
}

async function findById(collection, id) {
  const data = await readDB(collection);
  return data.find(item => item._id === id);
}

async function insertOne(collection, document) {
  const data = await readDB(collection);
  data.push(document);
  await writeDB(collection, data);
  return document;
}

async function updateOne(collection, query, update, options = {}) {
  const data = await readDB(collection);
  let updated = false;
  for (let i = 0; i < data.length; i++) {
    let match = true;
    for (const [key, value] of Object.entries(query)) {
      if (data[i][key] !== value) { match = false; break; }
    }
    if (match) {
      if (update.$set) Object.assign(data[i], update.$set);
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      updated = true;
      break;
    }
  }
  if (updated || options.upsert) {
    await writeDB(collection, data);
    return { modifiedCount: updated ? 1 : 0 };
  }
  return { modifiedCount: 0 };
}

async function updateById(collection, id, update) {
  const data = await readDB(collection);
  for (let i = 0; i < data.length; i++) {
    if (data[i]._id === id) {
      if (update.$set) Object.assign(data[i], update.$set);
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      await writeDB(collection, data);
      return true;
    }
  }
  return false;
}

async function deleteOne(collection, query) {
  const data = await readDB(collection);
  let deleted = false;
  for (let i = 0; i < data.length; i++) {
    let match = true;
    for (const [key, value] of Object.entries(query)) {
      if (data[i][key] !== value) { match = false; break; }
    }
    if (match) {
      data.splice(i, 1);
      deleted = true;
      break;
    }
  }
  if (deleted) {
    await writeDB(collection, data);
    return { deletedCount: 1 };
  }
  return { deletedCount: 0 };
}

async function deleteMany(collection, query) {
  const data = await readDB(collection);
  let deletedCount = 0;
  if (Object.keys(query).length === 0) {
    deletedCount = data.length;
    await writeDB(collection, []);
  } else {
    for (let i = data.length - 1; i >= 0; i--) {
      let match = true;
      for (const [key, value] of Object.entries(query)) {
        if (data[i][key] !== value) { match = false; break; }
      }
      if (match) {
        data.splice(i, 1);
        deletedCount++;
      }
    }
    await writeDB(collection, data);
  }
  return { deletedCount };
}

async function countDocuments(collection, query = {}) {
  const data = await readDB(collection);
  if (Object.keys(query).length === 0) return data.length;
  return data.filter(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  }).length;
}

async function createWithRetry(collection, data, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      if (!data._id) {
        if (collection === 'invoices') data._id = generateCustomId(startId.invoice);
        else if (collection === 'transactions') data._id = generateCustomId(startId.transaction);
        else if (collection === 'withdrawals') data._id = generateCustomId(startId.withdraw);
        else if (collection === 'apiKeys') data._id = generateCustomId(startId.apikey);
        else if (collection === 'otpOrders') data._id = generateCustomId(startId.otp);
      }
      if (collection === 'apiKeys' && !data.key) data.key = generateApiKey();
      const existing = await findOne(collection, { _id: data._id });
      if (existing) {
        if (collection === 'invoices') data._id = generateCustomId(startId.invoice);
        else if (collection === 'transactions') data._id = generateCustomId(startId.transaction);
        else if (collection === 'withdrawals') data._id = generateCustomId(startId.withdraw);
        else if (collection === 'apiKeys') {
          data._id = generateCustomId(startId.apikey);
          data.key = generateApiKey();
        } else if (collection === 'otpOrders') data._id = generateCustomId(startId.otp);
        continue;
      }
      return await insertOne(collection, data);
    } catch (err) {
      if (attempt < maxRetries - 1) continue;
      throw err;
    }
  }
  throw new Error('Gagal membuat dokumen setelah beberapa kali percobaan');
}

// ===================== FUNGSI PEMBANTU =====================
function generateCustomId(prefix) {
  const len = 10 - prefix.length;
  const randomHex = crypto.randomBytes(Math.ceil(len / 2)).toString('hex').substring(0, len);
  return prefix + randomHex;
}

function generateApiKey() {
  return startId.apikey + '_' + crypto.randomUUID().replace(/-/g, '').substring(0, 16);
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex') === hash;
}

async function migrateAddFlutterLimit() {
  const users = await readDB('users');
  let updated = false;
  for (const user of users) {
    if (user.flutterLimit === undefined) {
      user.flutterLimit = 0;
      await updateById('users', user._id, { $set: { flutterLimit: 0 } });
      updated = true;
    }
  }
  if (updated) console.log('✅ Migrasi flutterLimit selesai');
}
// Panggil di setTimeout

// ===================== GET SETTINGS & STATS =====================
async function getSettings() {
  let settings = await findOne('settings', {});
  if (!settings) {
    settings = {
      _id: 'settings_1',
      name: 'Azx Gateway',
      title: 'Layanan Payment Gateway',
      description: 'Terima pembayaran melalui QRIS Payment untuk Aplikasi atau Platform Bisnis kamu dengan mudah, cepat, dan aman.',
      channelWhatsApp: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
      apiDomain: 'skyserver.web.id',
      apiKey: 'skyy7',
      username: 'aancuy',
      token: '2163915:TZdCcEk7lX9e2OYWQpnv4fGruBPN80by',
      minDeposit: 1000,
      minWithdraw: 5000,
      feeWithdraw: 1000,
      maxFee: 500,
      checkInterval: 20,
      autoCheckEnabled: true,
      autoBackupEnabled: false,
      autoRestartEnabled: false,
      backupType: 'database',
      restartTime: '03:00',
      backupTime: '00:00',
      smtpUser: '',
      smtpPass: '',
      telegramBotToken: '',
      telegramAdminChatId: '',
      logoUrl: 'https://img2.pixhost.to/images/8187/731158188_skyzo.png'
    };
    await insertOne('settings', settings);
  }
  return settings;
}

async function getStats() {
  const transactions = await readDB('transactions');
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;
  await updateOne('stats', {}, {
    $set: { totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions }
  }, { upsert: true });
  return { totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions };
}

// ===================== NOTIFIKASI ADMIN =====================
async function sendAdminNotification(event, data) {
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const token = settings.telegramBotToken;
  if (!token || !adminChatId) return;
  let message = '';
  switch (event) {
    case 'new_register':
      message = `🆕 *Pendaftaran Baru*\n\n👤 Username: ${data.username}\n📧 Email: ${data.email}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_login':
      message = `🔐 *Login Baru*\n\n👤 Username: ${data.username}\n📧 Email: ${data.email}\n🌐 IP: ${data.ip}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_deposit':
      message = `💰 *Deposit Baru*\n\n👤 User: ${data.username}\n💵 Jumlah: Rp ${data.amount.toLocaleString()}\n📝 Status: ${data.status}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_withdraw':
      message = `💸 *Withdraw Baru*\n\n👤 User: ${data.username}\n💵 Jumlah: Rp ${data.amount.toLocaleString()}\n📝 Status: ${data.status}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_otp_order':
      message = `📱 *OTP Order Baru*\n\n👤 User: ${data.username}\n📱 Layanan: ${data.service}\n🌍 Negara: ${data.country}\n📡 Operator: ${data.operator}\n💰 Harga: Rp ${data.price.toLocaleString()}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'backup_success':
      message = `💾 *Backup Berhasil*\n\n📁 Tipe: ${data.type}\n📊 Ukuran: ${data.size} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'restart_success':
      message = `🔄 *Restart Server*\n\n✅ Server berhasil direstart\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
  }
  if (message) await sendTelegramMessage(adminChatId, message);
}

// ===================== BACKUP FUNGSI =====================
async function createBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_db_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      output.on('close', () => resolve({ path: zipFilePath, name: zipFileName, size: archive.pointer() }));
      archive.on('error', reject);
      archive.pipe(output);
      if (fs.existsSync(DATA_DIR)) archive.directory(DATA_DIR, 'data');
      else reject(new Error('Folder data tidak ditemukan'));
      await archive.finalize();
    } catch (error) { reject(error); }
  });
}

async function createFullBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_full_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      output.on('close', () => resolve({ path: zipFilePath, name: zipFileName, size: archive.pointer() }));
      archive.on('error', reject);
      archive.pipe(output);
      archive.glob('**/*', {
        cwd: __dirname,
        ignore: ['node_modules/**', 'package-lock.json', '.env', 'backup_*.zip', 'backup_db_*.zip', 'backup_full_*.zip', 'data/backup_*.json']
      });
      await archive.finalize();
    } catch (error) { reject(error); }
  });
}

async function sendBackupToTelegram(zipPath, zipName, isFull = false) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  const adminChatId = settings.telegramAdminChatId;
  if (!token || !adminChatId) return false;
  try {
    const stats = fs.statSync(zipPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    if (stats.size === 0) return false;
    if (stats.size > 50 * 1024 * 1024) {
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: adminChatId,
        text: `⚠️ *Backup terlalu besar*\n\nFile backup ${zipName} berukuran ${fileSizeMB} MB melebihi batas Telegram (50MB).\n\nSilakan download manual dari server: ${zipPath}`,
        parse_mode: 'Markdown'
      });
      return false;
    }
    const formData = new FormData();
    formData.append('chat_id', adminChatId);
    formData.append('document', fs.createReadStream(zipPath));
    formData.append('caption', `🗄️ *${isFull ? 'Full Backup' : 'Backup Database'}* - ${new Date().toLocaleDateString('id-ID')}\n\n📁 File: ${zipName}\n📊 Ukuran: ${fileSizeMB} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n⚠️ Simpan file ini dengan aman!`);
    await axios.post(`https://api.telegram.org/bot${token}/sendDocument`, formData, { headers: { ...formData.getHeaders() } });
    await sendAdminNotification('backup_success', { type: isFull ? 'Full Backup' : 'Database Backup', size: fileSizeMB });
    return true;
  } catch (error) { return false; }
}

async function performBackup(backupType) {
  try {
    let result;
    if (backupType === 'full') {
      const { path: zipPath, name: zipName } = await createFullBackupZip();
      await sendBackupToTelegram(zipPath, zipName, true);
      setTimeout(() => fs.unlink(zipPath, () => {}), 5000);
      result = { success: true, fileName: zipName };
    } else {
      const { path: zipPath, name: zipName } = await createBackupZip();
      await sendBackupToTelegram(zipPath, zipName, false);
      setTimeout(() => fs.unlink(zipPath, () => {}), 5000);
      result = { success: true, fileName: zipName };
    }
    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// ===================== CRON JOB =====================
let restartCronJob = null;
let backupCronJob = null;

async function scheduleAutoRestart() {
  if (restartCronJob) restartCronJob.stop();
  const settings = await getSettings();
  if (!settings.autoRestartEnabled) return;
  const [hour, minute] = settings.restartTime.split(':');
  restartCronJob = cron.schedule(`${minute} ${hour} * * *`, async () => {
    await sendAdminNotification('restart_success', {});
    setTimeout(() => process.exit(0), 2000);
  });
}

async function scheduleAutoBackup() {
  if (backupCronJob) backupCronJob.stop();
  const settings = await getSettings();
  if (!settings.autoBackupEnabled) return;
  const [hour, minute] = settings.backupTime.split(':');
  backupCronJob = cron.schedule(`${minute} ${hour} * * *`, async () => {
    await performBackup(settings.backupType);
  });
}

// ===================== TELEGRAM BOT =====================
let pollingTimeout = null;
let isPollingActive = false;

async function getAdminChatId() {
  const settings = await getSettings();
  return settings.telegramAdminChatId || null;
}

async function sendTelegramMessage(chatId, text, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token || !chatId) return;
  try {
    const payload = { chat_id: chatId, text, parse_mode: 'Markdown' };
    if (replyMarkup) payload.reply_markup = replyMarkup;
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, payload);
  } catch (e) {}
}

async function deleteMessage(chatId, messageId) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/deleteMessage`, { chat_id: chatId, message_id: messageId });
  } catch (e) {}
}

async function answerCallbackQuery(callbackQueryId, text) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/answerCallbackQuery`, { callback_query_id: callbackQueryId, text, show_alert: false });
  } catch (e) {}
}

const adminMenuKeyboard = {
  inline_keyboard: [
    [{ text: '📊 Dashboard', callback_data: 'admin_stats' }],
    [{ text: '👥 Users', callback_data: 'admin_users' }, { text: '💰 Withdraw', callback_data: 'admin_withdraw' }],
    [{ text: '📝 Transactions', callback_data: 'admin_transactions' }, { text: '⚙️ Settings', callback_data: 'admin_settings' }],
    [{ text: '💾 Backup DB', callback_data: 'backup_db' }, { text: '📦 Backup Full', callback_data: 'backup_full' }],
    [{ text: '🔄 Restart Server', callback_data: 'restart_server' }]
  ]
};

const mainMenuKeyboard = {
  inline_keyboard: [
    [{ text: '👤 Profile Saya', callback_data: 'my_profile' }],
    [{ text: '💰 Deposit', callback_data: 'deposit_info' }, { text: '💸 Withdraw', callback_data: 'withdraw_info' }],
    [{ text: '📜 Riwayat Transaksi', callback_data: 'my_transactions' }],
    [{ text: '🔑 API Key Saya', callback_data: 'my_apikey' }],
    [{ text: '🛠️ Admin Panel', callback_data: 'admin_panel' }]
  ]
};

async function handleTelegramCommand(msg) {
  const text = msg.text;
  const chatId = msg.chat.id;
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const isAdminUser = String(chatId) === String(adminChatId);
  if (text === '/start') {
    await sendTelegramMessage(chatId, `🤖 *${settings.name} Bot*\n\nSelamat datang di bot payment gateway!\n\nGunakan menu di bawah untuk mengakses fitur.`, isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
  } else if (text === '/menu') {
    await sendTelegramMessage(chatId, '📋 *Menu Utama*', isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
  } else if (text === '/backupdb' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses backup database...*');
    const result = await performBackup('database');
    await sendTelegramMessage(chatId, result.success ? `✅ Backup database berhasil: ${result.fileName}` : `❌ Backup gagal: ${result.error}`);
  } else if (text === '/backupall' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses full backup...*\n\n⏳ Mohon tunggu, proses ini mungkin memakan waktu beberapa saat.');
    const result = await performBackup('full');
    await sendTelegramMessage(chatId, result.success ? `✅ Full backup berhasil: ${result.fileName}` : `❌ Backup gagal: ${result.error}`);
  } else if (text === '/restart' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Merestart server...*\n\nServer akan online kembali dalam beberapa detik.');
    await sendAdminNotification('restart_success', {});
    setTimeout(() => process.exit(0), 2000);
  } else if (text === '/stats' && isAdminUser) {
    const stats = await getStats();
    await sendTelegramMessage(chatId, `📊 *Statistik Server*\n\n💰 Total Deposit: Rp ${stats.totalDepositAmount.toLocaleString()}\n💸 Total Withdraw: Rp ${stats.totalWithdrawAmount.toLocaleString()}\n👥 Total Users: ${stats.totalUsers}\n📝 Total Transaksi: ${stats.totalTransactions}\n⏰ Update: ${new Date().toLocaleString('id-ID')}`);
  } else if (text === '/users' && isAdminUser) {
    const users = await readDB('users');
    const userList = users.filter(u => u.role === 'user').slice(0, 10);
    let userText = `👥 *Daftar User (10 terbaru)*\n\n`;
    for (const u of userList) userText += `• ${u.username} - Saldo: Rp ${(u.balance || 0).toLocaleString()}\n`;
    userText += `\nTotal user: ${users.filter(u => u.role === 'user').length}`;
    await sendTelegramMessage(chatId, userText);
  }
}

async function handleCallbackQuery(cb) {
  const data = cb.data;
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const isAdminUser = String(chatId) === String(adminChatId);
  await answerCallbackQuery(cb.id, 'Processing...');
  if (data === 'admin_panel' && isAdminUser) {
    await sendTelegramMessage(chatId, '🛠️ *Admin Panel*\n\nPilih menu di bawah:', adminMenuKeyboard);
    await deleteMessage(chatId, messageId);
  } else if (data === 'admin_stats' && isAdminUser) {
    const stats = await getStats();
    await sendTelegramMessage(chatId, `📊 *Statistik Server*\n\n💰 Total Deposit: Rp ${stats.totalDepositAmount.toLocaleString()}\n💸 Total Withdraw: Rp ${stats.totalWithdrawAmount.toLocaleString()}\n👥 Total Users: ${stats.totalUsers}\n📝 Total Transaksi: ${stats.totalTransactions}`);
  } else if (data === 'admin_users' && isAdminUser) {
    const users = await readDB('users');
    const userList = users.filter(u => u.role === 'user').slice(0, 15);
    let userText = `👥 *Daftar User (15 terbaru)*\n\n`;
    for (const u of userList) userText += `• *${u.username}* - Saldo: Rp ${(u.balance || 0).toLocaleString()}\n  Status: ${u.suspended ? '⛔ Suspended' : '✅ Active'}\n\n`;
    userText += `📊 Total user: ${users.filter(u => u.role === 'user').length}`;
    await sendTelegramMessage(chatId, userText);
  } else if (data === 'admin_withdraw' && isAdminUser) {
    const withdrawals = await readDB('withdrawals');
    const pendingWd = withdrawals.filter(w => w.status === 'pending').slice(0, 10);
    if (pendingWd.length === 0) {
      await sendTelegramMessage(chatId, '✅ Tidak ada withdraw pending saat ini.');
    } else {
      let wdText = `💸 *Withdraw Pending (10 terbaru)*\n\n`;
      for (const w of pendingWd) {
        const user = await findById('users', w.userId);
        wdText += `• ID: \`${w._id}\`\n  User: ${user?.username || 'Unknown'}\n  Amount: Rp ${(w.amount + w.fee).toLocaleString()}\n  Waktu: ${new Date(w.createdAt).toLocaleString('id-ID')}\n\n`;
      }
      await sendTelegramMessage(chatId, wdText);
    }
  } else if (data === 'admin_transactions' && isAdminUser) {
    const transactions = await readDB('transactions');
    const recentTx = transactions.slice(0, 10);
    let txText = `📝 *Transaksi Terbaru (10)*\n\n`;
    for (const t of recentTx) {
      const user = await findById('users', t.userId);
      txText += `• ${t.type === 'deposit' ? '💰 Deposit' : '💸 Withdraw'} - ${user?.username || 'Unknown'}\n  Amount: Rp ${(t.amount || 0).toLocaleString()}\n  Status: ${t.status}\n  Waktu: ${new Date(t.createdAt).toLocaleString('id-ID')}\n\n`;
    }
    await sendTelegramMessage(chatId, txText);
  } else if (data === 'admin_settings' && isAdminUser) {
    await sendTelegramMessage(chatId, `⚙️ *Pengaturan Saat Ini*\n\n🏷️ Nama: ${settings.name}\n💰 Min Deposit: Rp ${settings.minDeposit.toLocaleString()}\n💸 Min Withdraw: Rp ${settings.minWithdraw.toLocaleString()}\n📊 Fee Withdraw: Rp ${settings.feeWithdraw.toLocaleString()}\n🔄 Auto Cek Mutasi: ${settings.autoCheckEnabled ? '✅ Aktif' : '❌ Nonaktif'}\n💾 Auto Backup: ${settings.autoBackupEnabled ? '✅ Aktif' : '❌ Nonaktif'}\n🔄 Auto Restart: ${settings.autoRestartEnabled ? '✅ Aktif' : '❌ Nonaktif'}\n⏰ Waktu Restart: ${settings.restartTime || '03:00'}\n⏰ Waktu Backup: ${settings.backupTime || '00:00'}\n📦 Tipe Backup: ${settings.backupType === 'full' ? 'Full Script' : 'Database Only'}\n\n📱 Telegram Bot: ${settings.telegramBotToken ? '✅ Terkonfigurasi' : '❌ Belum'}`);
  } else if (data === 'backup_db' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses backup database...*\n\n⏳ Mohon tunggu.');
    await performBackup('database');
  } else if (data === 'backup_full' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses full backup...*\n\n⏳ Mohon tunggu, proses ini mungkin memakan waktu beberapa saat.');
    await performBackup('full');
  } else if (data === 'restart_server' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Merestart server...*\n\nServer akan online kembali dalam beberapa detik.');
    await sendAdminNotification('restart_success', {});
    setTimeout(() => process.exit(0), 2000);
  } else if (data === 'main_menu') {
    await sendTelegramMessage(chatId, '📋 *Menu Utama*', isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
    await deleteMessage(chatId, messageId);
  } else if (data === 'my_profile') {
    const userRecord = await findOne('users', { telegramId: String(chatId) });
    if (userRecord) {
      await sendTelegramMessage(chatId, `👤 *Profil Saya*\n\nUsername: ${userRecord.username}\nEmail: ${userRecord.email}\nSaldo: Rp ${(userRecord.balance || 0).toLocaleString()}\nE-Wallet: ${userRecord.ewallet || 'Belum diisi'}\nStatus: ${userRecord.suspended ? '⛔ Suspended' : '✅ Active'}`);
    } else {
      await sendTelegramMessage(chatId, '❌ Akun tidak ditemukan. Silakan login terlebih dahulu di website.');
    }
  } else if (data === 'deposit_info') {
    await sendTelegramMessage(chatId, `💰 *Informasi Deposit*\n\nMinimal deposit: Rp ${settings.minDeposit.toLocaleString()}\n\nSilakan login ke website untuk melakukan deposit.\n\nWebsite: ${settings.apiDomain || 'belum diset'}`);
  } else if (data === 'withdraw_info') {
    await sendTelegramMessage(chatId, `💸 *Informasi Withdraw*\n\nMinimal withdraw: Rp ${settings.minWithdraw.toLocaleString()}\nBiaya admin: Rp ${settings.feeWithdraw.toLocaleString()}\n\nSilakan login ke website untuk melakukan withdraw.\n\nWebsite: ${settings.apiDomain || 'belum diset'}`);
  } else if (data === 'my_transactions') {
    const userRecord = await findOne('users', { telegramId: String(chatId) });
    if (userRecord) {
      const transactions = await readDB('transactions');
      const userTx = transactions.filter(t => t.userId === userRecord._id).slice(0, 10);
      if (userTx.length === 0) {
        await sendTelegramMessage(chatId, '📜 Belum ada transaksi.');
      } else {
        let txText = `📜 *Riwayat Transaksi (10 terbaru)*\n\n`;
        for (const t of userTx) txText += `• ${t.type === 'deposit' ? '💰 Deposit' : '💸 Withdraw'}\n  Amount: Rp ${(t.amount || 0).toLocaleString()}\n  Status: ${t.status}\n  Waktu: ${new Date(t.createdAt).toLocaleString('id-ID')}\n\n`;
        await sendTelegramMessage(chatId, txText);
      }
    } else {
      await sendTelegramMessage(chatId, '❌ Akun tidak ditemukan.');
    }
  } else if (data === 'my_apikey') {
    const userRecord = await findOne('users', { telegramId: String(chatId) });
    if (userRecord) {
      const apiKey = await findOne('apiKeys', { userId: userRecord._id });
      await sendTelegramMessage(chatId, `🔑 *API Key Saya*\n\n\`${apiKey?.key || 'Belum dibuat'}\`\n\nGunakan API key ini untuk mengakses API endpoint.\n\n⚠️ Jangan bagikan API key kepada siapapun!`);
    } else {
      await sendTelegramMessage(chatId, '❌ Akun tidak ditemukan.');
    }
  }
}

async function handleTelegramUpdate(update) {
  if (update.callback_query) await handleCallbackQuery(update.callback_query);
  else if (update.message && update.message.text) await handleTelegramCommand(update.message);
}

async function telegramGetUpdates(offset) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return [];
  try {
    const res = await axios.get(`https://api.telegram.org/bot${token}/getUpdates`, { params: { offset, timeout: 15 }, timeout: 20000 });
    if (res.data.ok) return res.data.result;
    return [];
  } catch (e) {
    if (e.response && e.response.status === 409) stopTelegramPolling();
    return [];
  }
}

function stopTelegramPolling() {
  if (pollingTimeout) clearTimeout(pollingTimeout);
  isPollingActive = false;
}

async function ensureNoWebhook(token) {
  try {
    const infoRes = await axios.get(`https://api.telegram.org/bot${token}/getWebhookInfo`);
    if (infoRes.data.ok && infoRes.data.result.url) await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook`);
    return true;
  } catch (e) { return false; }
}

async function startTelegramPolling() {
  stopTelegramPolling();
  const settings = await getSettings();
  if (!settings.telegramBotToken) return;
  if (isPollingActive) return;
  const ok = await ensureNoWebhook(settings.telegramBotToken);
  if (!ok) return;
  isPollingActive = true;
  let offset = 0;
  async function poll() {
    if (!isPollingActive) return;
    const updates = await telegramGetUpdates(offset);
    for (const update of updates) {
      offset = update.update_id + 1;
      await handleTelegramUpdate(update);
    }
    pollingTimeout = setTimeout(poll, 1000);
  }
  poll();
}

// ===================== MIDDLEWARE =====================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  store: new MemoryStore({ checkPeriod: 86400000 }),
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const Limiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 15,
  handler: (req, res) => {
    req.session.errorMsg = 'Terlalu banyak percobaan login. Silakan coba lagi setelah 5 menit.';
    res.redirect('/login');
  }
});

app.use(async (req, res, next) => {
  res.locals.user = null;
  if (req.session.userId) {
    try { res.locals.user = await findById('users', req.session.userId); } catch {}
  }
  res.locals.settings = await getSettings();
  res.locals.error = req.session.errorMsg || null;
  res.locals.success = req.session.successMsg || null;
  delete req.session.errorMsg;
  delete req.session.successMsg;
  next();
});

function isAuth(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}

function isAdmin(req, res, next) {
  if (req.session.userRole === 'admin') return next();
  res.redirect('/login');
}

// ===================== SEED ADMIN =====================
async function seed() {
  const admin = await findOne('users', { role: 'admin' });
  if (!admin) {
    await insertOne('users', {
      _id: crypto.randomBytes(12).toString('hex'),
      username: 'admin',
      email: 'admin@gmail.com',
      password: hashPassword('admin123'),
      role: 'admin',
      balance: 0,
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    });
    console.log(`Admin Account Default\nUsername: admin\nPassword: admin123`);
  }
}

// ===================== ROUTES =====================
app.get('/', (req, res) => res.render('home'));
app.get('/home', (req, res) => res.render('home'));
app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('login');
});
app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('register');
});

app.post('/login', Limiter, async (req, res) => {
  const { login, password } = req.body;
  if (!login || !password) {
    req.session.errorMsg = 'Harap isi semua field';
    return res.redirect('/login');
  }
  const isEmail = login.includes('@');
  let user;
  if (isEmail) {
    user = await findOne('users', { email: login.toLowerCase() });
    if (user && user.role === 'admin') {
      req.session.errorMsg = 'Admin hanya dapat login menggunakan username';
      return res.redirect('/login');
    }
  } else {
    user = await findOne('users', { username: login.toLowerCase() });
  }
  if (!user || !verifyPassword(password, user.password)) {
    req.session.errorMsg = 'Username/email atau kata sandi salah';
    return res.redirect('/login');
  }
  if (user.suspended) {
    req.session.errorMsg = 'Akun Anda dinonaktifkan';
    return res.redirect('/login');
  }
  req.session.userId = user._id;
  req.session.userRole = user.role;
  await sendAdminNotification('new_login', {
    username: user.username,
    email: user.email,
    ip: req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress
  });
  if (user.role === 'admin') return res.redirect('/admin/dashboard');
  res.redirect('/dashboard');
});

app.post('/register', Limiter, async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || username.trim().length === 0) {
    req.session.errorMsg = 'Username tidak boleh kosong';
    return res.redirect('/register');
  }
  if (!/^[a-zA-Z0-9]+$/.test(username)) {
    req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
    return res.redirect('/register');
  }
  if (username.length > 15) {
    req.session.errorMsg = 'Username maksimal 15 karakter';
    return res.redirect('/register');
  }
  try {
    const existingUser = await findOne('users', { $or: [{ username: username.toLowerCase() }, { email: email.toLowerCase() }] });
    if (existingUser) {
      req.session.errorMsg = 'Username atau email sudah terdaftar';
      return res.redirect('/register');
    }
    const user = {
  _id: crypto.randomBytes(12).toString('hex'),
  username: username.toLowerCase(),
  email: email.toLowerCase(),
  password: hashPassword(password),
  balance: 0,
  flutterLimit: 0,  // TAMBAHKAN - limit khusus Flutter Builder
  role: 'user',
  suspended: false,
  ewallet: '',
  accountNumber: '',
  accountName: '',
  createdAt: new Date()
};
    await insertOne('users', user);
    const apiKeyData = {
      _id: generateCustomId(startId.apikey),
      userId: user._id,
      key: generateApiKey(),
      createdAt: new Date()
    };
    await insertOne('apiKeys', apiKeyData);
    req.session.userId = user._id;
    req.session.userRole = 'user';
    await sendAdminNotification('new_register', { username: user.username, email: user.email });
    res.redirect('/dashboard');
  } catch (err) {
    req.session.errorMsg = 'Gagal mendaftar, periksa kembali data Anda';
    res.redirect('/register');
  }
});

app.post('/check-availability', async (req, res) => {
  const { type, value } = req.body;
  if (!type || !value || !['username', 'email'].includes(type)) {
    return res.json({ available: false, message: 'Parameter tidak valid' });
  }
  if (type === 'username') {
    if (!/^[a-zA-Z0-9]{1,15}$/.test(value)) {
      return res.json({ available: false, message: 'Format username tidak valid (huruf/angka, maks 15 karakter)' });
    }
    const exists = await findOne('users', { username: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Username sudah digunakan' : 'Username tersedia' });
  }
  if (type === 'email') {
    if (!/^\S+@\S+\.\S+$/.test(value)) {
      return res.json({ available: false, message: 'Format email tidak valid' });
    }
    const exists = await findOne('users', { email: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Email sudah terdaftar' : 'Email tersedia' });
  }
});

app.get('/forgot-password', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('forgot_password');
});

app.post('/forgot-password', Limiter, async (req, res) => {
  const { login } = req.body;
  if (!login) {
    req.session.errorMsg = 'Harap masukkan email atau username Anda.';
    return res.redirect('/forgot-password');
  }
  try {
    const settings = await getSettings();
    if (!settings.smtpUser || !settings.smtpPass) {
      req.session.errorMsg = 'Fitur pengiriman email belum dikonfigurasi oleh Administrator.';
      return res.redirect('/forgot-password');
    }
    const isEmail = login.includes('@');
    let user;
    if (isEmail) {
      user = await findOne('users', { email: login.toLowerCase() });
    } else {
      user = await findOne('users', { username: login.toLowerCase() });
    }
    if (!user) {
      req.session.errorMsg = 'Akun tidak ditemukan di sistem kami.';
      return res.redirect('/forgot-password');
    }
    if (!user.email) {
      req.session.errorMsg = 'Akun ini tidak memiliki alamat email yang valid.';
      return res.redirect('/forgot-password');
    }
    const token = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 30 * 60 * 1000;
    await updateById('users', user._id, { $set: user });
    const resetLink = `http://${req.headers.host}/reset-password/${token}`;
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: { user: settings.smtpUser, pass: settings.smtpPass },
      tls: { rejectUnauthorized: false }
    });
    await transporter.sendMail({
      to: user.email,
      from: `"${settings.name}" <${settings.smtpUser}>`,
      subject: `Permintaan Reset Password - ${settings.name}`,
      text: `Halo ${user.username},\n\nKami menerima permintaan untuk mengatur ulang kata sandi akun Anda. Silakan salin tautan berikut ke browser Anda:\n${resetLink}\n\nTautan ini hanya berlaku 30 menit.\n\nJika Anda tidak meminta ini, abaikan email ini.`,
      html: `<div>Reset password link: <a href="${resetLink}">${resetLink}</a></div>`
    });
    req.session.successMsg = `Link reset password telah dikirim ke email Anda yang terdaftar.`;
    res.redirect('/forgot-password');
  } catch (error) {
    req.session.errorMsg = 'Gagal memproses email. Pastikan konfigurasi SMTP di Admin valid.';
    res.redirect('/forgot-password');
  }
});

app.get('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const user = users.find(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (!user) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa (berlaku 30 menit).';
      return res.redirect('/forgot-password');
    }
    res.render('reset_password', { token: req.params.token });
  } catch (error) { res.redirect('/login'); }
});

app.post('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const userIndex = users.findIndex(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (userIndex === -1) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa.';
      return res.redirect('/forgot-password');
    }
    const { password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      req.session.errorMsg = 'Password dan konfirmasi password tidak cocok.';
      return res.redirect(`/reset-password/${req.params.token}`);
    }
    users[userIndex].password = hashPassword(password);
    delete users[userIndex].resetPasswordToken;
    delete users[userIndex].resetPasswordExpires;
    await writeDB('users', users);
    req.session.successMsg = 'Password berhasil diubah. Silakan login dengan password baru.';
    res.redirect('/login');
  } catch (error) {
    req.session.errorMsg = 'Gagal mereset password.';
    res.redirect(`/reset-password/${req.params.token}`);
  }
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/login'); });

app.get('/dashboard', isAuth, async (req, res) => {
  if (req.session.userRole === 'admin') return res.redirect('/admin/dashboard');
  const user = res.locals.user || { balance: 0 };
  const transactions = await readDB('transactions');
  const userTransactions = transactions.filter(t => t.userId === user._id);
  const totalDeposit = userTransactions.filter(t => t.type === 'deposit' && t.status === 'paid').reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalWithdraw = userTransactions.filter(t => t.type === 'withdraw' && t.status === 'success').reduce((sum, t) => sum + (t.amount || 0), 0);
  const recentTrx = userTransactions.filter(t => t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  const apiKeys = await find('apiKeys', { userId: req.session.userId });
  const allNotifications = await getNotifications();
  const activeNotifications = allNotifications.filter(n => n.isActive === true);
  res.render('dashboard', {
    user: user || { balance: 0, username: '', email: '' },
    totalDeposit: totalDeposit || 0,
    totalWithdraw: totalWithdraw || 0,
    recentTrx: recentTrx || [],
    apiKeys: apiKeys || [],
    allNotifications: activeNotifications || []
  });
});

app.get('/profile', isAuth, (req, res) => res.render('profile'));
app.post('/profile', isAuth, async (req, res) => {
  const { email, newPassword, ewallet, accountNumber, accountName } = req.body;
  try {
    const user = await findById('users', req.session.userId);
    if (email && email !== user.email) {
      const existing = await findOne('users', { email: email.toLowerCase() });
      if (existing && existing._id !== req.session.userId) {
        req.session.errorMsg = 'Email sudah digunakan oleh pengguna lain';
        return res.redirect('/profile');
      }
      user.email = email.toLowerCase();
    }
    user.ewallet = ewallet || '';
    user.accountNumber = accountNumber || '';
    user.accountName = accountName || '';
    if (newPassword && newPassword.trim()) user.password = hashPassword(newPassword);
    await updateById('users', req.session.userId, { $set: user });
    req.session.successMsg = 'Profil berhasil diperbarui';
    res.redirect('/profile');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui profil';
    res.redirect('/profile');
  }
});

app.post('/api/user/api-key/regenerate', isAuth, async (req, res) => {
  await deleteMany('apiKeys', { userId: req.session.userId });
  const key = generateApiKey();
  try {
    await createWithRetry('apiKeys', { userId: req.session.userId, key, createdAt: new Date() });
    res.json({ apiKey: key });
  } catch (err) {
    res.status(500).json({ error: 'Gagal membuat API key' });
  }
});

app.get('/deposit', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const transactions = await readDB('transactions');
  const deposits = transactions.filter(t => t.userId === req.session.userId && t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const invoices = await find('invoices', { userId: req.session.userId });
  res.render('deposit', { deposits, invoices: invoices.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), minDeposit: settings.minDeposit });
});

app.post('/invoice/create', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const userId = req.session.userId;
  const amount = parseInt(req.body.amount);
  if (isNaN(amount) || amount < settings.minDeposit) {
    req.session.errorMsg = `Minimal deposit adalah Rp ${settings.minDeposit.toLocaleString('id-ID')}`;
    return res.redirect('/deposit');
  }
  try {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const invoices = await readDB('invoices');
    const lockedInvoices = invoices.filter(i => i.status === 'pending' || (i.status === 'paid' && new Date(i.createdAt) >= oneDayAgo));
    const usedFees = lockedInvoices.map(i => Number(i.fee)).filter(f => !isNaN(f));
    const availableFees = [];
    for (let i = 1; i <= settings.maxFee; i++) {
      if (!usedFees.includes(i)) availableFees.push(i);
    }
    if (availableFees.length === 0) {
      req.session.errorMsg = 'Kode unik deposit sedang penuh. Silakan coba lagi beberapa menit.';
      return res.redirect('/deposit');
    }
    const fee = availableFees[Math.floor(Math.random() * availableFees.length)];
    const total = amount + fee;
    const url = `https://${settings.apiDomain}/?action=createpayment&apikey=${settings.apiKey}&username=${settings.username}&amount=${total}&token=${settings.token}`;
    const resp = await axios.get(url);
    const data = resp.data;
    if (!data.status) throw new Error('Gagal membuat QRIS dari gateway');
    const expiredAt = new Date(Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId, amount, fee, total,
      trxid: data.result.trxid,
      qris_image: data.result.qris_image,
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId, type: 'deposit', amount, fee,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date()
    });
    const user = await findById('users', userId);
    await sendAdminNotification('new_deposit', { username: user.username, amount: amount, status: 'pending' });
    return res.redirect(`/invoice/${invoice._id}`);
  } catch (e) {
    req.session.errorMsg = 'Gagal membuat invoice deposit. Silakan coba lagi.';
    return res.redirect('/deposit');
  }
});

app.get('/invoice/:id', isAuth, async (req, res) => {
  const inv = await findById('invoices', req.params.id);
  if (!inv || inv.userId !== req.session.userId) return res.status(404).send('Tidak ditemukan');
  res.render('invoice_detail', { inv });
});

app.get('/withdraw', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const withdrawals = await find('withdrawals', { userId: req.session.userId });
  res.render('withdraw', { settings, withdrawals: withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) });
});

app.post('/withdraw/request', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const user = res.locals.user;
  if (!user.ewallet || !user.accountNumber || !user.accountName) {
    req.session.errorMsg = 'Harap lengkapi data E-Wallet di Profil terlebih dahulu.';
    return res.redirect('/withdraw');
  }
  const { amount } = req.body;
  const amt = parseInt(amount);
  const fee = settings.feeWithdraw || 0;
  const totalDeduct = amt + fee;
  if (isNaN(amt) || amt < settings.minWithdraw) {
    req.session.errorMsg = 'Minimal penarikan Rp ' + settings.minWithdraw;
    return res.redirect('/withdraw');
  }
  if (user.balance < totalDeduct) {
    req.session.errorMsg = 'Saldo tidak cukup (termasuk biaya admin Rp ' + fee.toLocaleString() + ')';
    return res.redirect('/withdraw');
  }
  user.balance -= totalDeduct;
  await updateById('users', req.session.userId, { $set: user });
  try {
    const ref = 'W' + Date.now().toString(36).toUpperCase();
    const wd = await createWithRetry('withdrawals', {
      _id: generateCustomId(startId.withdraw),
      userId: req.session.userId, amount: amt, fee,
      method: user.ewallet, accountNumber: user.accountNumber, accountName: user.accountName,
      status: 'pending',
      adminNote: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId: req.session.userId, type: 'withdraw', amount: amt, fee,
      status: 'pending', reference: ref,
      createdAt: new Date()
    });
    await sendAdminNotification('new_withdraw', { username: user.username, amount: amt + fee, status: 'pending' });
    const adminChatId = await getAdminChatId();
    if (adminChatId) {
      const userForMsg = await findById('users', req.session.userId);
      const timeString = new Date(wd.createdAt).toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      }).replace(/, /, ' pukul ');
      const header = `🌐 *Notifikasi - ${settings.name}*\n\n`;
      const userInfo = `👤 *Informasi User*\n• *User:* ${userForMsg.username} (${userForMsg.email})\n• *Saldo Saat Ini:* Rp ${user.balance.toLocaleString()}\n• *E-Wallet:* ${user.ewallet}\n• *No. Rek:* \`${user.accountNumber}\`\n• *Nama Rek:* ${user.accountName}\n\n`;
      const withdrawInfo = `📤 Informasi Withdraw\n• *Jumlah:* Rp ${amt.toLocaleString()}\n• *Biaya:* Rp ${fee.toLocaleString()}\n• *Total Penarikan:* Rp ${totalDeduct.toLocaleString()}\n• *Waktu:* ${timeString}\n`;
      const inlineKeyboard = { inline_keyboard: [[{ text: '✅ Setujui', callback_data: `approve_wd:${wd._id}` }, { text: '❌ Tolak', callback_data: `reason_wd:${wd._id}` }]] };
      sendTelegramMessage(adminChatId, header + userInfo + withdrawInfo, inlineKeyboard);
    }
    req.session.successMsg = 'Penarikan berhasil diajukan dan sedang diproses.';
  } catch (err) {
    user.balance += totalDeduct;
    await updateById('users', req.session.userId, { $set: user });
    req.session.errorMsg = 'Gagal memproses penarikan sistem.';
  }
  res.redirect('/withdraw');
});

// ===================== ADMIN ROUTES =====================
app.get('/admin/dashboard', isAuth, isAdmin, async (req, res) => {
  const stats = await getStats();
  res.render('admin_dashboard', stats);
});

app.get('/admin/users', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let users = await readDB('users');
  users = users.filter(u => u.role === 'user');
  if (search) {
    users = users.filter(u => u.email.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase()));
  }
  users.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_users', { users, search });
});

app.get('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const targetUser = await findById('users', req.params.id);
  if (!targetUser) return res.status(404).send('Tidak ditemukan');
  res.render('admin_user_edit', { users: targetUser });
});

app.post('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const { username, email, password, balance, suspended } = req.body;
  if (username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
  }
  const user = await findById('users', req.params.id);
  if (!user) {
    req.session.errorMsg = 'User tidak ditemukan';
    return res.redirect('/admin/users');
  }
  if (username) user.username = username.toLowerCase();
  if (email) user.email = email.toLowerCase();
  if (balance !== undefined) user.balance = parseInt(balance) || 0;
  user.suspended = suspended === 'on';
  if (password && password.trim()) user.password = hashPassword(password);
  try {
    await updateById('users', req.params.id, { $set: user });
    req.session.successMsg = 'Data pengguna berhasil diperbarui';
    res.redirect('/admin/users');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui data pengguna';
    res.redirect(`/admin/users/${req.params.id}/edit`);
  }
});

app.post('/admin/users/:id/delete', isAuth, isAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const userToDelete = await findById('users', userId);
    if (!userToDelete) {
      req.session.errorMsg = 'User tidak ditemukan.';
      return res.redirect('/admin/users');
    }
    if (userToDelete.role === 'admin') {
      req.session.errorMsg = 'Tidak dapat menghapus akun admin.';
      return res.redirect('/admin/users');
    }
    await deleteMany('invoices', { userId });
    await deleteMany('transactions', { userId });
    await deleteMany('withdrawals', { userId });
    await deleteMany('apiKeys', { userId });
    await deleteOne('users', { _id: userId });
    req.session.successMsg = 'User berhasil dihapus beserta seluruh data terkait.';
    res.redirect('/admin/users');
  } catch (err) {
    req.session.errorMsg = 'Gagal menghapus user.';
    res.redirect('/admin/users');
  }
});

app.get('/admin/withdraw', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let withdrawals = await readDB('withdrawals');
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => u.email.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase())).map(u => u._id);
    withdrawals = withdrawals.filter(w => matchedUsers.includes(w.userId));
  }
  for (const w of withdrawals) {
    const user = await findById('users', w.userId);
    if (user) { w.username = user.username; w.email = user.email; }
  }
  withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_withdraw', { withdrawals, search });
});

app.post('/admin/withdraw/success/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'success';
    await updateById('withdrawals', wd._id, { $set: wd });
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'success';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    await updateOne('stats', {}, { $inc: { totalWithdrawAmount: wd.amount, totalWithdrawFee: wd.fee } });
    req.session.successMsg = 'Penarikan berhasil disetujui.';
  }
  res.redirect('/admin/withdraw');
});

app.post('/admin/withdraw/reject/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'rejected';
    wd.adminNote = req.body.note || '';
    await updateById('withdrawals', wd._id, { $set: wd });
    const user = await findById('users', wd.userId);
    user.balance += wd.amount + wd.fee;
    await updateById('users', wd.userId, { $set: user });
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'rejected';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    req.session.successMsg = 'Penarikan ditolak dan saldo dikembalikan.';
  }
  res.redirect('/admin/withdraw');
});

app.get('/admin/transactions', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let transactions = await readDB('transactions');
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => u.email.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase())).map(u => u._id);
    transactions = transactions.filter(t => matchedUsers.includes(t.userId) || (t.reference && t.reference.toLowerCase().includes(search.toLowerCase())));
  }
  for (const t of transactions) {
    const user = await findById('users', t.userId);
    if (user) { t.username = user.username; t.email = user.email; }
  }
  transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_transactions', { transactions, search });
});

app.get('/admin/account', isAuth, isAdmin, async (req, res) => {
  const admin = await findById('users', req.session.userId);
  res.render('admin_account', { admin });
});

app.post('/admin/account', isAuth, isAdmin, async (req, res) => {
  const { username, password, newPassword } = req.body;
  const admin = await findById('users', req.session.userId);
  if (!password || !verifyPassword(password, admin.password)) {
    req.session.errorMsg = 'Password saat ini salah';
    return res.redirect('/admin/account');
  }
  if (username && username !== admin.username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect('/admin/account');
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect('/admin/account');
    }
    const existing = await findOne('users', { username: username.toLowerCase() });
    if (existing && existing._id !== admin._id) {
      req.session.errorMsg = 'Username sudah digunakan oleh pengguna lain';
      return res.redirect('/admin/account');
    }
  }
  try {
    if (username && username !== admin.username) admin.username = username.toLowerCase();
    if (newPassword && newPassword.trim()) admin.password = hashPassword(newPassword);
    await updateById('users', req.session.userId, { $set: admin });
    req.session.successMsg = 'Data akun berhasil diperbarui';
  } catch (e) {
    req.session.errorMsg = 'Gagal memperbarui akun';
  }
  res.redirect('/admin/account');
});

app.post('/admin/settings/reset', isAuth, isAdmin, async (req, res) => {
  try {
    const users = await readDB('users');
    const adminUser = users.find(u => u.role === 'admin');
    await writeDB('users', adminUser ? [adminUser] : []);
    await writeDB('invoices', []);
    await writeDB('transactions', []);
    await writeDB('withdrawals', []);
    await writeDB('apiKeys', []);
    await writeDB('stats', [{ totalDepositAmount: 0, totalDepositFee: 0, totalWithdrawAmount: 0, totalWithdrawFee: 0, totalUsers: 0, totalTransactions: 0 }]);
    req.session.successMsg = 'Database berhasil direset. Semua data pengguna, invoice, transaksi, dan withdrawal telah dihapus.';
  } catch (error) {
    req.session.errorMsg = 'Gagal mereset database. Silakan coba lagi.';
  }
  res.redirect('/admin/settings');
});

app.get('/admin/settings', isAuth, isAdmin, async (req, res) => {
  res.render('admin_settings');
});

app.post('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const { name, title, description, apiDomain, apiKey, username, token, minDeposit, minWithdraw, channelWhatsApp, feeWithdraw, maxFee, checkInterval, autoCheckEnabled, autoBackupEnabled, autoRestartEnabled, backupType, restartTime, backupTime, smtpUser, smtpPass, telegramBotToken, telegramAdminChatId, logoUrl } = req.body;
  const settings = await getSettings();
  settings.name = name;
  settings.title = title;
  settings.description = description;
  settings.apiDomain = apiDomain;
  settings.apiKey = apiKey;
  settings.username = username;
  settings.token = token;
  settings.minDeposit = parseInt(minDeposit);
  settings.minWithdraw = parseInt(minWithdraw);
  settings.feeWithdraw = parseInt(feeWithdraw);
  settings.maxFee = parseInt(maxFee);
  settings.channelWhatsApp = channelWhatsApp;
  settings.checkInterval = parseInt(checkInterval);
  settings.autoCheckEnabled = autoCheckEnabled === 'on';
  settings.autoBackupEnabled = autoBackupEnabled === 'on';
  settings.autoRestartEnabled = autoRestartEnabled === 'on';
  settings.backupType = backupType || 'database';
  settings.restartTime = restartTime || '03:00';
  settings.backupTime = backupTime || '00:00';
  settings.smtpUser = smtpUser;
  settings.smtpPass = smtpPass;
  settings.telegramBotToken = telegramBotToken;
  settings.telegramAdminChatId = telegramAdminChatId;
  settings.logoUrl = logoUrl;
  await updateById('settings', settings._id, { $set: settings });
  startChecker();
  startTelegramPolling();
  scheduleAutoBackup();
  scheduleAutoRestart();
  req.session.successMsg = 'Pengaturan berhasil diperbarui dan sistem disinkronisasi.';
  res.redirect('/admin/settings');
});

app.get('/docs', async (req, res) => {
  let userApiKey = '';
  if (req.session.userId) {
    const key = await findOne('apiKeys', { userId: req.session.userId });
    if (key) userApiKey = key.key;
  }
  res.render('docs', { userApiKey });
});

// ===================== API ROUTES =====================
async function apiAuth(req, res, next) {
  const apiKey = req.headers['x-api-key'] || req.query.api_key || req.query.apikey;
  if (!apiKey) return res.status(401).json({ error: 'API key diperlukan' });
  const keyDoc = await findOne('apiKeys', { key: apiKey });
  if (!keyDoc) return res.status(401).json({ error: 'API key tidak valid' });
  req.apiUser = keyDoc.userId;
  next();
}

app.get('/api/v1/balance', apiAuth, async (req, res) => {
  const user = await findById('users', req.apiUser);
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan' });
  res.json({ balance: user.balance });
});

app.get('/api/v1/invoice', apiAuth, async (req, res) => {
  const settings = await getSettings();
  const amount = parseInt(req.query.amount);
  const userId = req.apiUser;
  if (!amount || isNaN(amount) || amount < settings.minDeposit) {
    return res.status(400).json({ error: `Nominal minimal Rp ${settings.minDeposit}` });
  }
  try {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const invoices = await readDB('invoices');
    const lockedInvoices = invoices.filter(i => i.status === 'pending' || (i.status === 'paid' && new Date(i.createdAt) >= oneDayAgo));
    const usedFees = lockedInvoices.map(i => Number(i.fee)).filter(f => !isNaN(f));
    const availableFees = [];
    for (let i = 1; i <= settings.maxFee; i++) {
      if (!usedFees.includes(i)) availableFees.push(i);
    }
    if (availableFees.length === 0) {
      return res.status(503).json({ error: 'Kode unik sedang penuh, silakan coba lagi beberapa menit.' });
    }
    const fee = availableFees[Math.floor(Math.random() * availableFees.length)];
    const total = amount + fee;
    const url = `https://${settings.apiDomain}/?action=createpayment&apikey=${settings.apiKey}&username=${settings.username}&amount=${total}&token=${settings.token}`;
    const resp = await axios.get(url);
    const data = resp.data;
    if (!data.status) throw new Error('Gagal membuat pembayaran');
    const expiredAt = new Date(Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId, amount, fee, total,
      trxid: data.result.trxid,
      qris_image: data.result.qris_image,
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId, type: 'deposit', amount, fee,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date()
    });
    return res.json({
      success: true,
      invoice_id: invoice._id,
      amount: invoice.amount,
      fee: invoice.fee,
      total: invoice.total,
      qris_image: invoice.qris_image,
      expired_at: invoice.expiredAt
    });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal membuat invoice' });
  }
});

app.get('/api/v1/invoice/status', apiAuth, async (req, res) => {
  const invoiceId = req.query.id || req.query.invoice_id;
  if (!invoiceId) return res.status(400).json({ error: 'Invoice ID diperlukan' });
  const invoice = await findById('invoices', invoiceId);
  if (!invoice || invoice.userId !== req.apiUser) {
    return res.status(404).json({ error: 'Invoice tidak ditemukan' });
  }
  res.json({
    invoice_id: invoice._id,
    amount: invoice.amount,
    fee: invoice.fee,
    total: invoice.total,
    status: invoice.status,
    qris_image: invoice.qris_image,
    expired_at: invoice.expiredAt,
    created_at: invoice.createdAt
  });
});

// ===================== OTP FUNGSI =====================
async function getRumahOTPBalance() {
  try {
    const response = await axios.get('https://www.rumahotp.io/api/v1/user/balance', {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false, error: error.response?.data?.error?.message || error.message };
  }
}

async function getRumahOTPServices() {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/services`, {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false, data: [], error: error.response?.data?.error?.message || error.message };
  }
}

async function getRumahOTPCountries(serviceId) {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/countries?service_id=${serviceId}`, {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false, data: [] };
  }
}

async function getRumahOTPOperators(countryName, providerId) {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/operators?country=${encodeURIComponent(countryName)}&provider_id=${providerId}`, {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false, data: [] };
  }
}

async function orderRumahOTPNumber(numberId, providerId, operatorId) {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/orders`, {
      params: { number_id: parseInt(numberId), provider_id: parseInt(providerId), operator_id: parseInt(operatorId) },
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false, error: error.response?.data?.error?.message || 'Gagal memesan nomor' };
  }
}

async function checkRumahOTPStatus(orderId) {
  try {
    const response = await axios.get(`https://www.rumahotp.io/api/v1/orders/get_status`, {
      params: { order_id: orderId },
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false };
  }
}

async function cancelRumahOTPOrder(orderId) {
  try {
    const response = await axios.get(`https://www.rumahotp.io/api/v1/orders/set_status`, {
      params: { order_id: orderId, status: 'cancel' },
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    return { success: false };
  }
}

// ===================== OTP ORDER FUNGSI =====================
async function getOTPOrders(userId = null) {
  const orders = await readDB('otpOrders');
  if (userId) {
    return orders.filter(o => o.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveOTPOrder(orderData) {
  const orders = await readDB('otpOrders');
  orders.push(orderData);
  await writeDB('otpOrders', orders);
  return orderData;
}

async function updateOTPOrder(orderId, updateData) {
  const orders = await readDB('otpOrders');
  const index = orders.findIndex(o => o._id === orderId);
  if (index !== -1) {
    Object.assign(orders[index], updateData);
    await writeDB('otpOrders', orders);
    return true;
  }
  return false;
}

// ===================== NOTIFIKASI FUNGSI =====================
async function getNotifications(userId = null) {
  const notifs = await readDB('notifications');
  if (userId) {
    return notifs.filter(n => n.userId === userId || n.target === 'all').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return notifs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveNotification(notifData) {
  const notifs = await readDB('notifications');
  notifs.push(notifData);
  await writeDB('notifications', notifs);
  return notifData;
}

async function updateNotification(notifId, updateData) {
  const notifs = await readDB('notifications');
  const index = notifs.findIndex(n => n._id === notifId);
  if (index !== -1) {
    Object.assign(notifs[index], updateData);
    await writeDB('notifications', notifs);
    return true;
  }
  return false;
}

async function deleteNotification(notifId) {
  const notifs = await readDB('notifications');
  const filtered = notifs.filter(n => n._id !== notifId);
  await writeDB('notifications', filtered);
  return true;
}

async function markNotificationAsSeen(notifId, userId) {
  const notifs = await readDB('notifications');
  const index = notifs.findIndex(n => n._id === notifId);
  if (index !== -1) {
    if (!notifs[index].seenBy) notifs[index].seenBy = [];
    if (!notifs[index].seenBy.includes(userId)) {
      notifs[index].seenBy.push(userId);
      await writeDB('notifications', notifs);
    }
    return true;
  }
  return false;
}

// ===================== EVENT FUNGSI =====================
async function getEvents() {
  const events = await readDB('events');
  return events.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function getActiveEvent() {
  const events = await readDB('events');
  const now = new Date();
  const activeEvent = events.find(e => e.isActive === true && new Date(e.expiredAt) > now);
  return activeEvent || null;
}

async function saveEvent(eventData) {
  const events = await readDB('events');
  events.push(eventData);
  await writeDB('events', events);
  return eventData;
}

async function updateEvent(eventId, updateData) {
  const events = await readDB('events');
  const index = events.findIndex(e => e._id === eventId);
  if (index !== -1) {
    Object.assign(events[index], updateData);
    await writeDB('events', events);
    return true;
  }
  return false;
}

async function deleteEvent(eventId) {
  const events = await readDB('events');
  const filtered = events.filter(e => e._id !== eventId);
  await writeDB('events', filtered);
  return true;
}

async function hasUserClaimedEvent(userId, eventId) {
  const events = await readDB('events');
  const event = events.find(e => e._id === eventId);
  return event?.claimedBy?.includes(userId) || false;
}

async function addUserToEventClaimed(eventId, userId) {
  const events = await readDB('events');
  const index = events.findIndex(e => e._id === eventId);
  if (index !== -1) {
    if (!events[index].claimedBy) events[index].claimedBy = [];
    if (!events[index].claimedBy.includes(userId)) {
      events[index].claimedBy.push(userId);
      await writeDB('events', events);
      return true;
    }
  }
  return false;
}

// ===================== CHAT FUNGSI =====================
async function getChatMessages(limit = 50) {
  const messages = await readDB('chatMessages');
  return messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
}

async function saveChatMessage(messageData) {
  const messages = await readDB('chatMessages');
  messages.push(messageData);
  if (messages.length > 500) messages.shift();
  await writeDB('chatMessages', messages);
  return messageData;
}

async function deleteChatMessage(messageId) {
  const messages = await readDB('chatMessages');
  const filtered = messages.filter(m => m._id !== messageId);
  await writeDB('chatMessages', filtered);
  return true;
}

async function deleteAllChatMessages() {
  await writeDB('chatMessages', []);
  return true;
}

async function getChatSettings() {
  const settings = await getSettings();
  return {
    chatMode: settings.chatMode || 'admin',
    blockedUsers: settings.blockedUsers || []
  };
}

async function updateChatSettings(mode, blockedUsers) {
  const settings = await getSettings();
  settings.chatMode = mode;
  settings.blockedUsers = blockedUsers;
  await updateById('settings', settings._id, { $set: settings });
}

// ===================== FLUTTER BUILD FUNGSI =====================
async function getFlutterBuilds(userId = null) {
  const builds = await readDB('flutterBuilds');
  if (userId) {
    return builds.filter(b => b.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return builds.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveFlutterBuild(buildData) {
  const builds = await readDB('flutterBuilds');
  builds.push(buildData);
  await writeDB('flutterBuilds', builds);
  return buildData;
}

async function updateFlutterBuild(buildId, updateData) {
  const builds = await readDB('flutterBuilds');
  const index = builds.findIndex(b => b._id === buildId);
  if (index !== -1) {
    Object.assign(builds[index], updateData);
    await writeDB('flutterBuilds', builds);
    return true;
  }
  return false;
}

async function getPendingBuilds() {
  const builds = await readDB('flutterBuilds');
  return builds.filter(b => b.status === 'pending').sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
}

async function cleanupExpiredBuilds() {
  const builds = await readDB('flutterBuilds');
  let updated = false;
  for (const build of builds) {
    if (build.expiredAt && new Date(build.expiredAt) < new Date() && build.status === 'success') {
      if (build.outputFile && fs.existsSync(build.outputFile)) fs.unlinkSync(build.outputFile);
      if (build.originalFile && fs.existsSync(build.originalFile)) fs.unlinkSync(build.originalFile);
      build.status = 'expired';
      await updateFlutterBuild(build._id, { status: 'expired' });
      updated = true;
    }
  }
  return updated;
}

let isProcessingBuild = false;

async function processBuildQueue() {
  if (isProcessingBuild) return;
  try {
    const pendingBuilds = await getPendingBuilds();
    if (pendingBuilds.length === 0) return;
    const build = pendingBuilds[0];
    isProcessingBuild = true;
    await updateFlutterBuild(build._id, { status: 'processing', startedAt: new Date() });
    const extractPath = path.join(BUILDS_TEMP_DIR, build._id);
    const apkOutputPath = path.join(BUILDS_RESULT_DIR, `${build._id}.apk`);
    if (!fs.existsSync(extractPath)) fs.mkdirSync(extractPath, { recursive: true });
    const zip = new AdmZip(build.originalFile);
    zip.extractAllTo(extractPath, true);
    const flutterCmd = `cd ${extractPath} && flutter clean && flutter pub get && flutter build apk --release`;
    await execPromise(flutterCmd, { timeout: 10 * 60 * 1000 });
    const possiblePaths = [
      path.join(extractPath, 'build', 'app', 'outputs', 'flutter-apk', 'app-release.apk'),
      path.join(extractPath, 'build', 'app', 'outputs', 'apk', 'release', 'app-release.apk'),
      path.join(extractPath, 'build', 'app', 'outputs', 'apk', 'release', 'app.apk')
    ];
    let apkPath = null;
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) { apkPath = p; break; }
    }
    if (!apkPath) throw new Error('APK tidak ditemukan setelah build');
    fs.copyFileSync(apkPath, apkOutputPath);
    const expiredAt = new Date();
    expiredAt.setHours(expiredAt.getHours() + BUILD_EXPIRY_HOURS);
    await updateFlutterBuild(build._id, { status: 'success', outputFile: apkOutputPath, completedAt: new Date(), expiredAt: expiredAt, message: 'Build berhasil!' });
    fs.rmSync(extractPath, { recursive: true, force: true });
  } catch (error) {
    await updateFlutterBuild(build._id, { status: 'failed', message: error.message, completedAt: new Date() });
  } finally {
    isProcessingBuild = false;
  }
}

setInterval(() => { cleanupExpiredBuilds(); processBuildQueue(); }, 5000);

// ===================== OTP SERVICE ROUTES =====================
app.get('/otp', isAuth, async (req, res) => {
  try {
    const servicesResult = await getRumahOTPServices();
    const orders = await getOTPOrders(req.session.userId);
    res.render('dashboard_otp', {
      services: servicesResult.success ? servicesResult.data : [],
      servicesError: servicesResult.error,
      orders: orders.slice(0, 5),
      user: res.locals.user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat halaman OTP';
    res.redirect('/dashboard');
  }
});

app.get('/otp/countries', isAuth, async (req, res) => {
  try {
    const { service_id, service_name, service_img } = req.query;
    const countries = await getRumahOTPCountries(service_id);
    res.render('negara_otp', {
      serviceId: service_id,
      serviceName: service_name || 'Unknown',
      serviceImg: service_img || '',
      countries: countries.success ? countries.data : [],
      user: res.locals.user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat daftar negara';
    res.redirect('/otp');
  }
});

app.get('/otp/operators', isAuth, async (req, res) => {
  try {
    const { country_id, country_name, country_price, provider_id, service_id, service_name, service_img } = req.query;
    const operators = await getRumahOTPOperators(country_name, provider_id);
    res.render('operator_otp', {
      serviceId: service_id,
      serviceName: service_name || 'Unknown',
      serviceImg: service_img || '',
      countryId: country_id,
      countryName: country_name || 'Unknown',
      countryPrice: country_price || '0',
      providerId: provider_id,
      operators: operators.success ? operators.data : [],
      user: res.locals.user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat daftar operator';
    res.redirect('/otp');
  }
});

app.post('/otp/order', isAuth, async (req, res) => {
  try {
    const { service_id, service_name, service_img, country_id, country_name, country_price, provider_id, operator_id, operator_name } = req.body;
    const user = res.locals.user;
    const basePrice = parseInt(country_price) || 0;
    const totalPrice = basePrice + OTP_ADMIN_FEE;
    if (user.balance < totalPrice) {
      req.session.errorMsg = `Saldo tidak cukup! Total: Rp ${totalPrice.toLocaleString()}`;
      return res.redirect(`/otp/operators?country_id=${country_id}&country_name=${encodeURIComponent(country_name)}&country_price=${basePrice}&provider_id=${provider_id}&service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
    }
    const orderResult = await orderRumahOTPNumber(country_id, provider_id, operator_id);
    if (!orderResult.success) {
      if (orderResult.error && orderResult.error.toLowerCase().includes('stock')) {
        req.session.errorMsg = 'Stock habis, silakan pilih server lain';
        return res.redirect(`/otp/countries?service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
      }
      throw new Error(orderResult.error || 'Gagal order');
    }
    user.balance -= totalPrice;
    await updateById('users', user._id, { $set: user });
    const newOrder = {
      _id: generateCustomId('OTP'),
      userId: user._id,
      serviceName: service_name,
      serviceImg: service_img,
      countryName: country_name,
      countryId: country_id,
      providerId: provider_id,
      serverId: operator_id,
      operatorName: operator_name,
      phoneNumber: orderResult.data.phone_number,
      orderId: orderResult.data.order_id,
      price: basePrice,
      adminFee: OTP_ADMIN_FEE,
      totalPrice: totalPrice,
      status: 'waiting',
      createdAt: new Date(),
      expiredAt: orderResult.data.expired_at ? new Date(orderResult.data.expired_at) : new Date(Date.now() + 10 * 60000)
    };
    await saveOTPOrder(newOrder);
    await sendAdminNotification('new_otp_order', { username: user.username, service: service_name, country: country_name, operator: operator_name, price: totalPrice });
    res.redirect(`/otp/order/${newOrder._id}`);
  } catch (error) {
    req.session.errorMsg = error.message || 'Gagal memesan OTP';
    res.redirect('/otp');
  }
});

app.get('/otp/order/:id', isAuth, async (req, res) => {
  try {
    let order = (await getOTPOrders()).find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      req.session.errorMsg = 'Order tidak ditemukan';
      return res.redirect('/otp');
    }
    if (order.status === 'waiting' && order.orderId) {
      const statusResult = await checkRumahOTPStatus(order.orderId);
      if (statusResult.success && statusResult.data) {
        const apiStatus = statusResult.data.status;
        const otpCode = statusResult.data.otp_code;
        if ((apiStatus === 'received' || apiStatus === 'completed') && otpCode) {
          order.otpCode = otpCode;
          order.otpMessage = statusResult.data.otp_msg;
          order.status = 'success';
          await updateOTPOrder(order._id, { otpCode: otpCode, otpMessage: statusResult.data.otp_msg, status: 'success' });
        } else if (apiStatus === 'expired' || apiStatus === 'canceled') {
          order.status = 'expired';
          await updateOTPOrder(order._id, { status: 'expired' });
          const user = await findById('users', order.userId);
          if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
        }
      }
      if (new Date() > new Date(order.expiredAt) && order.status === 'waiting') {
        order.status = 'expired';
        await updateOTPOrder(order._id, { status: 'expired' });
        const user = await findById('users', order.userId);
        if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
      }
    }
    res.render('order_otp', { order, user: res.locals.user });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat detail order';
    res.redirect('/otp');
  }
});

app.get('/otp/api/check/:id', isAuth, async (req, res) => {
  try {
    const orders = await getOTPOrders();
    const order = orders.find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      return res.json({ success: false, message: 'Order tidak ditemukan' });
    }
    let updated = false;
    let newStatus = order.status;
    if (order.status === 'waiting' && order.orderId) {
      const statusResult = await checkRumahOTPStatus(order.orderId);
      if (statusResult.success && statusResult.data) {
        const apiStatus = statusResult.data.status;
        const otpCode = statusResult.data.otp_code;
        if ((apiStatus === 'received' || apiStatus === 'completed') && otpCode) {
          await updateOTPOrder(order._id, { otpCode: otpCode, otpMessage: statusResult.data.otp_msg, status: 'success' });
          newStatus = 'success';
          updated = true;
          const user = await findById('users', order.userId);
          const adminChatId = await getAdminChatId();
          if (adminChatId && user) {
            await sendTelegramMessage(adminChatId, `OTP BERHASIL DITERIMA\n\nUser: ${user.username}\nLayanan: ${order.serviceName}\nNegara: ${order.countryName}\nKODE OTP: ${otpCode}\nPesan: ${statusResult.data.otp_msg?.substring(0, 100)}...\nWaktu: ${new Date().toLocaleString('id-ID')}`);
          }
        } else if (apiStatus === 'expired' || apiStatus === 'canceled') {
          await updateOTPOrder(order._id, { status: 'expired' });
          newStatus = 'expired';
          updated = true;
          const user = await findById('users', order.userId);
          if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
        }
      }
    }
    res.json({ success: true, status: newStatus, updated: updated });
  } catch (error) {
    res.json({ success: false, message: error.message });
  }
});

app.post('/otp/cancel/:id', isAuth, async (req, res) => {
  try {
    const orders = await getOTPOrders();
    const order = orders.find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      return res.json({ success: false, message: 'Order tidak ditemukan' });
    }
    if (order.status !== 'waiting') {
      return res.json({ success: false, message: 'Order tidak dapat dibatalkan' });
    }
    await cancelRumahOTPOrder(order.orderId);
    const user = await findById('users', order.userId);
    if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
    await updateOTPOrder(order._id, { status: 'cancelled' });
    res.json({ success: true, message: 'Order dibatalkan, saldo dikembalikan' });
  } catch (error) {
    res.json({ success: false, message: 'Gagal membatalkan order' });
  }
});

app.get('/otp/history', isAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 15;
    const filter = req.query.filter || 'all';
    const search = req.query.search || '';
    let orders = await getOTPOrders(req.session.userId);
    if (filter !== 'all') orders = orders.filter(o => o.status === filter);
    if (search) {
      const searchLower = search.toLowerCase();
      orders = orders.filter(o => o._id.toLowerCase().includes(searchLower) || o.serviceName.toLowerCase().includes(searchLower) || o.countryName.toLowerCase().includes(searchLower));
    }
    const totalOrders = orders.length;
    const totalPages = Math.ceil(totalOrders / limit);
    const startIndex = (page - 1) * limit;
    const paginatedOrders = orders.slice(startIndex, startIndex + limit);
    const successCount = orders.filter(o => o.status === 'success').length;
    const waitingCount = orders.filter(o => o.status === 'waiting').length;
    const expiredCount = orders.filter(o => o.status === 'expired').length;
    res.render('otp_history', { orders: paginatedOrders, totalOrders, successCount, waitingCount, expiredCount, currentPage: page, totalPages, limit, filter, search, user: res.locals.user });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat riwayat pesanan';
    res.redirect('/otp');
  }
});

// ===================== ADMIN OTP ROUTE =====================
app.get('/admin/otp', isAuth, isAdmin, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const filter = req.query.filter || 'all';
    const search = req.query.search || '';
    let orders = await getOTPOrders();
    const users = await readDB('users');
    orders = orders.map(order => {
      const user = users.find(u => u._id === order.userId);
      return { ...order, username: user?.username || 'Unknown', userEmail: user?.email || '-' };
    });
    if (filter !== 'all') orders = orders.filter(o => o.status === filter);
    if (search) {
      const searchLower = search.toLowerCase();
      orders = orders.filter(o => o._id.toLowerCase().includes(searchLower) || o.serviceName.toLowerCase().includes(searchLower) || o.countryName.toLowerCase().includes(searchLower) || o.username?.toLowerCase().includes(searchLower) || o.userEmail?.toLowerCase().includes(searchLower));
    }
    const totalOrders = orders.length;
    const totalGrossRevenue = orders.filter(o => o.status === 'success').reduce((sum, o) => sum + (o.totalPrice || 0), 0);
    const totalNetRevenue = orders.filter(o => o.status === 'success').reduce((sum, o) => sum + (o.adminFee || 0), 0);
    const successCount = orders.filter(o => o.status === 'success').length;
    const waitingCount = orders.filter(o => o.status === 'waiting').length;
    const expiredCount = orders.filter(o => o.status === 'expired').length;
    const providerBalance = await getRumahOTPBalance();
    const totalPages = Math.ceil(totalOrders / limit);
    const startIndex = (page - 1) * limit;
    const paginatedOrders = orders.slice(startIndex, startIndex + limit);
    res.render('admin_otp', {
      orders: paginatedOrders,
      stats: { totalOrders, totalGrossRevenue, totalNetRevenue, successCount, waitingCount, expiredCount },
      providerBalance: providerBalance.success ? providerBalance.data : null,
      providerBalanceError: providerBalance.error,
      currentPage: page, totalPages, limit, filter, search, totalOrders, adminFee: OTP_ADMIN_FEE, user: res.locals.user
    });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat data OTP';
    res.redirect('/admin/dashboard');
  }
});

// ===================== SEO ROUTES =====================
app.get('/sitemap.xml', async (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'sitemap.xml'));
});

app.get('/robots.txt', async (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'robots.txt'));
});

// ===================== NOTIFICATION ROUTES =====================
app.get('/admin/notifications', isAuth, isAdmin, async (req, res) => {
  const notifications = await getNotifications();
  res.render('admin_notifications', { notifications, user: res.locals.user });
});

app.post('/admin/notifications/create', isAuth, isAdmin, async (req, res) => {
  const { title, message, imageUrl, target, displayType } = req.body;
  const newNotif = {
    _id: generateCustomId('NOTIF'),
    title: title || 'Pengumuman',
    message: message || '',
    imageUrl: imageUrl || null,
    target: target || 'all',
    displayType: displayType || 'once',
    isActive: true,
    seenBy: [],
    createdAt: new Date(),
    updatedAt: new Date()
  };
  await saveNotification(newNotif);
  req.session.successMsg = 'Notifikasi berhasil dibuat!';
  res.redirect('/admin/notifications');
});

app.post('/admin/notifications/update/:id', isAuth, isAdmin, async (req, res) => {
  const { title, message, imageUrl, target, displayType, isActive } = req.body;
  await updateNotification(req.params.id, { title, message, imageUrl, target, displayType, isActive: isActive === 'on', updatedAt: new Date() });
  req.session.successMsg = 'Notifikasi berhasil diperbarui!';
  res.redirect('/admin/notifications');
});

app.post('/admin/notifications/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteNotification(req.params.id);
  req.session.successMsg = 'Notifikasi berhasil dihapus!';
  res.redirect('/admin/notifications');
});

app.get('/api/notifications/active', isAuth, async (req, res) => {
  const notifications = await getNotifications();
  const userNotifs = notifications.filter(n => {
    if (!n.isActive) return false;
    if (n.target !== 'all' && n.target !== req.session.userId) return false;
    if (n.displayType === 'once' && n.seenBy && n.seenBy.includes(req.session.userId)) return false;
    return true;
  });
  res.json({ success: true, notifications: userNotifs });
});

app.post('/api/notifications/seen/:id', isAuth, async (req, res) => {
  await markNotificationAsSeen(req.params.id, req.session.userId);
  res.json({ success: true });
});

// ===================== EVENT ROUTES =====================
app.get('/events', isAuth, async (req, res) => {
  try {
    const activeEvent = await getActiveEvent();
    const hasClaimed = activeEvent ? await hasUserClaimedEvent(req.session.userId, activeEvent._id) : false;
    res.render('events', { activeEvent: activeEvent || null, hasClaimed, user: res.locals.user });
  } catch (error) {
    req.session.errorMsg = 'Gagal memuat halaman event';
    res.redirect('/dashboard');
  }
});

app.post('/events/claim', isAuth, async (req, res) => {
  const { eventId, answer } = req.body;
  const events = await readDB('events');
  const event = events.find(e => e._id === eventId);
  if (!event) return res.json({ success: false, message: 'Event tidak ditemukan' });
  if (!event.isActive || new Date(event.expiredAt) < new Date()) return res.json({ success: false, message: 'Event sudah berakhir' });
  if (await hasUserClaimedEvent(req.session.userId, eventId)) return res.json({ success: false, message: 'Anda sudah pernah mengklaim hadiah event ini' });
  if (answer.toLowerCase().trim() !== event.answer.toLowerCase().trim()) return res.json({ success: false, message: 'Jawaban salah! Silakan coba lagi.' });
  const user = await findById('users', req.session.userId);
  user.balance += event.reward;
  await updateById('users', user._id, { $set: user });
  await addUserToEventClaimed(eventId, req.session.userId);
  await createWithRetry('transactions', {
    _id: generateCustomId(startId.transaction),
    userId: user._id,
    type: 'deposit',
    amount: event.reward,
    fee: 0,
    status: 'paid',
    reference: `EVENT_${event._id}`,
    createdAt: new Date()
  });
  res.json({ success: true, message: `Selamat! Anda mendapat Rp ${event.reward.toLocaleString()}`, reward: event.reward });
});

app.get('/admin/events', isAuth, isAdmin, async (req, res) => {
  const events = await getEvents();
  res.render('admin_events', { events, user: res.locals.user });
});

app.post('/admin/events/create', isAuth, isAdmin, async (req, res) => {
  const { title, question, answer, reward, expiredAt } = req.body;
  const newEvent = {
    _id: generateCustomId('EVENT'),
    title,
    question,
    answer: answer.toLowerCase().trim(),
    reward: parseInt(reward),
    isActive: true,
    claimedBy: [],
    createdAt: new Date(),
    expiredAt: new Date(expiredAt)
  };
  await saveEvent(newEvent);
  req.session.successMsg = 'Event berhasil dibuat!';
  res.redirect('/admin/events');
});

app.post('/admin/events/toggle/:id', isAuth, isAdmin, async (req, res) => {
  const events = await readDB('events');
  const event = events.find(e => e._id === req.params.id);
  if (event) {
    event.isActive = !event.isActive;
    await updateEvent(req.params.id, { isActive: event.isActive });
    req.session.successMsg = `Event ${event.isActive ? 'diaktifkan' : 'dinonaktifkan'}`;
  }
  res.redirect('/admin/events');
});

app.post('/admin/events/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteEvent(req.params.id);
  req.session.successMsg = 'Event berhasil dihapus!';
  res.redirect('/admin/events');
});

// ===================== CHAT ROUTES =====================
app.get('/chat', isAuth, async (req, res) => {
  const chatSettings = await getChatSettings();
  const messages = await getChatMessages(100);
  const isBlocked = chatSettings.blockedUsers.includes(req.session.userId);
  res.render('chat', { messages, chatSettings, isBlocked, user: res.locals.user });
});

app.post('/chat/send', isAuth, async (req, res) => {
  const { message } = req.body;
  if (!message || message.trim() === '') return res.json({ success: false, message: 'Pesan tidak boleh kosong' });
  const chatSettings = await getChatSettings();
  const isBlocked = chatSettings.blockedUsers.includes(req.session.userId);
  if (isBlocked && res.locals.user.role !== 'admin') return res.json({ success: false, message: 'Anda diblokir dari chat' });
  if (chatSettings.chatMode === 'admin' && res.locals.user.role !== 'admin') return res.json({ success: false, message: 'Mode chat hanya untuk admin saat ini' });
  const user = await findById('users', req.session.userId);
  const newMessage = {
    _id: generateCustomId('CHAT'),
    userId: user._id,
    username: user.username,
    message: message.trim(),
    role: user.role,
    createdAt: new Date()
  };
  await saveChatMessage(newMessage);
  res.json({ success: true });
});

app.get('/chat/messages', isAuth, async (req, res) => {
  const messages = await getChatMessages(100);
  res.json({ success: true, messages });
});

app.get('/admin/chat', isAuth, isAdmin, async (req, res) => {
  const messages = await getChatMessages(200);
  const users = await readDB('users');
  const chatSettings = await getChatSettings();
  res.render('admin_chat', { messages, users, chatSettings, user: res.locals.user });
});

app.post('/admin/chat/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteChatMessage(req.params.id);
  res.json({ success: true });
});

app.post('/admin/chat/clear', isAuth, isAdmin, async (req, res) => {
  await deleteAllChatMessages();
  res.json({ success: true });
});

app.post('/admin/chat/settings', isAuth, isAdmin, async (req, res) => {
  const { chatMode, blockedUsers } = req.body;
  const blockedArray = blockedUsers ? blockedUsers.split(',').map(id => id.trim()) : [];
  await updateChatSettings(chatMode, blockedArray);
  req.session.successMsg = 'Pengaturan chat diperbarui!';
  res.redirect('/admin/chat');
});

app.post('/admin/chat/block/:userId', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const blockedUsers = settings.blockedUsers || [];
  if (!blockedUsers.includes(req.params.userId)) {
    blockedUsers.push(req.params.userId);
    await updateChatSettings(settings.chatMode, blockedUsers);
  }
  res.json({ success: true });
});

app.post('/admin/chat/unblock/:userId', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const blockedUsers = (settings.blockedUsers || []).filter(id => id !== req.params.userId);
  await updateChatSettings(settings.chatMode, blockedUsers);
  res.json({ success: true });
});

// ===================== FLUTTER BUILD ROUTES =====================
app.get('/flutter-build', isAuth, async (req, res) => {
  const builds = await getFlutterBuilds(req.session.userId);
  res.render('flutter_build', { builds: builds.slice(0, 20), user: res.locals.user, buildCost: BUILD_COST, buildLimit: BUILD_LIMIT });
});

app.post('/flutter-build/upload', isAuth, upload.single('sourceCode'), async (req, res) => {
  try {
    const { flutterVersion, buildType } = req.body;
    const user = res.locals.user;
    const BUILD_COST_LIMIT = 5; // 5 limit per build
    
    // CEK LIMIT, BUKAN SALDO
    if (user.flutterLimit < BUILD_COST_LIMIT) {
      req.session.errorMsg = `Limit tidak cukup! Butuh ${BUILD_COST_LIMIT} limit. Silakan beli limit terlebih dahulu.`;
      return res.redirect('/flutter-buy-limit');
    }
    
    if (!req.file) {
      req.session.errorMsg = 'Silakan upload file ZIP source code Flutter';
      return res.redirect('/flutter-build');
    }
    
    if (!req.file.originalname.endsWith('.zip')) {
      fs.unlinkSync(req.file.path);
      req.session.errorMsg = 'File harus berekstensi .zip';
      return res.redirect('/flutter-build');
    }
    
    // KURANGI LIMIT, BUKAN SALDO
    user.flutterLimit -= BUILD_COST_LIMIT;
    await updateById('users', user._id, { $set: { flutterLimit: user.flutterLimit } });
    
    const newBuild = {
      _id: generateCustomId('BLD'),
      userId: user._id,
      username: user.username,
      flutterVersion: flutterVersion || 'stable',
      buildType: buildType || 'release',
      originalFile: req.file.path,
      outputFile: null,
      status: 'pending',
      message: 'Menunggu antrian build...',
      createdAt: new Date(),
      expiredAt: null,
      completedAt: null,
      limitUsed: BUILD_COST_LIMIT
    };
    
    await saveFlutterBuild(newBuild);
    
    req.session.successMsg = `Build ditambahkan ke antrian! Sisa limit: ${user.flutterLimit}`;
    res.redirect('/flutter-build');
    
  } catch (error) {
    req.session.errorMsg = 'Gagal memproses upload';
    res.redirect('/flutter-build');
  }
});

app.get('/flutter-build/download/:id', isAuth, async (req, res) => {
  const builds = await getFlutterBuilds();
  const build = builds.find(b => b._id === req.params.id);
  if (!build || build.userId !== req.session.userId) {
    req.session.errorMsg = 'Build tidak ditemukan';
    return res.redirect('/flutter-build');
  }
  if (build.status !== 'success') {
    req.session.errorMsg = 'Build belum selesai atau gagal';
    return res.redirect('/flutter-build');
  }
  if (new Date(build.expiredAt) < new Date()) {
    req.session.errorMsg = 'Link download sudah kadaluarsa (1 jam)';
    return res.redirect('/flutter-build');
  }
  if (!fs.existsSync(build.outputFile)) {
    req.session.errorMsg = 'File APK tidak ditemukan';
    return res.redirect('/flutter-build');
  }
  res.download(build.outputFile, `${build._id}.apk`);
});

app.get('/flutter-build/status/:id', isAuth, async (req, res) => {
  const builds = await getFlutterBuilds();
  const build = builds.find(b => b._id === req.params.id);
  if (!build || build.userId !== req.session.userId) return res.json({ success: false, message: 'Build tidak ditemukan' });
  res.json({ success: true, status: build.status, message: build.message, expiredAt: build.expiredAt, outputFile: build.status === 'success' ? `/flutter-build/download/${build._id}` : null });
});

app.get('/flutter-buy-limit', isAuth, async (req, res) => {
  res.render('flutter_buy_limit', { 
    packages: LIMIT_PACKAGES,
    user: res.locals.user
  });
});

app.post('/flutter-buy-limit', isAuth, async (req, res) => {
  try {
    const { limit, price } = req.body;
    const user = res.locals.user;
    const totalPrice = parseInt(price);
    const limitAmount = parseInt(limit);
    
    if (user.balance < totalPrice) {
      req.session.errorMsg = `Saldo tidak cukup! Harga: Rp ${totalPrice.toLocaleString()}`;
      return res.redirect('/flutter-buy-limit');
    }
    
    // Kurangi saldo, tambah limit
    user.balance -= totalPrice;
    user.flutterLimit += limitAmount;
    await updateById('users', user._id, { $set: { balance: user.balance, flutterLimit: user.flutterLimit } });
    
    // Catat transaksi
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId: user._id,
      type: 'deposit',
      amount: totalPrice,
      fee: 0,
      status: 'paid',
      reference: `FLUTTER_LIMIT_${limitAmount}`,
      createdAt: new Date()
    });
    
    req.session.successMsg = `Berhasil membeli ${limitAmount} limit Flutter! Sisa limit: ${user.flutterLimit}`;
    res.redirect('/flutter-build');
    
  } catch (error) {
    req.session.errorMsg = 'Gagal membeli limit';
    res.redirect('/flutter-buy-limit');
  }
});

// ===================== AUTO MUTASI =====================
let checkerInterval;
async function checkMutasi() {
  try {
    const settings = await getSettings();
    if (!settings.autoCheckEnabled || !settings.apiKey) return;
    let invoices = await readDB('invoices');
    const pendingInvoices = invoices.filter(i => i.status === 'pending');
    const now = new Date();
    for (const inv of pendingInvoices) {
      if (now > new Date(inv.expiredAt)) {
        inv.status = 'expired';
        await updateById('invoices', inv._id, { $set: inv });
        const transactions = await readDB('transactions');
        const tx = transactions.find(t => t.reference === inv._id.toString() && t.type === 'deposit' && t.status === 'pending');
        if (tx) { tx.status = 'expired'; await updateById('transactions', tx._id, { $set: tx }); }
      }
    }
    invoices = await readDB('invoices');
    const mutasiUrl = `https://${settings.apiDomain}/?action=mutasiqr&apikey=${settings.apiKey}&username=${settings.username}&token=${settings.token}`;
    const resp = await axios.get(mutasiUrl);
    const data = resp.data;
    if (!data.status || !data.result || !data.result.success || !Array.isArray(data.result.results)) return;
    const results = data.result.results;
    const usedMutationIds = invoices.filter(i => i.mutationId !== null).map(i => String(i.mutationId));
    const availableMutations = results.filter(tx => tx.status === 'IN' && !usedMutationIds.includes(String(tx.id)));
    for (const inv of invoices) {
      if (inv.status !== 'pending') continue;
      const matchedMutation = availableMutations.find(tx => {
        const nominal = parseInt(String(tx.kredit).replace(/\./g, ''));
        if (nominal !== inv.total) return false;
        const rawDateString = tx.tanggal || tx.created_at || tx.createdAt || tx.date || tx.datetime;
        if (!rawDateString) return false;
        let mutationTime;
        if (rawDateString.includes('/')) {
          const [datePart, timePart] = rawDateString.split(' ');
          const [day, month, year] = datePart.split('/');
          mutationTime = new Date(`${year}-${month}-${day}T${timePart}+07:00`);
        } else { mutationTime = new Date(rawDateString); }
        if (isNaN(mutationTime.getTime())) return false;
        const diffMinutes = Math.abs(mutationTime.getTime() - new Date(inv.createdAt).getTime()) / 1000 / 60;
        return diffMinutes <= 30;
      });
      if (!matchedMutation) continue;
      inv.status = 'paid';
      inv.mutationId = String(matchedMutation.id);
      await updateById('invoices', inv._id, { $set: inv });
      const user = await findById('users', inv.userId);
      if (user) { user.balance = (user.balance || 0) + inv.amount; await updateById('users', inv.userId, { $set: user }); }
      const transactions = await readDB('transactions');
      const tx = transactions.find(t => t.reference === inv._id.toString() && t.type === 'deposit' && t.status === 'pending');
      if (tx) { tx.status = 'paid'; await updateById('transactions', tx._id, { $set: tx }); }
      await updateOne('stats', {}, { $inc: { totalDepositAmount: inv.amount, totalDepositFee: inv.fee, totalTransactions: 1 } });
      const index = availableMutations.findIndex(tx => String(tx.id) === String(matchedMutation.id));
      if (index !== -1) availableMutations.splice(index, 1);
      const adminChatId = await getAdminChatId();
      if (adminChatId && user) {
        const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
        await sendTelegramMessage(adminChatId, `🌐 *Notifikasi - ${settings.name}*\n\n👤 *Informasi User*\n• User: ${user.username} (${user.email})\n• Saldo Saat Ini: Rp ${user.balance.toLocaleString('id-ID')}\n\n💰 *Informasi Deposit*\n• Jumlah: Rp ${inv.amount.toLocaleString('id-ID')}\n• Fee: Rp ${inv.fee.toLocaleString('id-ID')}\n• Total: Rp ${inv.total.toLocaleString('id-ID')}\n• ID Invoice: ${inv._id}\n• Waktu: ${timeString}\n• Status: Paid`);
      }
    }
  } catch (err) {}
}

async function updateStatsOnStartup() {
  const transactions = await readDB('transactions');
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;
  const stats = await findOne('stats', {});
  if (stats) {
    stats.totalDepositAmount = dAmount;
    stats.totalDepositFee = dFee;
    stats.totalWithdrawAmount = wAmount;
    stats.totalWithdrawFee = wFee;
    stats.totalUsers = totalUsers;
    stats.totalTransactions = totalTransactions;
    await updateById('stats', stats._id, { $set: stats });
  } else {
    await insertOne('stats', { _id: 'stats_1', totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions });
  }
}

function startChecker() {
  if (checkerInterval) clearInterval(checkerInterval);
  getSettings().then(s => {
    if (s.autoCheckEnabled) checkerInterval = setInterval(checkMutasi, s.checkInterval * 1000);
  });
}

setTimeout(async () => {
  await seed();
  await updateStatsOnStartup();
  startChecker();
  startTelegramPolling();
  scheduleAutoBackup();
  scheduleAutoRestart();
}, 2000);

app.listen(PORT, () => console.log(`🚀 Server berjalan di http://localhost:${PORT}`));