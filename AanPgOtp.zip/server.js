require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MemoryStore = require('memorystore')(session);
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const fs = require('fs');
const fsPromises = require('fs').promises;
const archiver = require('archiver');
const FormData = require('form-data');
const cron = require('node-cron');

const RECAPTCHA_SECRET_KEY = process.env.RECAPTCHA_SECRET_KEY || '';
const RECAPTCHA_SITE_KEY = process.env.RECAPTCHA_SITE_KEY || '';
const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;

const RUMAHOTP_API_KEY = 'rk-dev-sol08R6qixrUv2MU4jfSzaLostotmwgV';
const RUMAHOTP_BASE_URL = 'https://www.rumahotp.io/api/v2';
const OTP_ADMIN_FEE = 600;

const DEFAULT_PAKASIR_API_URL = 'https://app.pakasir.com/api';
const DEFAULT_PAKASIR_PROJECT = process.env.PAKASIR_PROJECT || 'depodomain';
const DEFAULT_PAKASIR_API_KEY = process.env.PAKASIR_API_KEY || '';

const TELEGRAM_CHANNEL_IDS = ['@aanchannell', '@aanpublic', '-1003961314465'];

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILES = {
  users: 'users.json',
  invoices: 'invoices.json',
  transactions: 'transactions.json',
  withdrawals: 'withdrawals.json',
  apiKeys: 'apikeys.json',
  settings: 'settings.json',
  stats: 'stats.json',
  otpOrders: 'otp_orders.json',
  notifications: 'notifications.json',
  events: 'events.json',
  chatMessages: 'chat_messages.json',
  userChatMessages: 'user_chat_messages.json',
  games: 'games.json'
};

const GAME_TYPES = {
  'hi-lo': {
    name: 'HI-LO',
    icon: 'fa-dice',
    description: 'Tebak angka HI (51-100) atau LO (1-50)',
    minBet: 1000,
    maxBet: 1000000,
    enabled: true,
    route: '/games/hi-lo',
    hasSettings: true
  },
  'coinflip': {
    name: 'Coin Flip',
    icon: 'fa-coins',
    description: 'Tebak HEAD (Kepala) atau TAIL (Ekor)',
    minBet: 1000,
    maxBet: 1000000,
    enabled: true,
    route: '/games/coinflip',
    hasSettings: true
  },
  'wheel': {
    name: 'Wheel of Fortune',
    icon: 'fa-circle',
    description: 'Putar roda keberuntungan',
    minBet: 2000,
    maxBet: 2000000,
    enabled: false,
    route: '/games/wheel',
    hasSettings: false
  },
  'dice': {
    name: 'Dice Roll',
    icon: 'fa-cubes',
    description: 'Lempar dadu dan tebak hasilnya',
    minBet: 1000,
    maxBet: 500000,
    enabled: false,
    route: '/games/dice',
    hasSettings: false
  },
  'crash': {
    name: 'Crash Game',
    icon: 'fa-rocket',
    description: 'Cashout sebelum crash!',
    minBet: 5000,
    maxBet: 5000000,
    enabled: false,
    route: '/games/crash',
    hasSettings: false
  }
};

const DEFAULT_GAME_CONFIG = {
  hiLo: {
    enabled: true,
    minBet: 1000,
    maxBet: 1000000,
    winRate: 75,
    maxWinMultiplier: 2,
    cooldown: 10,
    jackpotThreshold: 50000,
    houseEdge: 5
  },
  coinflip: {
    enabled: true,
    minBet: 1000,
    maxBet: 1000000,
    winRate: 75,
    maxWinMultiplier: 1.95,
    cooldown: 5,
    jackpotThreshold: 50000,
    houseEdge: 5
  }
};

// ============================================
// DUMMY DEPOSIT PROMOTION - FIXED VERSION
// ============================================

// Daftar username untuk dummy
const DUMMY_USERNAMES = [
  'Raka', 'rannyx', 'Dava', 'yanzx', 'Naya',
  'skyped', 'Rian', 'zaynx', 'Alya', 'reynx',
  'Keen', 'Jeno', 'nayyx', 'Farel', 'kaelx',
  'Rafa', 'vanyx', 'Zio', 'raynx', 'Caca',
  'Kian', 'jeynx', 'Dion', 'aeryx', 'Raya',
  'Nino', 'xavyn', 'Ares', 'levyn', 'Salsa',
  'Zara', 'ryven', 'Adit', 'kairo', 'Vira',
  'Daffa', 'ziven', 'Luna', 'rhexx', 'Fino',
  'Arka', 'nexy', 'Jihan', 'kaizen', 'Rafi',
  'Alvin', 'mivyx', 'Reno', 'syrex', 'Nayla',
  'Dimas', 'vexyn', 'Keanu', 'zaylen', 'Rania',
  'Fikri', 'aevyx', 'Rizky', 'kyzen', 'Nadia',
  'Aldo', 'reyven', 'Zahra', 'xavied', 'RakaX',
  'Ilham', 'nexz', 'Aurel', 'vynox', 'Rendy',
  'Celine', 'kaelz', 'Bima', 'zyrex', 'Nanda',
  'Rasya', 'mavyn', 'Dito', 'ravenx', 'Alika',
  'Farhan', 'xynza', 'Mika', 'jovyn', 'Aqila',
  'Rizal', 'veyza', 'Kyla', 'nexian', 'Fathan',
  'Nara', 'zayrix', 'Revan', 'aerynx', 'Dinda',
  'Kiko', 'vanyxz', 'RenoX', 'skynx', 'Ayla'
];
// Daftar nominal deposit (Rp) - lebih variatif
const DUMMY_AMOUNTS = [
  1000, 2000, 3000, 5000, 10000, 15000, 20000, 25000, 30000, 35000,
  40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000,
  90000, 95000, 100000, 110000, 120000, 130000, 140000, 150000, 160000, 
  170000, 180000, 190000, 200000, 250000, 300000, 350000, 400000, 450000, 
  500000, 550000, 600000, 650000, 700000, 750000, 800000, 850000, 900000, 
  950000, 1000000
];

// Flag untuk mengontrol dummy
let dummyDepositRunning = true;
let dummyInterval = null;

// Fungsi untuk generate random item dari array
function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Fungsi untuk generate random number antara min dan max
function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Fungsi untuk generate ID invoice dummy
function generateDummyInvoiceId() {
  const prefix = 'INV';
  const random = crypto.randomBytes(5).toString('hex').substring(0, 7);
  return prefix + random;
}

// Fungsi untuk generate Order ID dummy
function generateDummyOrderId() {
  const prefix = 'PAK';
  const random = crypto.randomBytes(5).toString('hex').substring(0, 7);
  return prefix + random;
}

// Versi dengan HTML (lebih aman dari masalah escape)
async function sendDummyDeposit() {
  try {
    const settings = await getSettings();
    if (!settings.telegramBotToken) {
      console.log('[DUMMY] Bot token tidak dikonfigurasi, skip dummy deposit');
      return;
    }

    const username = randomItem(DUMMY_USERNAMES);
    const amount = randomItem(DUMMY_AMOUNTS);
    const fee = Math.round(amount * 0.02);
    const total = amount + fee;
    const invoiceId = generateDummyInvoiceId();
    const orderId = generateDummyOrderId();
    const now = new Date();
    
    const timeString = now.toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).replace(/\./g, ':').replace(/,/, ',');

    // Escape untuk HTML
    function escapeHtml(text) {
      if (!text) return '';
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    const safeUsername = escapeHtml(username);
    const safeInvoiceId = escapeHtml(invoiceId);
    const safeOrderId = escapeHtml(orderId);
    const safeTimeString = escapeHtml(timeString);

    // Menggunakan HTML parse_mode
    const caption = 
      `<b>🌐 Azx Pedia</b>\n\n` +
      `<b>✅ Deposit Berhasil</b>\n` +
      `<b>User:</b> ${safeUsername}\n` +
      `<b>ID Invoice:</b> ${safeInvoiceId}\n` +
      `<b>Order ID:</b> ${safeOrderId}\n` +
      `<b>Jumlah:</b> Rp ${amount.toLocaleString('id-ID')}\n` +
      `<b>Fee:</b> Rp ${fee.toLocaleString('id-ID')}\n` +
      `<b>Total:</b> Rp ${total.toLocaleString('id-ID')}\n` +
      `<b>Metode:</b> Qris Payment\n` +
      `<b>Status:</b> ✅ Sukses\n\n` +
      `<i>${safeTimeString}</i>`;

    const replyMarkup = {
      inline_keyboard: [
        [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
      ]
    };

    for (const chatId of TELEGRAM_CHANNEL_IDS) {
      try {
        const token = settings.telegramBotToken;
        const formData = new FormData();
        formData.append('chat_id', chatId);
        formData.append('photo', 'https://cdn.yupra.my.id/yp/u61fubbu.png');
        formData.append('caption', caption);
        formData.append('parse_mode', 'HTML'); // Pakai HTML, lebih aman!
        formData.append('reply_markup', JSON.stringify(replyMarkup));
        
        await axios.post(`https://api.telegram.org/bot${token}/sendPhoto`, formData, {
          headers: formData.getHeaders(),
          timeout: 30000
        });
        
        console.log(`[DUMMY] ✅ Sent to ${chatId}: ${username} - Rp ${amount.toLocaleString('id-ID')}`);
      } catch (e) {
        console.error(`[DUMMY] ❌ Failed to send to ${chatId}:`, e.response?.data || e.message);
      }
    }

  } catch (error) {
    console.error('[DUMMY] Error sending dummy deposit:', error);
  }
}

// Fungsi untuk memulai dummy deposit
async function startDummyDeposit() {
  if (dummyDepositRunning) {
    console.log('[DUMMY] Already running');
    return;
  }
  
  const settings = await getSettings();
  if (!settings.telegramBotToken) {
    console.log('[DUMMY] ❌ Bot token tidak dikonfigurasi, dummy deposit tidak dijalankan');
    return;
  }
  
  dummyDepositRunning = true;
  console.log('[DUMMY] 🚀 Started dummy deposit (every 5 minutes)');
  
  // Kirim pertama kali setelah 5 detik
  setTimeout(async () => {
    console.log('[DUMMY] 📤 Sending initial dummy deposit...');
    await sendDummyDeposit();
  }, 5000);
  
  // Set interval 5 menit
  dummyInterval = setInterval(async () => {
    console.log('[DUMMY] ⏰ Scheduled dummy deposit at:', new Date().toLocaleString('id-ID'));
    await sendDummyDeposit();
  }, 5 * 60 * 1000); // 5 menit
}

// Fungsi untuk menghentikan dummy deposit
function stopDummyDeposit() {
  if (dummyInterval) {
    clearInterval(dummyInterval);
    dummyInterval = null;
  }
  dummyDepositRunning = false;
  console.log('[DUMMY] 🛑 Stopped dummy deposit');
}

// Fungsi untuk menjalankan dummy deposit sekali (manual trigger)
async function triggerDummyDeposit() {
  console.log('[DUMMY] 🔄 Manual trigger dummy deposit...');
  await sendDummyDeposit();
}

// ============================================
// DUMMY OTP CONFIGURATION
// ============================================

// Daftar layanan OTP dummy
const DUMMY_OTP_SERVICES = [
  { name: 'WhatsApp', country: 'Indonesia', operator: 'Telkomsel' },
  { name: 'Telegram', country: 'Indonesia', operator: 'Indosat' },
  { name: 'Instagram', country: 'Indonesia', operator: 'XL' },
  { name: 'Facebook', country: 'Indonesia', operator: 'Tri' },
  { name: 'Google', country: 'Indonesia', operator: 'Smartfren' },
  { name: 'Twitter/X', country: 'Indonesia', operator: 'Telkomsel' },
  { name: 'TikTok', country: 'Indonesia', operator: 'Indosat' },
  { name: 'Shopee', country: 'Indonesia', operator: 'XL' },
  { name: 'Gojek', country: 'Indonesia', operator: 'Tri' },
  { name: 'Grab', country: 'Indonesia', operator: 'Smartfren' },
  { name: 'WhatsApp', country: 'Malaysia', operator: 'Celcom' },
  { name: 'Telegram', country: 'Malaysia', operator: 'Digi' },
  { name: 'Instagram', country: 'Singapura', operator: 'Singtel' },
  { name: 'Facebook', country: 'Singapura', operator: 'StarHub' },
  { name: 'Google', country: 'Malaysia', operator: 'Maxis' },
];

// Daftar nomor telepon dummy (masked)
const DUMMY_PHONE_NUMBERS = [
  '0812-3456-7890', '0813-4567-8901', '0814-5678-9012', '0815-6789-0123',
  '0816-7890-1234', '0817-8901-2345', '0818-9012-3456', '0819-0123-4567',
  '0821-2345-6789', '0822-3456-7890', '0823-4567-8901', '0824-5678-9012',
  '0851-2345-6789', '0852-3456-7890', '0853-4567-8901', '0854-5678-9012',
  '0877-1234-5678', '0878-2345-6789', '0879-3456-7890', '0881-2345-6789',
];

// Daftar kode OTP dummy (4-6 digit)
const DUMMY_OTP_CODES = [
  '1234', '5678', '9012', '3456', '7890', 
  '2345', '6789', '0123', '4567', '8901',
  '123456', '654321', '987654', '456789', '321456',
  '789012', '234567', '567890', '901234', '345678'
];

// Daftar harga OTP dummy
const DUMMY_OTP_PRICES = [1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000];

// Flag untuk mengontrol dummy OTP
let dummyOtpRunning = false;
let dummyOtpInterval = null;

// Fungsi untuk generate dummy OTP data
function generateDummyOtpData() {
  const service = randomItem(DUMMY_OTP_SERVICES);
  const phone = randomItem(DUMMY_PHONE_NUMBERS);
  const otpCode = randomItem(DUMMY_OTP_CODES);
  const price = randomItem(DUMMY_OTP_PRICES);
  const adminFee = Math.round(price * 0.1); // 10% admin fee
  const totalPrice = price + adminFee;
  
  // Mask phone number (tampilkan sebagian)
  let maskedPhone = phone;
  if (maskedPhone.length > 4) {
    const last4 = maskedPhone.slice(-4);
    maskedPhone = '••••••' + last4;
  }
  
  // Mask OTP code (tampilkan sebagian)
  let maskedOtp = otpCode;
  if (maskedOtp.length > 2) {
    const last2 = maskedOtp.slice(-2);
    maskedOtp = '••••' + last2;
  }
  
  return {
    serviceName: service.name,
    countryName: service.country,
    operatorName: service.operator,
    phoneNumber: phone,
    maskedPhone: maskedPhone,
    otpCode: otpCode,
    maskedOtp: maskedOtp,
    price: price,
    adminFee: adminFee,
    totalPrice: totalPrice,
    username: randomItem(DUMMY_USERNAMES)
  };
}

// Fungsi untuk send dummy OTP success
async function sendDummyOtpSuccess() {
  try {
    const settings = await getSettings();
    if (!settings.telegramBotToken) {
      console.log('[DUMMY OTP] Bot token tidak dikonfigurasi, skip dummy OTP');
      return;
    }

    const data = generateDummyOtpData();
    const now = new Date();
    const timeString = now.toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    // Format caption dengan HTML (lebih aman)
    const caption = 
      `<b>✅ OTP BERHASIL DITERIMA</b>\n\n` +
      `<b>🌐 AzxPedia</b>\n\n` +
      `<b>👤 User:</b> ${data.username}\n` +
      `<b>📱 Layanan:</b> ${data.serviceName}\n` +
      `<b>🌍 Negara:</b> ${data.countryName}\n` +
      `<b>📡 Operator:</b> ${data.operatorName}\n` +
      `<b>💰 Harga:</b> Rp ${data.totalPrice.toLocaleString('id-ID')}\n` +
      `<b>📱 Nomor:</b> ${data.maskedPhone}\n` +
      `<b>🔑 Kode OTP:</b> ${data.maskedOtp}\n` +
      `<b>⏰ Waktu:</b> ${timeString}`;

    const replyMarkup = {
      inline_keyboard: [
        [{ text: '🌐 Layanan Nokos', url: 'https://app.azxpedia.my.id' }]
      ]
    };

    // Kirim ke semua channel
    for (const chatId of TELEGRAM_CHANNEL_IDS) {
      try {
        const token = settings.telegramBotToken;
        const formData = new FormData();
        formData.append('chat_id', chatId);
        formData.append('photo', 'https://cdn.yupra.my.id/yp/tftx606i.png');
        formData.append('caption', caption);
        formData.append('parse_mode', 'HTML');
        formData.append('reply_markup', JSON.stringify(replyMarkup));
        
        await axios.post(`https://api.telegram.org/bot${token}/sendPhoto`, formData, {
          headers: formData.getHeaders(),
          timeout: 30000
        });
        
        console.log(`[DUMMY OTP] ✅ Sent OTP success to ${chatId}: ${data.username} - ${data.serviceName} - ${data.maskedOtp}`);
      } catch (e) {
        console.error(`[DUMMY OTP] ❌ Failed to send to ${chatId}:`, e.response?.data || e.message);
      }
    }

  } catch (error) {
    console.error('[DUMMY OTP] Error sending dummy OTP:', error);
  }
}

// Fungsi untuk memulai dummy OTP
async function startDummyOtp() {
  if (dummyOtpRunning) {
    console.log('[DUMMY OTP] Already running');
    return;
  }
  
  const settings = await getSettings();
  if (!settings.telegramBotToken) {
    console.log('[DUMMY OTP] ❌ Bot token tidak dikonfigurasi, dummy OTP tidak dijalankan');
    return;
  }
  
  dummyOtpRunning = true;
  console.log('[DUMMY OTP] 🚀 Started dummy OTP (every 3 minutes)');
  
  // Kirim pertama kali setelah 15 detik
  setTimeout(async () => {
    console.log('[DUMMY OTP] 📤 Sending initial dummy OTP...');
    await sendDummyOtpSuccess();
  }, 15000);
  
  // Set interval 3 menit (lebih sering dari deposit)
  dummyOtpInterval = setInterval(async () => {
    console.log('[DUMMY OTP] ⏰ Scheduled dummy OTP at:', new Date().toLocaleString('id-ID'));
    await sendDummyOtpSuccess();
  }, 8 * 60 * 1000); // 3 menit
}

// Fungsi untuk menghentikan dummy OTP
function stopDummyOtp() {
  if (dummyOtpInterval) {
    clearInterval(dummyOtpInterval);
    dummyOtpInterval = null;
  }
  dummyOtpRunning = false;
  console.log('[DUMMY OTP] 🛑 Stopped dummy OTP');
}

// Fungsi untuk trigger manual
async function triggerDummyOtp() {
  console.log('[DUMMY OTP] 🔄 Manual trigger dummy OTP...');
  await sendDummyOtpSuccess();
}

// ============================================
// OTP ORDER WITH SMART DUMMY FALLBACK - FULL CODE
// ============================================

// Storage untuk dummy OTP yang pending
const dummyOtpStorage = {};

// ============================================
// FUNGSI UTILITY - FORMAT PHONE NUMBER
// ============================================

function formatPhoneNumberInternational(phoneNumber) {
  if (!phoneNumber) return '+62 812-3456-7890';
  
  let clean = phoneNumber.replace(/[^0-9]/g, '');
  
  if (clean.startsWith('0')) {
    clean = '62' + clean.substring(1);
  }
  
  if (clean.length >= 10) {
    let countryCode = '62';
    let rest = clean;
    
    const countryCodes = {
      '62': '62', '1': '1', '44': '44', '61': '61', '63': '63', '65': '65',
      '66': '66', '81': '81', '82': '82', '84': '84', '86': '86', '90': '90',
      '91': '91', '92': '92', '93': '93', '95': '95', '98': '98', '30': '30',
      '31': '31', '32': '32', '33': '33', '34': '34', '36': '36', '39': '39',
      '40': '40', '41': '41', '43': '43', '45': '45', '46': '46', '47': '47',
      '48': '48', '49': '49', '52': '52', '54': '54', '55': '55', '56': '56',
      '57': '57', '58': '58', '60': '60', '64': '64', '212': '212', '213': '213',
      '216': '216', '218': '218', '220': '220', '221': '221', '222': '222',
      '223': '223', '224': '224', '225': '225', '226': '226', '227': '227',
      '228': '228', '229': '229', '230': '230', '231': '231', '232': '232',
      '233': '233', '234': '234', '235': '235', '236': '236', '237': '237',
      '238': '238', '239': '239', '240': '240', '241': '241', '242': '242',
      '243': '243', '244': '244', '245': '245', '248': '248', '249': '249',
      '250': '250', '251': '251', '252': '252', '253': '253', '254': '254',
      '255': '255', '256': '256', '257': '257', '258': '258', '260': '260',
      '261': '261', '263': '263', '264': '264', '265': '265', '267': '267',
      '269': '269', '291': '291', '351': '351', '352': '352', '353': '353',
      '354': '354', '355': '355', '356': '356', '357': '357', '358': '358',
      '359': '359', '370': '370', '371': '371', '372': '372', '373': '373',
      '374': '374', '375': '375', '376': '376', '377': '377', '378': '378',
      '379': '379', '380': '380', '381': '381', '382': '382', '383': '383',
      '385': '385', '386': '386', '387': '387', '389': '389', '420': '420',
      '421': '421', '423': '423'
    };
    
    let found = false;
    for (const [code] of Object.entries(countryCodes)) {
      if (clean.startsWith(code)) {
        countryCode = code;
        rest = clean.substring(code.length);
        found = true;
        break;
      }
    }
    
    if (!found) {
      if (clean.length >= 4) {
        countryCode = clean.substring(0, 1);
        rest = clean.substring(1);
        if (clean.length >= 5 && parseInt(clean.substring(0, 2)) > 10) {
          countryCode = clean.substring(0, 2);
          rest = clean.substring(2);
        }
        if (clean.length >= 6 && parseInt(clean.substring(0, 3)) > 100) {
          countryCode = clean.substring(0, 3);
          rest = clean.substring(3);
        }
      } else {
        return phoneNumber;
      }
    }
    
    if (rest.length >= 8) {
      const part1 = rest.substring(0, 3);
      const part2 = rest.substring(3, 7);
      const part3 = rest.substring(7);
      return `+${countryCode} ${part1}-${part2}-${part3}`;
    } else if (rest.length >= 4) {
      const part1 = rest.substring(0, 2);
      const part2 = rest.substring(2, 6);
      const part3 = rest.substring(6);
      return `+${countryCode} ${part1}-${part2}-${part3}`;
    } else {
      return `+${countryCode} ${rest}`;
    }
  }
  
  return phoneNumber;
}

// ============================================
// FUNGSI GENERATE NOMOR TELEPON PER NEGARA
// ============================================

function generatePhoneNumberByCountry(countryName) {
  const countryPrefix = {
    'Indonesia': '62', 'Malaysia': '60', 'Singapura': '65', 'Thailand': '66',
    'Vietnam': '84', 'Filipina': '63', 'India': '91', 'USA': '1', 'UK': '44',
    'Australia': '61', 'Jepang': '81', 'Korea': '82', 'China': '86', 'Taiwan': '886',
    'Hong Kong': '852', 'Macau': '853', 'Brunei': '673', 'Kamboja': '855',
    'Laos': '856', 'Myanmar': '95', 'Timor Leste': '670', 'Papua Nugini': '675',
    'New Zealand': '64', 'Canada': '1', 'Mexico': '52', 'Brazil': '55',
    'Argentina': '54', 'Chile': '56', 'Peru': '51', 'Colombia': '57',
    'Venezuela': '58', 'Ecuador': '593', 'Bolivia': '591', 'Paraguay': '595',
    'Uruguay': '598', 'South Africa': '27', 'Nigeria': '234', 'Egypt': '20',
    'Kenya': '254', 'Ghana': '233', 'Tanzania': '255', 'Uganda': '256',
    'Zimbabwe': '263', 'Botswana': '267', 'Namibia': '264', 'Zambia': '260',
    'Mozambique': '258', 'Angola': '244', 'Morocco': '212', 'Algeria': '213',
    'Tunisia': '216', 'Libya': '218', 'Sudan': '249', 'Ethiopia': '251',
    'Somalia': '252', 'Djibouti': '253', 'Eritrea': '291', 'Mauritania': '222',
    'Senegal': '221', 'Mali': '223', 'Burkina Faso': '226', 'Niger': '227',
    'Chad': '235', 'Central African Republic': '236', 'Cameroon': '237',
    'Congo': '242', 'DR Congo': '243', 'Gabon': '241', 'Equatorial Guinea': '240',
    'Sao Tome': '239', 'Rwanda': '250', 'Burundi': '257', 'Malawi': '265',
    'Madagascar': '261', 'Comoros': '269', 'Mauritius': '230', 'Seychelles': '248',
    'Cape Verde': '238', 'Gambia': '220', 'Guinea': '224', 'Guinea-Bissau': '245',
    'Sierra Leone': '232', 'Liberia': '231', 'Ivory Coast': '225', 'Togo': '228',
    'Benin': '229', 'Saudi Arabia': '966', 'UAE': '971', 'Qatar': '974',
    'Kuwait': '965', 'Bahrain': '973', 'Oman': '968', 'Yemen': '967',
    'Jordan': '962', 'Lebanon': '961', 'Syria': '963', 'Iraq': '964',
    'Iran': '98', 'Turkey': '90', 'Pakistan': '92', 'Afghanistan': '93',
    'Nepal': '977', 'Bhutan': '975', 'Bangladesh': '880', 'Sri Lanka': '94',
    'Maldives': '960', 'Kazakhstan': '7', 'Uzbekistan': '998', 'Turkmenistan': '993',
    'Kyrgyzstan': '996', 'Tajikistan': '992', 'Armenia': '374', 'Azerbaijan': '994',
    'Georgia': '995', 'Moldova': '373', 'Belarus': '375', 'Russia': '7',
    'Ukraine': '380', 'Poland': '48', 'Czech Republic': '420', 'Slovakia': '421',
    'Hungary': '36', 'Romania': '40', 'Bulgaria': '359', 'Greece': '30',
    'Cyprus': '357', 'Italy': '39', 'Spain': '34', 'Portugal': '351',
    'Germany': '49', 'France': '33', 'Netherlands': '31', 'Belgium': '32',
    'Switzerland': '41', 'Austria': '43', 'Sweden': '46', 'Norway': '47',
    'Denmark': '45', 'Finland': '358', 'Iceland': '354', 'Ireland': '353'
  };

  let prefix = '62';
  const countryLower = countryName.toLowerCase();
  for (const [key, value] of Object.entries(countryPrefix)) {
    if (countryLower.includes(key.toLowerCase()) || key.toLowerCase().includes(countryLower)) {
      prefix = value;
      break;
    }
  }

  let number = '';
  let numLength = 10;
  
  if (prefix === '62') {
    number = '8' + String(Math.floor(Math.random() * 900000000) + 100000000);
    numLength = 10;
  } else if (prefix === '63') {
    number = '9' + String(Math.floor(Math.random() * 900000000) + 100000000);
    numLength = 10;
  } else if (prefix === '91') {
    const firstDigit = Math.floor(Math.random() * 4) + 6;
    number = String(firstDigit) + String(Math.floor(Math.random() * 900000000) + 100000000);
    numLength = 10;
  } else if (prefix === '1') {
    const firstDigit = Math.floor(Math.random() * 8) + 2;
    number = String(firstDigit) + String(Math.floor(Math.random() * 900000000) + 100000000);
    numLength = 10;
  } else if (prefix === '44') {
    number = '7' + String(Math.floor(Math.random() * 900000000) + 100000000);
    numLength = 10;
  } else if (prefix === '86') {
    number = '1' + String(Math.floor(Math.random() * 9000000000) + 1000000000);
    numLength = 11;
  } else if (prefix === '886' || prefix === '852' || prefix === '853' || prefix === '855' || prefix === '856') {
    numLength = 9;
    for (let i = 0; i < numLength; i++) {
      number += Math.floor(Math.random() * 10);
    }
  } else if (prefix === '95' || prefix === '977' || prefix === '880' || prefix === '94') {
    numLength = 10;
    for (let i = 0; i < numLength; i++) {
      number += Math.floor(Math.random() * 10);
    }
  } else {
    if (['65', '66', '84', '61', '81', '82', '60', '64'].includes(prefix)) {
      numLength = 9;
    } else if (['673', '670', '675', '960', '230', '248', '238', '220', '224', '245', '232', '231', '225', '228', '229'].includes(prefix)) {
      numLength = 8;
    } else {
      numLength = 9;
    }
    for (let i = 0; i < numLength; i++) {
      number += Math.floor(Math.random() * 10);
    }
  }

  const fullNumber = prefix + number;
  
  if (fullNumber.length >= 10) {
    const prefixLen = prefix.length;
    const rest = fullNumber.substring(prefixLen);
    const part1 = rest.substring(0, 3);
    const part2 = rest.substring(3, 7);
    const part3 = rest.substring(7);
    return `+${prefix} ${part1}-${part2}-${part3}`;
  } else if (fullNumber.length >= 8) {
    const prefixLen = prefix.length;
    const rest = fullNumber.substring(prefixLen);
    const part1 = rest.substring(0, 2);
    const part2 = rest.substring(2, 6);
    const part3 = rest.substring(6);
    return `+${prefix} ${part1}-${part2}-${part3}`;
  } else {
    return `+${prefix} ${number}`;
  }
}

// ============================================
// FUNGSI UTILITY LAINNYA
// ============================================

function generateOtpCode() {
  const length = Math.random() > 0.5 ? 4 : 6;
  let code = '';
  for (let i = 0; i < length; i++) {
    code += Math.floor(Math.random() * 10);
  }
  return code;
}

function maskPhoneNumber(phone) {
  if (!phone) return '••••••••••';
  const clean = phone.replace(/[^0-9]/g, '');
  if (clean.length > 4) {
    const last4 = clean.slice(-4);
    const prefix = clean.slice(0, -4);
    const maskedPrefix = prefix.replace(/[0-9]/g, '•');
    return maskedPrefix + last4;
  }
  return '••••' + clean;
}

function maskOtp(otp) {
  if (!otp) return '••••••';
  const clean = otp.replace(/[^0-9]/g, '');
  if (clean.length > 2) {
    const last2 = clean.slice(-2);
    const prefix = clean.slice(0, -2);
    const maskedPrefix = prefix.replace(/[0-9]/g, '•');
    return maskedPrefix + last2;
  }
  return '••••' + clean;
}

function getWaktuJakarta() {
  const now = new Date();
  const date = now.toLocaleDateString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
  const time = now.toLocaleTimeString('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).replace(/:/g, '.');
  return `${date}, ${time}`;
}

function formatRupiah(amount) {
  return 'Rp ' + amount.toLocaleString('id-ID').replace(/,/g, '.');
}

// ============================================
// SERVE ASSETS FOLDER
// ============================================
const ASSETS_DIR = path.join(__dirname, 'assets');

// Pastikan folder assets ada
if (!fs.existsSync(ASSETS_DIR)) {
  fs.mkdirSync(ASSETS_DIR, { recursive: true });
  
  // Buat placeholder jika file belum ada
  const placeholders = ['logo.jpg', 'information.jpg', 'welcome.jpg', 'peringatan.jpg'];
  for (const file of placeholders) {
    const filePath = path.join(ASSETS_DIR, file);
    if (!fs.existsSync(filePath)) {
      // Copy default logo jika ada
      try {
        const defaultLogo = path.join(__dirname, 'public', 'default-logo.jpg');
        if (fs.existsSync(defaultLogo)) {
          fs.copyFileSync(defaultLogo, filePath);
        }
      } catch (e) {}
    }
  }
}

// 2FA & RATE LIMITING
const ADMIN_CHAT_ID_2FA = '8038424443';
const otpStore = {};
const loginAttempts = {};
const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_TIME = 15 * 60 * 1000;

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function checkLoginRateLimit(ip) {
  const key = `login_${ip}`;
  if (loginAttempts[key] && loginAttempts[key].locked) {
    if (loginAttempts[key].lockedUntil > Date.now()) {
      const timeLeft = Math.ceil((loginAttempts[key].lockedUntil - Date.now()) / 60000);
      return { blocked: true, timeLeft };
    }
    delete loginAttempts[key];
  }
  return { blocked: false };
}

function recordFailedLogin(ip) {
  const key = `login_${ip}`;
  if (!loginAttempts[key]) {
    loginAttempts[key] = { count: 0, locked: false, lockedUntil: null };
  }
  loginAttempts[key].count++;
  if (loginAttempts[key].count >= MAX_LOGIN_ATTEMPTS) {
    loginAttempts[key].locked = true;
    loginAttempts[key].lockedUntil = Date.now() + LOCK_TIME;
  }
}

function resetLoginAttempts(ip) {
  delete loginAttempts[`login_${ip}`];
}

async function sendAdminOTP(chatId, code, username) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return false;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
      chat_id: chatId,
      text: `🔐 *KODE VERIFIKASI 2FA*\n\n` +
            `👤 *Username:* ${username}\n` +
            `🔑 *Kode OTP:* *${code}*\n\n` +
            `⏰ Kode ini berlaku *5 menit*.\n` +
            `⚠️ Jangan berikan kode ini kepada siapapun!`,
      parse_mode: 'Markdown'
    });
    return true;
  } catch (error) {
    console.error('[2FA] Failed to send OTP:', error.response?.data || error.message);
    return false;
  }
}

function loginRateLimiter(req, res, next) {
  const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  const check = checkLoginRateLimit(ip);
  if (check.blocked) {
    req.session.errorMsg = `Terlalu banyak percobaan login. Coba lagi dalam ${check.timeLeft} menit.`;
    return res.redirect('/login');
  }
  next();
}

function generateCoinFlipResult(winRate) {
  const random = Math.random() * 100;
  const isWin = random <= winRate;
  const coin = Math.random() < 0.5 ? 'HEAD' : 'TAIL';
  return { coin, isWin, winRate };
}

function generateGameResult(winRate) {
  const random = Math.random() * 100;
  const isWin = random <= winRate;
  const number = Math.floor(Math.random() * 100) + 1;
  const result = number >= 51 ? 'HI' : 'LO';
  return { number, result, isWin, winRate };
}

function calculatePayout(bet, isWin, multiplier = 2) {
  if (!isWin) return 0;
  return bet * multiplier;
}

async function saveGameHistory(userId, gameData) {
  const games = await readDB('games');
  games.push({
    _id: generateCustomId('GAME'),
    userId: userId,
    ...gameData,
    createdAt: new Date()
  });
  await writeDB('games', games);
  return true;
}

async function getGameHistory(userId, limit = 20) {
  const games = await readDB('games');
  const userGames = games.filter(g => g.userId === userId);
  return userGames.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
}

async function getGameStats() {
  const games = await readDB('games');
  const totalGames = games.length;
  const totalWins = games.filter(g => g.isWin).length;
  const totalBets = games.reduce((sum, g) => sum + (g.bet || 0), 0);
  const totalPayouts = games.reduce((sum, g) => sum + (g.winAmount || 0), 0);
  const houseProfit = totalBets - totalPayouts;
  return {
    totalGames,
    totalWins,
    totalLosses: totalGames - totalWins,
    winRate: totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0,
    totalBets,
    totalPayouts,
    houseProfit,
    houseEdge: totalBets > 0 ? Math.round((houseProfit / totalBets) * 100) : 0
  };
}

const AI_API_URL = 'https://api.siputzx.my.id/api/ai/gptoss120b';
const CS_SYSTEM_PROMPT = `Kamu adalah Customer Service dari AzxPedia, platform payment gateway Indonesia.

Aturan:
1. Bersikap profesional, sopan, dan ramah
2. Gunakan bahasa Indonesia yang baik dan benar
3. Jawaban singkat, padat, dan jelas (maksimal 3-4 kalimat)
4. Jangan menjawab pertanyaan di luar topik layanan
5. Jika ditanya tentang teknis di luar layanan, arahkan ke admin

Informasi Layanan:
- Nama: AzxPedia
- Layanan: Deposit QRIS, Withdraw Saldo, OTP, Payment Gateway
- Metode Pembayaran: QRIS Pakasir
- Deposit minimal: Rp 1.000
- Withdraw minimal: Rp 5.000
- Fee withdraw: Rp 1.000
- Proses deposit: 5-10 menit (otomatis)
- Proses withdraw: 10-20 menit (manual admin)
- Saldo akan otomatis bertambah setelah pembayaran terdeteksi

Jam Operasional: 24/7 (respon cepat 08:00-22:00 WIB)

Kontak Darurat:
- WhatsApp: 08988106426
- Telegram: @AanzCuyxzzz

Jika user marah/mengeluh: tetap tenang, minta maaf, dan tawarkan solusi.
Jika user menanyakan hal di luar layanan: katakan "Maaf, saya hanya bisa membantu pertanyaan seputar layanan AzxPedia. Untuk pertanyaan lain, silakan hubungi admin kami di WhatsApp 08988106426."`;

async function getAIResponse(userMessage, chatHistory = []) {
  try {
    const settings = await getSettings();
    if (settings.aiEnabled === false) return null;
    let chatContext = '';
    if (chatHistory && chatHistory.length > 0) {
      const recentHistory = chatHistory.slice(-5);
      chatContext = recentHistory.map(msg => {
        const sender = msg.userId === 'admin' ? 'CS' : 'User';
        return `${sender}: ${msg.message}`;
      }).join('\n');
    }
    let prompt = userMessage;
    if (chatContext) prompt = `Riwayat chat:\n${chatContext}\n\nUser: ${userMessage}`;
    const response = await axios.get(AI_API_URL, {
      params: { prompt, system: CS_SYSTEM_PROMPT, temperature: 0.7 },
      timeout: 30000
    });
    if (response.data?.status && response.data.data) {
      return response.data.data.response || 'Maaf, saya tidak bisa menjawab pertanyaan itu. Silakan hubungi admin di WhatsApp 08988106426.';
    }
    return 'Maaf, AI sedang sibuk. Silakan hubungi admin di WhatsApp 08988106426.';
  } catch (error) {
    console.error('[AI] Error:', error.message);
    if (error.code === 'ECONNABORTED') {
      return 'Maaf, koneksi ke AI timeout. Silakan coba lagi atau hubungi admin di WhatsApp 08988106426.';
    }
    return 'Maaf, sistem AI sedang sibuk. Silakan hubungi admin langsung di WhatsApp 08988106426 atau Telegram @AanzCuyxzzz.';
  }
}

function needsHumanAgent(message) {
  const keywords = ['admin', 'manusia', 'orang', 'cs', 'customer service', 'bantuan langsung', 'telpon', 'telepon', 'wa', 'whatsapp', 'telegram', 'hubungi', 'call', 'chat langsung', 'live chat', 'agent', 'orang'];
  return keywords.some(kw => message.toLowerCase().includes(kw));
}

async function getEvents() {
  const events = await readDB('events');
  return events.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function getActiveEvent() {
  const events = await readDB('events');
  const now = new Date();
  return events.find(e => e.isActive && new Date(e.expiredAt) > now) || null;
}

async function saveEvent(eventData) {
  const events = await readDB('events');
  events.push(eventData);
  await writeDB('events', events);
  return eventData;
}

async function updateEvent(eventId, updateData) {
  const events = await readDB('events');
  const index = events.findIndex(e => e._id === eventId);
  if (index !== -1) {
    Object.assign(events[index], updateData);
    await writeDB('events', events);
    return true;
  }
  return false;
}

async function deleteEvent(eventId) {
  const events = await readDB('events');
  await writeDB('events', events.filter(e => e._id !== eventId));
  return true;
}

async function hasUserClaimedEvent(userId, eventId) {
  const events = await readDB('events');
  const event = events.find(e => e._id === eventId);
  return event?.claimedBy?.includes(userId) || false;
}

async function addUserToEventClaimed(eventId, userId) {
  const events = await readDB('events');
  const index = events.findIndex(e => e._id === eventId);
  if (index !== -1) {
    if (!events[index].claimedBy) events[index].claimedBy = [];
    if (!events[index].claimedBy.includes(userId)) {
      events[index].claimedBy.push(userId);
      await writeDB('events', events);
      return true;
    }
  }
  return false;
}

function deduplicateMessages(messages) {
  if (!Array.isArray(messages) || messages.length === 0) return messages || [];
  const seen = new Set();
  return messages.filter(msg => {
    if (!msg || !msg._id) return false;
    if (seen.has(msg._id)) return false;
    seen.add(msg._id);
    return true;
  });
}

async function getChatMessages(limit = 50) {
  const messages = await readDB('chatMessages');
  if (!Array.isArray(messages)) return [];
  const sorted = messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return deduplicateMessages(sorted.slice(0, limit).reverse());
}

async function saveChatMessage(messageData) {
  const messages = await readDB('chatMessages');
  if (!Array.isArray(messages)) {
    await writeDB('chatMessages', []);
    return saveChatMessage(messageData);
  }
  if (messages.some(m => m._id === messageData._id)) return messageData;
  messages.push(messageData);
  if (messages.length > 500) {
    const sorted = messages.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    await writeDB('chatMessages', sorted.slice(-500));
  } else {
    await writeDB('chatMessages', messages);
  }
  return messageData;
}

async function deleteChatMessage(messageId) {
  const messages = await readDB('chatMessages');
  await writeDB('chatMessages', messages.filter(m => m._id !== messageId));
  return true;
}

async function deleteAllChatMessages() {
  await writeDB('chatMessages', []);
  return true;
}

async function getChatSettings() {
  const settings = await getSettings();
  return { chatMode: settings.chatMode || 'admin', blockedUsers: settings.blockedUsers || [] };
}

async function updateChatSettings(mode, blockedUsers) {
  const settings = await getSettings();
  settings.chatMode = mode;
  settings.blockedUsers = blockedUsers;
  await updateById('settings', settings._id, { $set: settings });
}

async function markManyUserChatRead(messageIds, readerId) {
  if (!messageIds || !Array.isArray(messageIds) || messageIds.length === 0) return 0;
  const messages = await readDB('userChatMessages');
  if (!Array.isArray(messages)) return 0;
  let updatedCount = 0;
  const idSet = new Set(messageIds);
  const updatedMessages = messages.map(msg => {
    if (idSet.has(msg._id)) {
      if (!msg.readBy) msg.readBy = [];
      if (!msg.readBy.includes(readerId)) {
        updatedCount++;
        return { ...msg, readBy: [...msg.readBy, readerId] };
      }
    }
    return msg;
  });
  if (updatedCount > 0) await writeDB('userChatMessages', updatedMessages);
  return updatedCount;
}

async function markUserChatRead(messageId, userId) {
  return markManyUserChatRead([messageId], userId);
}

async function getUserChatMessages(userId = null, limit = 100) {
  const messages = await readDB('userChatMessages');
  if (!Array.isArray(messages)) return [];
  let filtered = messages;
  if (userId) {
    filtered = messages.filter(m => m.userId === userId || m.targetUserId === userId || (m.userId === 'admin' && m.targetUserId === userId));
  }
  const sorted = filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return deduplicateMessages(sorted.slice(0, limit).reverse());
}

async function saveUserChatMessage(messageData) {
  const messages = await readDB('userChatMessages');
  if (!Array.isArray(messages)) {
    await writeDB('userChatMessages', []);
    return saveUserChatMessage(messageData);
  }
  if (messages.some(m => m._id === messageData._id)) return messageData;
  messages.push(messageData);
  if (messages.length > 2000) {
    const sorted = messages.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    await writeDB('userChatMessages', sorted.slice(-2000));
  } else {
    await writeDB('userChatMessages', messages);
  }
  return messageData;
}

async function getUnreadChatCount(userId) {
  const messages = await readDB('userChatMessages');
  if (!Array.isArray(messages)) return 0;
  return messages.filter(m =>
    ((m.targetUserId === userId || m.userId === userId) &&
      (!m.readBy || !m.readBy.includes(userId)) &&
      m.userId !== userId)
  ).length;
}

async function getChatList() {
  const messages = await readDB('userChatMessages');
  const users = await readDB('users');
  if (!Array.isArray(messages) || !Array.isArray(users)) return [];
  const userMap = {};
  users.forEach(u => { if (u && u._id) userMap[u._id] = u; });
  const chatGroups = {};
  messages.forEach(msg => {
    let userId = null;
    if (msg.userId && msg.userId !== 'admin') userId = msg.userId;
    else if (msg.targetUserId && msg.targetUserId !== 'admin') userId = msg.targetUserId;
    if (userId) {
      if (!chatGroups[userId]) chatGroups[userId] = [];
      chatGroups[userId].push(msg);
    }
  });
  const chatList = [];
  for (const [userId, userMessages] of Object.entries(chatGroups)) {
    const sorted = userMessages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const lastMessage = sorted[0] || null;
    const unread = userMessages.filter(msg => msg.userId === userId && (!msg.readBy || !msg.readBy.includes('admin'))).length;
    const user = userMap[userId];
    chatList.push({
      userId,
      username: user ? user.username : 'Unknown User',
      email: user ? user.email : '',
      lastMessage: lastMessage ? { message: lastMessage.message, createdAt: lastMessage.createdAt, sender: lastMessage.userId === 'admin' ? 'admin' : 'user' } : null,
      lastMessageTime: lastMessage ? lastMessage.createdAt : null,
      unreadCount: unread
    });
  }
  return chatList.sort((a, b) => new Date(b.lastMessageTime || 0) - new Date(a.lastMessageTime || 0));
}

async function deleteChatMessageById(messageId, userId, isAdmin = false) {
  const messages = await readDB('userChatMessages');
  if (!Array.isArray(messages)) return false;
  const msg = messages.find(m => m._id === messageId);
  if (!msg) return false;
  if (!isAdmin && msg.userId !== userId) return false;
  await writeDB('userChatMessages', messages.filter(m => m._id !== messageId));
  return true;
}

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
for (const [key, filename] of Object.entries(DB_FILES)) {
  const filepath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filepath)) fs.writeFileSync(filepath, JSON.stringify([], null, 2));
}

async function readDB(collection) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    return JSON.parse(await fsPromises.readFile(filepath, 'utf8'));
  } catch (error) {
    console.error(`Error reading ${collection}:`, error);
    return [];
  }
}

async function writeDB(collection, data) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    await fsPromises.writeFile(filepath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Error writing ${collection}:`, error);
    return false;
  }
}

async function findOne(collection, query) {
  const data = await readDB(collection);
  return data.find(item => Object.entries(query).every(([key, value]) => item[key] === value));
}

async function find(collection, query = {}) {
  const data = await readDB(collection);
  if (!Object.keys(query).length) return data;
  return data.filter(item => Object.entries(query).every(([key, value]) => item[key] === value));
}

async function findById(collection, id) {
  const data = await readDB(collection);
  return data.find(item => item._id === id);
}

async function insertOne(collection, document) {
  const data = await readDB(collection);
  data.push(document);
  await writeDB(collection, data);
  return document;
}

async function updateOne(collection, query, update) {
  const data = await readDB(collection);
  let updated = false;
  for (let i = 0; i < data.length; i++) {
    if (Object.entries(query).every(([key, value]) => data[i][key] === value)) {
      if (update.$set) Object.assign(data[i], update.$set);
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      updated = true;
      break;
    }
  }
  if (updated) await writeDB(collection, data);
  return { modifiedCount: updated ? 1 : 0 };
}

async function updateById(collection, id, update) {
  const data = await readDB(collection);
  for (let i = 0; i < data.length; i++) {
    if (data[i]._id === id) {
      if (update.$set) Object.assign(data[i], update.$set);
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      await writeDB(collection, data);
      return true;
    }
  }
  return false;
}

async function deleteOne(collection, query) {
  const data = await readDB(collection);
  for (let i = 0; i < data.length; i++) {
    if (Object.entries(query).every(([key, value]) => data[i][key] === value)) {
      data.splice(i, 1);
      await writeDB(collection, data);
      return { deletedCount: 1 };
    }
  }
  return { deletedCount: 0 };
}

async function deleteMany(collection, query) {
  const data = await readDB(collection);
  if (!Object.keys(query).length) {
    const count = data.length;
    await writeDB(collection, []);
    return { deletedCount: count };
  }
  const filtered = data.filter(item => !Object.entries(query).every(([key, value]) => item[key] === value));
  const deletedCount = data.length - filtered.length;
  await writeDB(collection, filtered);
  return { deletedCount };
}

async function countDocuments(collection, query = {}) {
  const data = await readDB(collection);
  if (!Object.keys(query).length) return data.length;
  return data.filter(item => Object.entries(query).every(([key, value]) => item[key] === value)).length;
}

async function getNotifications(userId = null) {
  const notifs = await readDB('notifications');
  if (userId) {
    return notifs.filter(n => n.userId === userId || n.target === 'all').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return notifs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveNotification(notifData) {
  const notifs = await readDB('notifications');
  notifs.push(notifData);
  await writeDB('notifications', notifs);
  return notifData;
}

async function updateNotification(notifId, updateData) {
  const notifs = await readDB('notifications');
  const index = notifs.findIndex(n => n._id === notifId);
  if (index !== -1) {
    Object.assign(notifs[index], updateData);
    await writeDB('notifications', notifs);
    return true;
  }
  return false;
}

async function deleteNotification(notifId) {
  const notifs = await readDB('notifications');
  await writeDB('notifications', notifs.filter(n => n._id !== notifId));
  return true;
}

async function markNotificationAsSeen(notifId, userId) {
  const notifs = await readDB('notifications');
  const index = notifs.findIndex(n => n._id === notifId);
  if (index !== -1) {
    if (!notifs[index].seenBy) notifs[index].seenBy = [];
    if (!notifs[index].seenBy.includes(userId)) {
      notifs[index].seenBy.push(userId);
      await writeDB('notifications', notifs);
    }
    return true;
  }
  return false;
}

async function getOTPOrders(userId = null) {
  const orders = await readDB('otpOrders');
  if (userId) {
    return orders.filter(o => o.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveOTPOrder(orderData) {
  const orders = await readDB('otpOrders');
  orders.push(orderData);
  await writeDB('otpOrders', orders);
  return orderData;
}

async function updateOTPOrder(orderId, updateData) {
  const orders = await readDB('otpOrders');
  const index = orders.findIndex(o => o._id === orderId);
  if (index !== -1) {
    Object.assign(orders[index], updateData);
    await writeDB('otpOrders', orders);
    return true;
  }
  return false;
}

async function createPakasirQRIS(amount, orderId) {
  try {
    const settings = await getSettings();
    const project = settings.pakasirProject || DEFAULT_PAKASIR_PROJECT;
    const apiKey = settings.pakasirApiKey || DEFAULT_PAKASIR_API_KEY;
    if (!apiKey) return { success: false, error: 'API Key Pakasir belum dikonfigurasi' };
    const payload = { project, order_id: orderId, amount, api_key: apiKey };
    const response = await axios.post(`${DEFAULT_PAKASIR_API_URL}/transactioncreate/qris`, payload, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });
    if (response.data?.payment) {
      const payment = response.data.payment;
      return {
        success: true,
        image_url: '',
        qr_string: payment.payment_number || '',
        trxid: payment.order_id || orderId,
        expired: payment.expired_at || new Date(Date.now() + 10 * 60000).toISOString(),
        nominal: payment.amount || amount,
        total_payment: payment.total_payment || amount,
        fee: payment.fee || 0,
        payment_method: payment.payment_method || 'qris',
        payment_number: payment.payment_number || '',
        raw: payment
      };
    }
    return { success: false, error: response.data?.message || 'Gagal membuat Qris Payment' };
  } catch (error) {
    console.error('[PAKASIR] Create QRIS error:', error.response?.data || error.message);
    return { success: false, error: error.response?.data?.message || error.message };
  }
}

async function checkPakasirTransaction(orderId, amount) {
  try {
    const settings = await getSettings();
    const project = settings.pakasirProject || DEFAULT_PAKASIR_PROJECT;
    const apiKey = settings.pakasirApiKey || DEFAULT_PAKASIR_API_KEY;
    if (!apiKey) return { success: false, data: null, error: 'API Key Pakasir belum dikonfigurasi' };
    const url = `${DEFAULT_PAKASIR_API_URL}/transactiondetail?project=${project}&amount=${amount}&order_id=${orderId}&api_key=${apiKey}`;
    const response = await axios.get(url, { timeout: 30000 });
    if (response.data?.transaction) return { success: true, data: response.data.transaction };
    return { success: false, data: null, error: response.data?.message || 'Gagal cek transaksi Pakasir' };
  } catch (error) {
    console.error('[PAKASIR] Check transaction error:', error.response?.data || error.message);
    return { success: false, data: null, error: error.message };
  }
}

async function cancelPakasirTransaction(orderId, amount) {
  try {
    const settings = await getSettings();
    const project = settings.pakasirProject || DEFAULT_PAKASIR_PROJECT;
    const apiKey = settings.pakasirApiKey || DEFAULT_PAKASIR_API_KEY;
    if (!apiKey) return { success: false, error: 'API Key Pakasir belum dikonfigurasi' };
    const payload = { project, order_id: orderId, amount, api_key: apiKey };
    const response = await axios.post(`${DEFAULT_PAKASIR_API_URL}/transactioncancel`, payload, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });
    return { success: response.data?.success || false, data: response.data };
  } catch (error) {
    console.error('[PAKASIR] Cancel transaction error:', error.response?.data || error.message);
    return { success: false, error: error.message };
  }
}

async function getRumahOTPBalance() {
  try {
    const response = await axios.get('https://www.rumahotp.io/api/v1/user/balance', {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get balance failed:', error.response?.data || error.message);
    return { success: false, error: error.response?.data?.error?.message || error.message };
  }
}

async function getRumahOTPServices() {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/services`, {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get services failed:', error.response?.data || error.message);
    return { success: false, data: [], error: error.response?.data?.error?.message || error.message };
  }
}

async function getRumahOTPCountries(serviceId) {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/countries?service_id=${serviceId}`, {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get countries failed:', error.response?.data || error.message);
    return { success: false, data: [] };
  }
}

async function getRumahOTPOperators(countryName, providerId) {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/operators?country=${encodeURIComponent(countryName)}&provider_id=${providerId}`, {
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    console.error('[ERROR] Get operators failed:', error.response?.data || error.message);
    return { success: false, data: [] };
  }
}

async function orderRumahOTPNumber(numberId, providerId, operatorId) {
  try {
    const response = await axios.get(`${RUMAHOTP_BASE_URL}/orders`, {
      params: { 
        number_id: parseInt(numberId), 
        provider_id: parseInt(providerId), 
        operator_id: parseInt(operatorId) 
      },
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' },
      timeout: 10000 // 10 detik timeout
    });
    
    // Cek response
    if (response.data) {
      // Jika ada pesan error dari provider
      if (response.data.error) {
        return { 
          success: false, 
          error: response.data.error 
        };
      }
      
      // Jika success
      if (response.data.success && response.data.data) {
        return response.data;
      }
      
      // Jika response sukses tapi ga ada data
      return { 
        success: false, 
        error: response.data.message || 'Gagal memesan nomor' 
      };
    }
    
    return { success: false, error: 'Tidak ada response dari provider' };
    
  } catch (error) {
    console.error('[ERROR] Order number failed:', error.response?.data || error.message);
    
    // Handle error dari axios
    let errorMessage = error.message;
    if (error.response?.data?.error) {
      if (typeof error.response.data.error === 'string') {
        errorMessage = error.response.data.error;
      } else if (error.response.data.error.message) {
        errorMessage = error.response.data.error.message;
      }
    }
    
    return { 
      success: false, 
      error: errorMessage || 'Gagal memesan nomor' 
    };
  }
}

async function checkRumahOTPStatus(orderId) {
  try {
    const response = await axios.get(`https://www.rumahotp.io/api/v1/orders/get_status`, {
      params: { order_id: orderId },
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    console.error('[ERROR] Check status failed:', error.response?.data || error.message);
    return { success: false };
  }
}

async function cancelRumahOTPOrder(orderId) {
  try {
    const response = await axios.get(`https://www.rumahotp.io/api/v1/orders/set_status`, {
      params: { order_id: orderId, status: 'cancel' },
      headers: { 'x-apikey': RUMAHOTP_API_KEY, 'Accept': 'application/json' }
    });
    return response.data;
  } catch (error) {
    console.error('[ERROR] Cancel order failed:', error.response?.data || error.message);
    return { success: false };
  }
}

async function verifyRecaptcha(recaptchaResponse) {
  if (!recaptchaResponse) return false;
  try {
    const response = await axios.post('https://www.google.com/recaptcha/api/siteverify', null, {
      params: { secret: RECAPTCHA_SECRET_KEY, response: recaptchaResponse }
    });
    return response.data.success === true;
  } catch (error) {
    console.error('reCAPTCHA verification error:', error.message);
    return false;
  }
}

const startId = {
  apikey: 'AZX',
  invoice: 'INV',
  withdraw: 'WD',
  transaction: 'TRX',
  otp: 'OTP',
  event: 'EVT',
  chat: 'CHT',
  uchat: 'UCHT',
  game: 'GAME'
};

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================
// SESSION CONFIG - MENGGUNAKAN MEMORYSTORE
// ============================================
const sessionStore = new MemoryStore({
  checkPeriod: 86400000
});

app.use(session({
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  store: sessionStore,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000,
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax'
  }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const Limiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 15,
  handler: (req, res) => {
    req.session.errorMsg = 'Terlalu banyak percobaan login. Silakan coba lagi setelah 5 menit.';
    res.redirect('/login');
  }
});

function generateCustomId(prefix) {
  const len = 10 - prefix.length;
  return prefix + crypto.randomBytes(Math.ceil(len / 2)).toString('hex').substring(0, len);
}

function generateApiKey() {
  return startId.apikey + '_' + crypto.randomUUID().replace(/-/g, '').substring(0, 16);
}

async function createWithRetry(collection, data, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      if (!data._id) {
        const map = {
          invoices: startId.invoice,
          transactions: startId.transaction,
          withdrawals: startId.withdraw,
          apiKeys: startId.apikey,
          otpOrders: startId.otp,
          games: startId.game
        };
        data._id = generateCustomId(map[collection] || '');
      }
      if (collection === 'apiKeys' && !data.key) data.key = generateApiKey();
      const existing = await findOne(collection, { _id: data._id });
      if (existing) continue;
      return await insertOne(collection, data);
    } catch (err) {
      if (attempt < maxRetries - 1) continue;
      throw err;
    }
  }
  throw new Error('Gagal membuat dokumen setelah beberapa kali percobaan');
}

async function getSettings() {
  let settings = await findOne('settings', {});
  if (!settings) {
    settings = {
      _id: 'settings_1',
      name: 'AzxPedia',
      title: 'Layanan Payment Gateway',
      description: 'Terima pembayaran melalui QRIS Payment untuk Aplikasi atau Platform Bisnis kamu dengan mudah, cepat, dan aman.',
      channelWhatsApp: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
      minDeposit: 1000,
      minWithdraw: 5000,
      feeWithdraw: 1000,
      feeDeposit: 0,
      maxFee: 500,
      checkInterval: 20,
      autoCheckEnabled: true,
      autoBackupEnabled: false,
      autoRestartEnabled: false,
      backupType: 'database',
      backupInterval: 5,
      restartTime: '03:00',
      backupTime: '00:00',
      smtpUser: '',
      smtpPass: '',
      aiEnabled: true,
      telegramBotToken: '',
      telegramAdminChatId: '',
      logoUrl: 'https://img2.pixhost.to/images/8187/731158188_skyzo.png',
      pakasirApiUrl: DEFAULT_PAKASIR_API_URL,
      pakasirProject: DEFAULT_PAKASIR_PROJECT,
      pakasirApiKey: '',
      chatMode: 'all',
      blockedUsers: [],
      gameConfig: DEFAULT_GAME_CONFIG,
      gameTypes: GAME_TYPES
    };
    await insertOne('settings', settings);
  }
  if (!settings.gameConfig) {
    settings.gameConfig = DEFAULT_GAME_CONFIG;
    await updateById('settings', settings._id, { $set: settings });
  }
  if (!settings.gameConfig.hiLo) {
    settings.gameConfig.hiLo = DEFAULT_GAME_CONFIG.hiLo;
    await updateById('settings', settings._id, { $set: settings });
  }
  if (!settings.gameConfig.coinflip) {
    settings.gameConfig.coinflip = DEFAULT_GAME_CONFIG.coinflip;
    await updateById('settings', settings._id, { $set: settings });
  }
  if (!settings.gameTypes) {
    settings.gameTypes = GAME_TYPES;
    await updateById('settings', settings._id, { $set: settings });
  }
  for (const key of ['hi-lo', 'coinflip', 'wheel', 'dice', 'crash']) {
    if (!settings.gameTypes[key]) {
      settings.gameTypes[key] = GAME_TYPES[key];
      await updateById('settings', settings._id, { $set: settings });
    }
  }
  return settings;
}

async function getStats() {
  const transactions = await readDB('transactions');
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;
  await updateOne('stats', {}, {
    $set: { totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions }
  }, { upsert: true });
  return { totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions };
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex') === hash;
}

async function sendTelegramChannelMessage(text, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  for (const chatId of TELEGRAM_CHANNEL_IDS) {
    try {
      const payload = { chat_id: chatId, text, parse_mode: 'Markdown', disable_web_page_preview: true };
      if (replyMarkup) payload.reply_markup = replyMarkup;
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, payload);
    } catch (e) {
      console.error(`[TELEGRAM] Send to ${chatId} error:`, e.response?.data || e.message);
    }
  }
}

async function sendTelegramChannelPhoto(photoUrl, caption, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  for (const chatId of TELEGRAM_CHANNEL_IDS) {
    try {
      const formData = new FormData();
      formData.append('chat_id', chatId);
      formData.append('photo', photoUrl);
      formData.append('caption', caption);
      formData.append('parse_mode', 'Markdown');
      if (replyMarkup) formData.append('reply_markup', JSON.stringify(replyMarkup));
      await axios.post(`https://api.telegram.org/bot${token}/sendPhoto`, formData, { headers: formData.getHeaders() });
    } catch (e) {
      console.error(`[TELEGRAM] Send photo to ${chatId} error:`, e.response?.data || e.message);
    }
  }
}

// ============================================
// SEND ADMIN NOTIFICATION - FIXED
// ============================================
async function sendAdminNotification(event, data) {
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const token = settings.telegramBotToken;
  if (!token || !adminChatId) return;
  
  let message = '';
  switch (event) {
    case 'new_register':
      message = `🆕 *Pendaftaran Baru*\n\n👤 Username: ${data.username || 'Unknown'}\n📧 Email: ${data.email || '-'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_login':
      message = `🔐 *Login Baru*\n\n👤 Username: ${data.username || 'Unknown'}\n📧 Email: ${data.email || '-'}\n🌐 IP: ${data.ip || '-'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_deposit':
      message = `💰 *Deposit Baru*\n\n👤 User: ${data.username || 'Unknown'}\n💵 Jumlah: Rp ${(data.amount || 0).toLocaleString('id-ID')}\n📝 Status: ${data.status || 'pending'}\n📱 Metode: ${data.method || 'Qris Payment'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'deposit_success':
      message = `✅ *Deposit Sukses*\n\n👤 User: ${data.username || 'Unknown'}\n💵 Jumlah: Rp ${(data.amount || 0).toLocaleString('id-ID')}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_withdraw':
      message = `💸 *Withdraw Baru*\n\n👤 User: ${data.username || 'Unknown'}\n💵 Jumlah: Rp ${(data.amount || 0).toLocaleString('id-ID')}\n📝 Status: ${data.status || 'pending'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'game_jackpot':
      message = `🎉 *JACKPOT!*\n\n👤 User: ${data.username || 'Unknown'}\n🎯 Game: ${data.game || 'Unknown'}\n💰 Taruhan: Rp ${(data.bet || 0).toLocaleString('id-ID')}\n🏆 Menang: Rp ${(data.winAmount || 0).toLocaleString('id-ID')}\n📈 Multiplier: ${data.multiplier || 0}x\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_otp_order':
      message = `📱 *OTP Order Baru*\n\n👤 User: ${data.username || 'Unknown'}\n📱 Layanan: ${data.service || '-'}\n🌍 Negara: ${data.country || '-'}\n📡 Operator: ${data.operator || '-'}\n💰 Harga: Rp ${(data.price || 0).toLocaleString('id-ID')}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'otp_order_success':
      message = `✅ *OTP Order Sukses*\n\n👤 User: ${data.username || 'Unknown'}\n📱 Layanan: ${data.service || '-'}\n🌍 Negara: ${data.country || '-'}\n📡 Operator: ${data.operator || '-'}\n💰 Harga: Rp ${(data.price || 0).toLocaleString('id-ID')}\n📱 Nomor: ${data.phoneNumber || '-'}\n🔑 Kode OTP: ${data.otpCode || '-'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'backup_success':
      message = `💾 *Backup Berhasil*\n\n📁 Tipe: ${data.type || 'Database Backup'}\n📊 Ukuran: ${data.size || 0} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'restart_success':
      message = `🔄 *Restart Server*\n\n✅ Server berhasil direstart\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`;
      break;
    case 'new_user_chat':
      message = `💬 *Pesan Baru dari User*\n\n👤 *User:* ${data.username || 'Unknown'} (${data.email || '-'})\n📝 *Isi Pesan:*\n${data.message || '-'}\n\n⏰ *Waktu:* ${data.time || new Date().toLocaleString('id-ID')}\n\n🔗 Silakan login ke website untuk membalas`;
      break;
  }
  
  if (message) {
    await sendTelegramMessage(adminChatId, message);
  }
}

// ============================================
// CREATE BACKUP ZIP - FIXED
// ============================================
async function createBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_db_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', () => {
        const sizeInMB = (archive.pointer() / (1024 * 1024)).toFixed(2);
        resolve({ path: zipFilePath, name: zipFileName, size: parseFloat(sizeInMB) });
      });
      
      archive.on('error', (err) => reject(err));
      archive.pipe(output);
      
      if (fs.existsSync(DATA_DIR)) {
        archive.directory(DATA_DIR, 'data');
      } else {
        reject(new Error('Folder data tidak ditemukan'));
      }
      
      await archive.finalize();
    } catch (error) { 
      reject(error); 
    }
  });
}

async function createFullBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_full_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', () => {
        const sizeInMB = (archive.pointer() / (1024 * 1024)).toFixed(2);
        resolve({ path: zipFilePath, name: zipFileName, size: parseFloat(sizeInMB) });
      });
      
      archive.on('error', (err) => reject(err));
      archive.pipe(output);
      
      archive.glob('**/*', {
        cwd: __dirname,
        ignore: ['node_modules/**', 'package-lock.json', '.env', 'backup_*.zip', 'data/backup_*.json']
      });
      
      await archive.finalize();
    } catch (error) { 
      reject(error); 
    }
  });
}

async function createFullBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_full_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      output.on('close', () => resolve({ path: zipFilePath, name: zipFileName, size: archive.pointer() }));
      archive.on('error', reject);
      archive.pipe(output);
      archive.glob('**/*', {
        cwd: __dirname,
        ignore: ['node_modules/**', 'package-lock.json', '.env', 'backup_*.zip', 'data/backup_*.json']
      });
      await archive.finalize();
    } catch (error) { reject(error); }
  });
}

// ============================================
// SEND BACKUP TO TELEGRAM - FIXED
// ============================================
async function sendBackupToTelegram(zipPath, zipName, isFull = false) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  const adminChatId = settings.telegramAdminChatId;
  if (!token || !adminChatId) {
    console.log('Telegram belum dikonfigurasi, backup hanya disimpan lokal');
    return false;
  }
  
  try {
    const stats = fs.statSync(zipPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    
    if (stats.size === 0) {
      console.error('File backup kosong!');
      return false;
    }
    
    if (stats.size > 50 * 1024 * 1024) {
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: adminChatId,
        text: `⚠️ *Backup terlalu besar*\n\nFile backup ${zipName} berukuran ${fileSizeMB} MB melebihi batas Telegram (50MB).\n\nSilakan download manual dari server: ${zipPath}`,
        parse_mode: 'Markdown'
      });
      return false;
    }
    
    const formData = new FormData();
    formData.append('chat_id', adminChatId);
    formData.append('document', fs.createReadStream(zipPath));
    formData.append('caption', `🗄️ *${isFull ? 'Full Backup' : 'Backup Database'}* - ${new Date().toLocaleDateString('id-ID')}\n\n📁 File: ${zipName}\n📊 Ukuran: ${fileSizeMB} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n⚠️ Simpan file ini dengan aman!`);
    
    await axios.post(`https://api.telegram.org/bot${token}/sendDocument`, formData, { headers: formData.getHeaders() });
    
    console.log(`Backup terkirim ke Telegram: ${zipName}`);
    
    // Kirim notifikasi sukses dengan data yang benar
    await sendAdminNotification('backup_success', { 
      type: isFull ? 'Full Backup' : 'Database Backup', 
      size: parseFloat(fileSizeMB) 
    });
    
    return true;
  } catch (error) {
    console.error('Gagal kirim backup ke Telegram:', error.message);
    return false;
  }
}
// ============================================
// PERFORM BACKUP - FIXED
// ============================================
async function performBackup(backupType) {
  try {
    const result = backupType === 'full' ? await createFullBackupZip() : await createBackupZip();
    await sendBackupToTelegram(result.path, result.name, backupType === 'full');
    setTimeout(() => fs.unlink(result.path, () => {}), 5000);
    return { success: true, fileName: result.name };
  } catch (error) {
    console.error('Backup gagal:', error);
    // Kirim notifikasi error backup
    const settings = await getSettings();
    const adminChatId = settings.telegramAdminChatId;
    const token = settings.telegramBotToken;
    if (token && adminChatId) {
      await sendTelegramMessage(adminChatId, `❌ *Backup Gagal*\n\nError: ${error.message}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`);
    }
    return { success: false, error: error.message };
  }
}

let restartCronJob = null;
async function scheduleAutoRestart() {
  if (restartCronJob) { restartCronJob.stop(); restartCronJob = null; }
  const settings = await getSettings();
  if (!settings.autoRestartEnabled) return;
  const [hour, minute] = settings.restartTime.split(':');
  restartCronJob = cron.schedule(`${minute} ${hour} * * *`, async () => {
    await sendAdminNotification('restart_success', {});
    setTimeout(() => process.exit(0), 2000);
  });
}

let backupIntervalId = null;
async function scheduleAutoBackup() {
  if (backupIntervalId) { clearInterval(backupIntervalId); backupIntervalId = null; }
  const settings = await getSettings();
  if (!settings.autoBackupEnabled) return;
  const intervalMs = (settings.backupInterval || 5) * 60 * 1000;
  setTimeout(async () => await performBackup(settings.backupType), 5000);
  backupIntervalId = setInterval(async () => await performBackup(settings.backupType), intervalMs);
}

let pollingTimeout = null;
let isPollingActive = false;

async function getAdminChatId() {
  const settings = await getSettings();
  return settings.telegramAdminChatId || null;
}

async function sendTelegramMessage(chatId, text, replyMarkup = null) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token || !chatId) return;
  try {
    const payload = { chat_id: chatId, text, parse_mode: 'Markdown' };
    if (replyMarkup) payload.reply_markup = replyMarkup;
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, payload);
  } catch (e) {
    console.error('Telegram sendMessage error:', e.response?.data || e.message);
  }
}

async function deleteMessage(chatId, messageId) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/deleteMessage`, { chat_id: chatId, message_id: messageId });
  } catch (e) {
    console.error('Telegram deleteMessage error:', e.response?.data || e.message);
  }
}

async function answerCallbackQuery(callbackQueryId, text) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
      callback_query_id: callbackQueryId, text, show_alert: false
    });
  } catch (e) { }
}

const mainMenuKeyboard = {
  inline_keyboard: [
    [{ text: '💾 Backup Database', callback_data: 'backup_db' }],
    [{ text: '📦 Backup Full', callback_data: 'backup_full' }]
  ]
};

async function handleTelegramCommand(msg) {
  const text = msg.text;
  const chatId = msg.chat.id;
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const isAdminUser = String(chatId) === String(adminChatId);
  if (text === '/login') {
    await sendTelegramMessage(chatId, `🤖 *${settings.name} Bot*\n\nSelamat datang!\n\nGunakan menu di bawah untuk mengakses fitur.`, isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
  } else if (text === '/menu') {
    await sendTelegramMessage(chatId, '📋 *Menu Utama*', isAdminUser ? mainMenuKeyboard : mainMenuKeyboard);
  } else if (text === '/backupdb' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses backup database...*', null);
    const result = await performBackup('database');
    await sendTelegramMessage(chatId, result.success ? `✅ Backup database berhasil: ${result.fileName}` : `❌ Backup gagal: ${result.error}`);
  } else if (text === '/backupall' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses full backup...*\n\n⏳ Mohon tunggu, proses ini mungkin memakan waktu beberapa saat.', null);
    const result = await performBackup('full');
    await sendTelegramMessage(chatId, result.success ? `✅ Full backup berhasil: ${result.fileName}` : `❌ Backup gagal: ${result.error}`);
  }
}

async function handleCallbackQuery(cb) {
  const data = cb.data;
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  const isAdminUser = String(chatId) === String(adminChatId);
  await answerCallbackQuery(cb.id, 'Processing...');
  if (data === 'backup_db' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses backup database...*\n\n⏳ Mohon tunggu.', null);
    await performBackup('database');
    await deleteMessage(chatId, messageId);
  } else if (data === 'backup_full' && isAdminUser) {
    await sendTelegramMessage(chatId, '🔄 *Memproses full backup...*\n\n⏳ Mohon tunggu, proses ini mungkin memakan waktu beberapa saat.', null);
    await performBackup('full');
    await deleteMessage(chatId, messageId);
  }
}

async function handleTelegramUpdate(update) {
  if (update.callback_query) await handleCallbackQuery(update.callback_query);
  else if (update.message && update.message.text) await handleTelegramCommand(update.message);
}

async function telegramGetUpdates(offset) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return [];
  try {
    const res = await axios.get(`https://api.telegram.org/bot${token}/getUpdates`, {
      params: { offset, timeout: 15 },
      timeout: 20000
    });
    return res.data.ok ? res.data.result : [];
  } catch (e) {
    if (e.response?.status === 409) stopTelegramPolling();
    return [];
  }
}

function stopTelegramPolling() {
  if (pollingTimeout) { clearTimeout(pollingTimeout); pollingTimeout = null; }
  isPollingActive = false;
}

async function ensureNoWebhook(token) {
  try {
    const infoRes = await axios.get(`https://api.telegram.org/bot${token}/getWebhookInfo`);
    if (infoRes.data.ok && infoRes.data.result.url) {
      await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook`);
    }
    return true;
  } catch (e) {
    console.error('Gagal menghapus webhook:', e.message);
    return false;
  }
}

async function startTelegramPolling() {
  stopTelegramPolling();
  const settings = await getSettings();
  if (!settings.telegramBotToken) return;
  if (isPollingActive) return;
  const ok = await ensureNoWebhook(settings.telegramBotToken);
  if (!ok) return;
  isPollingActive = true;
  let offset = 0;
  async function poll() {
    if (!isPollingActive) return;
    const updates = await telegramGetUpdates(offset);
    for (const update of updates) {
      offset = update.update_id + 1;
      await handleTelegramUpdate(update);
    }
    pollingTimeout = setTimeout(poll, 1000);
  }
  poll();
}

app.use(async (req, res, next) => {
  res.locals.user = null;
  if (req.session.userId) {
    try { res.locals.user = await findById('users', req.session.userId); } catch { }
  }
  res.locals.settings = await getSettings();
  res.locals.error = req.session.errorMsg || null;
  res.locals.success = req.session.successMsg || null;
  delete req.session.errorMsg;
  delete req.session.successMsg;
  next();
});

function isAuth(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}

function isAdmin(req, res, next) {
  if (req.session.userRole === 'admin') return next();
  res.redirect('/login');
}

async function seed() {
  const admin = await findOne('users', { role: 'admin' });
  if (!admin) {
    await insertOne('users', {
      _id: crypto.randomBytes(12).toString('hex'),
      username: 'aanadmin',
      email: 'aancuy@gmail.com',
      password: hashPassword('frkhnsptra23'),
      role: 'admin',
      balance: 0,
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    });
    console.log('Admin Account Created:\nUsername: aanadmin\nPassword: frkhnsptra23');
  }
}

// ==================== GAME ROUTES ====================
app.get('/games', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameTypes = settings.gameTypes || GAME_TYPES;
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const userId = req.session.userId;
    const history = await getGameHistory(userId, 50);
    const stats = await getGameStats();
    const userStats = {
      totalGames: history.length,
      totalWins: history.filter(g => g.isWin).length,
      totalBets: history.reduce((sum, g) => sum + (g.bet || 0), 0),
      totalWinAmount: history.reduce((sum, g) => sum + (g.winAmount || 0), 0),
      netProfit: history.reduce((sum, g) => sum + (g.netWin || 0), 0)
    };
    res.render('games', { gameTypes, gameConfig, user: res.locals.user, userStats, stats });
  } catch (error) {
    console.error('[GAMES] Error:', error);
    req.session.errorMsg = 'Gagal memuat halaman game';
    res.redirect('/dashboard');
  }
});

app.get('/games/hi-lo', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const history = await getGameHistory(req.session.userId, 20);
    res.render('games/hi-lo_game', {
      gameConfig: gameConfig.hiLo || DEFAULT_GAME_CONFIG.hiLo,
      history,
      user: res.locals.user,
      gameName: 'HI-LO',
      gameIcon: 'fa-dice'
    });
  } catch (error) {
    console.error('[GAME] HI-LO error:', error);
    req.session.errorMsg = 'Gagal memuat game';
    res.redirect('/games');
  }
});

app.get('/games/coinflip', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const history = await getGameHistory(req.session.userId, 20);
    res.render('games/coinflip_game', {
      gameConfig: gameConfig.coinflip || DEFAULT_GAME_CONFIG.coinflip,
      history,
      user: res.locals.user,
      gameName: 'Coin Flip',
      gameIcon: 'fa-coins'
    });
  } catch (error) {
    console.error('[GAME] Coin Flip error:', error);
    req.session.errorMsg = 'Gagal memuat game';
    res.redirect('/games');
  }
});

app.get('/games/wheel', isAuth, (req, res) => {
  res.render('games/wheel_game', {
    user: res.locals.user,
    gameName: 'Wheel of Fortune',
    gameIcon: 'fa-circle',
    comingSoon: true
  });
});

app.get('/games/dice', isAuth, (req, res) => {
  res.render('games/dice_game', {
    user: res.locals.user,
    gameName: 'Dice Roll',
    gameIcon: 'fa-cubes',
    comingSoon: true
  });
});

app.get('/games/crash', isAuth, (req, res) => {
  res.render('games/crash_game', {
    user: res.locals.user,
    gameName: 'Crash Game',
    gameIcon: 'fa-rocket',
    comingSoon: true
  });
});

app.get('/api/game/config', isAuth, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    res.json({ success: true, config: gameConfig });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/game/hi-lo/play', isAuth, async (req, res) => {
  try {
    const { bet, choice } = req.body;
    const userId = req.session.userId;
    const user = await findById('users', userId);
    const settings = await getSettings();
    const gameConfig = settings.gameConfig?.hiLo || DEFAULT_GAME_CONFIG.hiLo;
    if (!gameConfig.enabled) return res.json({ success: false, message: 'Game sedang tidak aktif' });
    if (!bet || isNaN(bet) || bet < gameConfig.minBet) return res.json({ success: false, message: `Minimal taruhan Rp ${gameConfig.minBet.toLocaleString('id-ID')}` });
    if (bet > gameConfig.maxBet) return res.json({ success: false, message: `Maksimal taruhan Rp ${gameConfig.maxBet.toLocaleString('id-ID')}` });
    if (!choice || !['HI', 'LO'].includes(choice)) return res.json({ success: false, message: 'Pilih HI atau LO' });
    if (user.balance < bet) return res.json({ success: false, message: 'Saldo tidak cukup' });
    const lastGame = await getGameHistory(userId, 1);
    if (lastGame.length > 0) {
      const diff = (Date.now() - new Date(lastGame[0].createdAt).getTime()) / 1000;
      if (diff < (gameConfig.cooldown || 10)) return res.json({ success: false, message: `Tunggu ${Math.ceil((gameConfig.cooldown || 10) - diff)} detik lagi` });
    }
    const result = generateGameResult(gameConfig.winRate || 75);
    const isWin = result.isWin && choice === result.result;
    const multiplier = gameConfig.maxWinMultiplier || 2;
    const winAmount = isWin ? bet * multiplier : 0;
    const netWin = winAmount - bet;
    user.balance += isWin ? netWin : -bet;
    await updateById('users', userId, { $set: user });
    const gameData = { gameType: 'hi-lo', bet, choice, number: result.number, result: result.result, isWin, winAmount, netWin, multiplier: isWin ? multiplier : 0, balanceAfter: user.balance, winRate: gameConfig.winRate };
    await saveGameHistory(userId, gameData);
    if (isWin && winAmount >= (gameConfig.jackpotThreshold || 50000)) {
      await sendAdminNotification('game_jackpot', { username: user.username, game: 'HI-LO', bet, winAmount, multiplier });
      await sendTelegramChannelPhoto('https://cdn.yupra.my.id/yp/tftx606i.png', `🎉 *JACKPOT!*\n\n🌐 *AzxPedia*\n\n👤 User: ${user.username}\n🎯 Game: HI-LO\n💰 Taruhan: Rp ${bet.toLocaleString()}\n🏆 Menang: Rp ${winAmount.toLocaleString()}\n📈 Multiplier: x${multiplier}\n🔢 Angka: ${result.number} (${result.result})\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`);
    }
    res.json({ success: true, data: { bet, choice, number: result.number, result: result.result, isWin, winAmount, netWin, multiplier: isWin ? multiplier : 0, balance: user.balance } });
  } catch (error) {
    console.error('[GAME] Play error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/game/coinflip/play', isAuth, async (req, res) => {
  try {
    const { bet, choice } = req.body;
    const userId = req.session.userId;
    const user = await findById('users', userId);
    const settings = await getSettings();
    const gameConfig = settings.gameConfig?.coinflip || DEFAULT_GAME_CONFIG.coinflip;
    if (!gameConfig.enabled) return res.json({ success: false, message: 'Game Coin Flip sedang tidak aktif' });
    if (!bet || isNaN(bet) || bet < gameConfig.minBet) return res.json({ success: false, message: `Minimal taruhan Rp ${gameConfig.minBet.toLocaleString('id-ID')}` });
    if (bet > gameConfig.maxBet) return res.json({ success: false, message: `Maksimal taruhan Rp ${gameConfig.maxBet.toLocaleString('id-ID')}` });
    if (!choice || !['HEAD', 'TAIL'].includes(choice)) return res.json({ success: false, message: 'Pilih HEAD atau TAIL' });
    if (user.balance < bet) return res.json({ success: false, message: 'Saldo tidak cukup' });
    const lastGame = await getGameHistory(userId, 1);
    if (lastGame.length > 0) {
      const diff = (Date.now() - new Date(lastGame[0].createdAt).getTime()) / 1000;
      if (diff < (gameConfig.cooldown || 5)) return res.json({ success: false, message: `Tunggu ${Math.ceil((gameConfig.cooldown || 5) - diff)} detik lagi` });
    }
    const result = generateCoinFlipResult(gameConfig.winRate || 75);
    const isWin = result.isWin && choice === result.coin;
    const multiplier = gameConfig.maxWinMultiplier || 1.95;
    const winAmount = isWin ? Math.round(bet * multiplier) : 0;
    const netWin = winAmount - bet;
    user.balance += isWin ? netWin : -bet;
    await updateById('users', userId, { $set: user });
    const gameData = { gameType: 'coinflip', bet, choice, coin: result.coin, isWin, winAmount, netWin, multiplier: isWin ? multiplier : 0, balanceAfter: user.balance, winRate: gameConfig.winRate };
    await saveGameHistory(userId, gameData);
    if (isWin && winAmount >= (gameConfig.jackpotThreshold || 50000)) {
      await sendAdminNotification('game_jackpot', { username: user.username, game: 'Coin Flip', bet, winAmount, multiplier });
      await sendTelegramChannelPhoto('https://cdn.yupra.my.id/yp/tftx606i.png', `🪙 *JACKPOT! Coin Flip*\n\n🌐 *AzxPedia*\n\n👤 User: ${user.username}\n🪙 Game: Coin Flip\n💰 Taruhan: Rp ${bet.toLocaleString()}\n🏆 Menang: Rp ${winAmount.toLocaleString()}\n📈 Multiplier: x${multiplier}\n🪙 Coin: ${result.coin}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`);
    }
    res.json({ success: true, data: { bet, choice, coin: result.coin, isWin, winAmount, netWin, multiplier: isWin ? multiplier : 0, balance: user.balance } });
  } catch (error) {
    console.error('[COINFLIP] Play error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/game/history', isAuth, async (req, res) => {
  try {
    const userId = req.session.userId;
    const limit = parseInt(req.query.limit) || 20;
    const history = await getGameHistory(userId, limit);
    const totalGames = history.length;
    const totalWins = history.filter(g => g.isWin).length;
    const totalBets = history.reduce((sum, g) => sum + (g.bet || 0), 0);
    const totalWinAmount = history.reduce((sum, g) => sum + (g.winAmount || 0), 0);
    const netProfit = totalWinAmount - totalBets;
    res.json({
      success: true,
      data: {
        history,
        stats: { totalGames, totalWins, totalLosses: totalGames - totalWins, totalBets, totalWinAmount, netProfit, winRate: totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0 }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== ADMIN GAME ROUTES ====================
app.get('/admin/games', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await getSettings();
    const gameConfig = settings.gameConfig || DEFAULT_GAME_CONFIG;
    const gameTypes = settings.gameTypes || GAME_TYPES;
    const stats = await getGameStats();
    const games = await readDB('games');
    const users = await readDB('users');
    const playerStats = {};
    games.forEach(g => {
      if (!playerStats[g.userId]) playerStats[g.userId] = { wins: 0, losses: 0, totalBet: 0, totalWin: 0 };
      if (g.isWin) { playerStats[g.userId].wins++; playerStats[g.userId].totalWin += g.winAmount || 0; }
      else { playerStats[g.userId].losses++; }
      playerStats[g.userId].totalBet += g.bet || 0;
    });
    const topPlayers = Object.keys(playerStats).map(userId => {
      const user = users.find(u => u._id === userId);
      return { userId, username: user ? user.username : 'Unknown', ...playerStats[userId], netProfit: playerStats[userId].totalWin - playerStats[userId].totalBet };
    }).sort((a, b) => b.totalBet - a.totalBet).slice(0, 10);
    res.render('admin_games', { gameConfig, gameTypes, stats, topPlayers, user: res.locals.user });
  } catch (error) {
    console.error('[ADMIN GAMES] Error:', error);
    req.session.errorMsg = 'Gagal memuat halaman game';
    res.redirect('/admin/dashboard');
  }
});

app.post('/admin/games/update', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await getSettings();
    settings.gameConfig.hiLo = {
      enabled: req.body.hiLo_enabled === 'on',
      minBet: parseInt(req.body.hiLo_minBet) || 1000,
      maxBet: parseInt(req.body.hiLo_maxBet) || 1000000,
      winRate: parseInt(req.body.hiLo_winRate) || 75,
      maxWinMultiplier: parseFloat(req.body.hiLo_maxWinMultiplier) || 2,
      cooldown: parseInt(req.body.hiLo_cooldown) || 10,
      jackpotThreshold: parseInt(req.body.hiLo_jackpotThreshold) || 50000,
      houseEdge: 5
    };
    settings.gameConfig.coinflip = {
      enabled: req.body.coinflip_enabled === 'on',
      minBet: parseInt(req.body.coinflip_minBet) || 1000,
      maxBet: parseInt(req.body.coinflip_maxBet) || 1000000,
      winRate: parseInt(req.body.coinflip_winRate) || 75,
      maxWinMultiplier: parseFloat(req.body.coinflip_maxWinMultiplier) || 1.95,
      cooldown: parseInt(req.body.coinflip_cooldown) || 5,
      jackpotThreshold: parseInt(req.body.coinflip_jackpotThreshold) || 50000,
      houseEdge: 5
    };
    await updateById('settings', settings._id, { $set: settings });
    req.session.successMsg = 'Pengaturan game berhasil diperbarui!';
    res.redirect('/admin/games');
  } catch (error) {
    console.error('[ADMIN GAMES] Update error:', error);
    req.session.errorMsg = 'Gagal memperbarui pengaturan game: ' + error.message;
    res.redirect('/admin/games');
  }
});

app.post('/admin/games/reset', isAuth, isAdmin, async (req, res) => {
  try {
    await writeDB('games', []);
    req.session.successMsg = 'Riwayat game berhasil direset!';
  } catch (error) {
    req.session.errorMsg = 'Gagal reset riwayat game';
  }
  res.redirect('/admin/games');
});

// ==================== AUTH ROUTES ====================
app.get('/', (req, res) => res.render('home'));
app.get('/home', (req, res) => res.render('home'));

app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('login', { recaptchaSiteKey: RECAPTCHA_SITE_KEY, error: null, success: null });
});

app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('register', { recaptchaSiteKey: RECAPTCHA_SITE_KEY, error: null, success: null });
});

app.post('/login', Limiter, loginRateLimiter, async (req, res) => {
  const { login, password, 'g-recaptcha-response': recaptchaResponse } = req.body;
  const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  if (!login || !password) {
    req.session.errorMsg = 'Harap isi semua field';
    return res.redirect('/login');
  }
  const isHuman = await verifyRecaptcha(recaptchaResponse);
  if (!isHuman) {
    recordFailedLogin(ip);
    req.session.errorMsg = 'Verifikasi keamanan gagal. Silakan coba lagi.';
    return res.redirect('/login');
  }
  const isEmail = login.includes('@');
  let user;
  if (isEmail) {
    user = await findOne('users', { email: login.toLowerCase() });
    if (user?.role === 'admin') {
      req.session.errorMsg = 'Admin hanya dapat login menggunakan username';
      return res.redirect('/login');
    }
  } else {
    user = await findOne('users', { username: login.toLowerCase() });
  }
  if (!user || !verifyPassword(password, user.password)) {
    recordFailedLogin(ip);
    req.session.errorMsg = 'Username/email atau kata sandi salah';
    return res.redirect('/login');
  }
  if (user.suspended) {
    req.session.errorMsg = 'Akun Anda dinonaktifkan';
    return res.redirect('/login');
  }
  resetLoginAttempts(ip);

  if (user.role === 'admin') {
    const settings = await getSettings();
    if (!settings.telegramBotToken) {
      req.session.errorMsg = 'Bot Telegram belum dikonfigurasi. Hubungi developer.';
      return res.redirect('/login');
    }
    const otp = generateOTP();
    otpStore[user._id] = { otp, expires: Date.now() + 5 * 60 * 1000 };
    const sent = await sendAdminOTP(ADMIN_CHAT_ID_2FA, otp, user.username);
    if (!sent) {
      req.session.errorMsg = 'Gagal mengirim kode verifikasi. Pastikan bot Telegram aktif.';
      return res.redirect('/login');
    }
    req.session.tempUserId = user._id;
    req.session.tempUsername = user.username;
    req.session.otpRequired = true;
    return res.render('admin_2fa', {
      message: 'Kode verifikasi telah dikirim ke Telegram Admin.',
      userId: user._id,
      username: user.username,
      recaptchaSiteKey: RECAPTCHA_SITE_KEY,
      error: null
    });
  }

  req.session.userId = user._id;
  req.session.userRole = user.role;
  req.session.loginIp = ip;
  req.session.loginTime = Date.now();
  await sendAdminNotification('new_login', { username: user.username, email: user.email, ip });
  res.redirect('/dashboard');
});

app.post('/verify-2fa', async (req, res) => {
  const { otp, 'g-recaptcha-response': recaptchaResponse } = req.body;
  const userId = req.session.tempUserId;

  if (!userId) {
    req.session.errorMsg = 'Sesi tidak valid. Silakan login ulang.';
    return res.redirect('/login');
  }

  const isHuman = await verifyRecaptcha(recaptchaResponse);
  if (!isHuman) {
    return res.render('admin_2fa', {
      message: 'Verifikasi keamanan gagal. Silakan coba lagi.',
      userId, username: req.session.tempUsername || 'Admin', error: 'Verifikasi keamanan gagal', recaptchaSiteKey: RECAPTCHA_SITE_KEY
    });
  }

  if (!otp) {
    return res.render('admin_2fa', {
      message: 'Kode OTP diperlukan.',
      userId, username: req.session.tempUsername || 'Admin', error: 'Kode OTP diperlukan', recaptchaSiteKey: RECAPTCHA_SITE_KEY
    });
  }

  const stored = otpStore[userId];
  if (!stored) {
    return res.render('admin_2fa', {
      message: 'Kode OTP tidak ditemukan. Silakan login ulang.',
      userId, username: req.session.tempUsername || 'Admin', error: 'OTP tidak ditemukan', recaptchaSiteKey: RECAPTCHA_SITE_KEY
    });
  }

  if (stored.expires < Date.now()) {
    delete otpStore[userId];
    return res.render('admin_2fa', {
      message: 'Kode OTP telah kadaluarsa (5 menit). Silakan login ulang.',
      userId, username: req.session.tempUsername || 'Admin', error: 'OTP kadaluarsa', recaptchaSiteKey: RECAPTCHA_SITE_KEY
    });
  }

  if (stored.otp !== otp) {
    return res.render('admin_2fa', {
      message: 'Kode OTP salah. Silakan coba lagi.',
      userId, username: req.session.tempUsername || 'Admin', error: 'OTP salah', recaptchaSiteKey: RECAPTCHA_SITE_KEY
    });
  }

  delete otpStore[userId];
  const user = await findById('users', userId);
  if (!user) {
    req.session.errorMsg = 'User tidak ditemukan.';
    return res.redirect('/login');
  }

  const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;

  req.session.userId = user._id;
  req.session.userRole = user.role;
  req.session.loginIp = ip;
  req.session.loginTime = Date.now();
  req.session.otpRequired = false;
  delete req.session.tempUserId;
  delete req.session.tempUsername;

  req.session.save(async (err) => {
    if (err) {
      console.error('[2FA] Session save error:', err);
      req.session.errorMsg = 'Gagal menyimpan session. Silakan coba lagi.';
      return res.redirect('/login');
    }

    const settings = await getSettings();
    if (settings.telegramBotToken) {
      await sendTelegramMessage(ADMIN_CHAT_ID_2FA,
        `✅ *LOGIN ADMIN BERHASIL*\n\n` +
        `👤 *Username:* ${user.username}\n` +
        `📧 *Email:* ${user.email}\n` +
        `🌐 *IP:* ${ip}\n` +
        `⏰ *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n` +
        `✅ Verifikasi 2FA berhasil.`
      );
    }

    await sendAdminNotification('new_login', { username: user.username, email: user.email, ip });
    return res.redirect('/admin/dashboard');
  });
});

app.post('/register', Limiter, async (req, res) => {
  const { username, email, password, 'g-recaptcha-response': recaptchaResponse } = req.body;
  if (!username || username.trim().length === 0) {
    req.session.errorMsg = 'Username tidak boleh kosong';
    return res.redirect('/register');
  }
  if (!/^[a-zA-Z0-9]+$/.test(username)) {
    req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
    return res.redirect('/register');
  }
  if (username.length > 15) {
    req.session.errorMsg = 'Username maksimal 15 karakter';
    return res.redirect('/register');
  }
  if (!email || !email.includes('@')) {
    req.session.errorMsg = 'Email tidak valid';
    return res.redirect('/register');
  }
  if (!password || password.length < 4) {
    req.session.errorMsg = 'Password minimal 4 karakter';
    return res.redirect('/register');
  }
  const isHuman = await verifyRecaptcha(recaptchaResponse);
  if (!isHuman) {
    req.session.errorMsg = 'Verifikasi keamanan gagal. Silakan coba lagi.';
    return res.redirect('/register');
  }
  try {
    const existingUser = await findOne('users', { $or: [{ username: username.toLowerCase() }, { email: email.toLowerCase() }] });
    if (existingUser) {
      req.session.errorMsg = 'Username atau email sudah terdaftar';
      return res.redirect('/register');
    }
    const user = {
      _id: crypto.randomBytes(12).toString('hex'),
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      password: hashPassword(password),
      balance: 0,
      role: 'user',
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    };
    await insertOne('users', user);
    await createWithRetry('apiKeys', { userId: user._id, key: generateApiKey(), createdAt: new Date() });
    req.session.userId = user._id;
    req.session.userRole = 'user';
    await sendAdminNotification('new_register', { username: user.username, email: user.email });
    res.redirect('/dashboard');
  } catch (err) {
    console.error('Register error:', err);
    req.session.errorMsg = 'Gagal mendaftar, periksa kembali data Anda';
    res.redirect('/register');
  }
});

app.post('/check-availability', async (req, res) => {
  const { type, value } = req.body;
  if (!type || !value || !['username', 'email'].includes(type)) return res.json({ available: false, message: 'Parameter tidak valid' });
  if (type === 'username') {
    if (!/^[a-zA-Z0-9]{1,15}$/.test(value)) return res.json({ available: false, message: 'Format username tidak valid' });
    const exists = await findOne('users', { username: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Username sudah digunakan' : 'Username tersedia' });
  }
  if (type === 'email') {
    if (!/^\S+@\S+\.\S+$/.test(value)) return res.json({ available: false, message: 'Format email tidak valid' });
    const exists = await findOne('users', { email: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Email sudah terdaftar' : 'Email tersedia' });
  }
});

app.get('/forgot-password', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('forgot_password');
});

app.post('/forgot-password', Limiter, async (req, res) => {
  const { login } = req.body;
  if (!login) {
    req.session.errorMsg = 'Harap masukkan email atau username Anda.';
    return res.redirect('/forgot-password');
  }
  try {
    const settings = await getSettings();
    if (!settings.smtpUser || !settings.smtpPass) {
      req.session.errorMsg = 'Fitur pengiriman email belum dikonfigurasi oleh Administrator.';
      return res.redirect('/forgot-password');
    }
    const isEmail = login.includes('@');
    let user = isEmail ? await findOne('users', { email: login.toLowerCase() }) : await findOne('users', { username: login.toLowerCase() });
    if (!user) {
      req.session.errorMsg = 'Akun tidak ditemukan di sistem kami.';
      return res.redirect('/forgot-password');
    }
    if (!user.email) {
      req.session.errorMsg = 'Akun ini tidak memiliki alamat email yang valid.';
      return res.redirect('/forgot-password');
    }
    const token = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 30 * 60 * 1000;
    await updateById('users', user._id, { $set: user });
    const resetLink = `http://${req.headers.host}/reset-password/${token}`;
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com', port: 587, secure: false,
      auth: { user: settings.smtpUser, pass: settings.smtpPass },
      tls: { rejectUnauthorized: false }
    });
    await transporter.sendMail({
      to: user.email,
      from: `"${settings.name}" <${settings.smtpUser}>`,
      subject: `Permintaan Reset Password - ${settings.name}`,
      text: `Halo ${user.username},\n\nKami menerima permintaan untuk mengatur ulang kata sandi akun Anda. Silakan salin tautan berikut ke browser Anda:\n${resetLink}\n\nTautan ini hanya berlaku 30 menit.\n\nJika Anda tidak meminta ini, abaikan email ini.`,
      html: `<div>Reset password link: <a href="${resetLink}">${resetLink}</a></div>`
    });
    req.session.successMsg = `Link reset password telah dikirim ke email Anda yang terdaftar.`;
    res.redirect('/forgot-password');
  } catch (error) {
    console.error('Error Forgot Password:', error);
    req.session.errorMsg = 'Gagal memproses email. Pastikan konfigurasi SMTP di Admin valid.';
    res.redirect('/forgot-password');
  }
});

app.get('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const user = users.find(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (!user) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa (berlaku 30 menit).';
      return res.redirect('/forgot-password');
    }
    res.render('reset_password', { token: req.params.token });
  } catch (error) {
    res.redirect('/login');
  }
});

app.post('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const userIndex = users.findIndex(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (userIndex === -1) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa.';
      return res.redirect('/forgot-password');
    }
    const { password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      req.session.errorMsg = 'Password dan konfirmasi password tidak cocok.';
      return res.redirect(`/reset-password/${req.params.token}`);
    }
    users[userIndex].password = hashPassword(password);
    delete users[userIndex].resetPasswordToken;
    delete users[userIndex].resetPasswordExpires;
    await writeDB('users', users);
    req.session.successMsg = 'Password berhasil diubah. Silakan login dengan password baru.';
    res.redirect('/login');
  } catch (error) {
    req.session.errorMsg = 'Gagal mereset password.';
    res.redirect(`/reset-password/${req.params.token}`);
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    res.redirect('/login');
  });
});

// ==================== DASHBOARD & MAIN ROUTES ====================
app.get('/dashboard', isAuth, async (req, res) => {
  if (req.session.userRole === 'admin') return res.redirect('/admin/dashboard');
  const userId = req.session.userId;
  const user = res.locals.user || { balance: 0 };
  const transactions = await readDB('transactions');
  const userTransactions = transactions.filter(t => t.userId === user._id);
  const totalDeposit = userTransactions.filter(t => t.type === 'deposit' && t.status === 'paid').reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalWithdraw = userTransactions.filter(t => t.type === 'withdraw' && t.status === 'success').reduce((sum, t) => sum + (t.amount || 0), 0);
  const recentTrx = userTransactions.filter(t => t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  const apiKeys = await find('apiKeys', { userId });
  const allNotifications = await getNotifications();
  const activeNotifications = allNotifications.filter(n => n.isActive);
  const unreadChatCount = await getUnreadChatCount(userId);
  res.render('dashboard', {
    user: user || { balance: 0, username: '', email: '' },
    totalDeposit: totalDeposit || 0,
    totalWithdraw: totalWithdraw || 0,
    recentTrx: recentTrx || [],
    apiKeys: apiKeys || [],
    allNotifications: activeNotifications || [],
    unreadChatCount: unreadChatCount || 0
  });
});

app.get('/chat/user', isAuth, async (req, res) => {
  const userId = req.session.userId;
  const messages = await getUserChatMessages(userId, 200);
  const user = res.locals.user;
  const adminMessageIds = messages.filter(msg => msg.userId === 'admin').map(msg => msg._id);
  if (adminMessageIds.length > 0) await markManyUserChatRead(adminMessageIds, userId);
  res.render('user_chat', { messages, user, unreadChatCount: 0 });
});

app.post('/chat/user/send', isAuth, async (req, res) => {
  const { message } = req.body;
  if (!message || message.trim() === '') return res.json({ success: false, message: 'Pesan tidak boleh kosong' });
  const user = res.locals.user;
  const settings = await getSettings();
  const useAI = settings.aiEnabled !== false;
  const userMessage = {
    _id: generateCustomId('UCHAT'),
    userId: user._id,
    username: user.username,
    message: message.trim(),
    targetUserId: 'admin',
    role: 'user',
    readBy: [],
    createdAt: new Date()
  };
  await saveUserChatMessage(userMessage);
  const adminChatId = settings.telegramAdminChatId;
  if (adminChatId) {
    const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    await sendTelegramMessage(adminChatId, `💬 *Pesan Baru dari User*\n\n👤 *User:* ${user.username} (${user.email})\n📝 *Isi Pesan:*\n${message.trim()}\n\n⏰ *Waktu:* ${timeString}`);
  }
  let aiResponse = null;
  if (useAI) {
    if (needsHumanAgent(message)) {
      aiResponse = 'Baik, saya akan menghubungkan Anda dengan admin. Mohon tunggu sebentar ya. Admin akan merespon secepatnya.\n\nAtau Anda juga bisa langsung menghubungi admin di:\n📱 WhatsApp: 08988106426\n✈️ Telegram: @AanzCuyxzzz';
    } else {
      try {
        const chatHistory = await getUserChatMessages(user._id, 20);
        aiResponse = await getAIResponse(message, chatHistory);
      } catch (error) {
        console.error('[AI] Reply Error:', error);
        aiResponse = null;
      }
    }
    if (aiResponse) {
      const aiMessage = {
        _id: generateCustomId('UCHAT'),
        userId: 'admin',
        username: 'AI Assistant',
        message: aiResponse,
        targetUserId: user._id,
        role: 'admin',
        readBy: [user._id],
        isAI: true,
        aiProvider: 'siputzx',
        createdAt: new Date()
      };
      await saveUserChatMessage(aiMessage);
      if (adminChatId) {
        await sendTelegramMessage(adminChatId, `🤖 *AI Auto-Reply*\n\n👤 *User:* ${user.username}\n📝 *Balasan AI:*\n${aiResponse.substring(0, 300)}${aiResponse.length > 300 ? '...' : ''}`);
      }
      return res.json({ success: true, message: userMessage, aiResponse: aiMessage });
    }
  }
  res.json({ success: true, message: userMessage });
});

app.get('/chat/user/messages', isAuth, async (req, res) => {
  const userId = req.session.userId;
  const messages = await getUserChatMessages(userId, 200);
  res.json({ success: true, messages: deduplicateMessages(messages) });
});

app.get('/admin/chat/user', isAuth, isAdmin, async (req, res) => {
  const chatList = await getChatList();
  const selectedUserId = req.query.user_id || null;
  let messages = [];
  let selectedUser = null;
  if (selectedUserId) {
    messages = await getUserChatMessages(selectedUserId, 200);
    selectedUser = await findById('users', selectedUserId);
    const userMessageIds = messages.filter(msg => msg.userId === selectedUserId).map(msg => msg._id);
    if (userMessageIds.length > 0) await markManyUserChatRead(userMessageIds, 'admin');
  }
  res.render('admin_chat_user', { chatList, messages: deduplicateMessages(messages), selectedUserId, selectedUser, user: res.locals.user });
});

app.post('/admin/chat/user/send', isAuth, isAdmin, async (req, res) => {
  const { userId, message } = req.body;
  if (!userId || !message || message.trim() === '') return res.json({ success: false, message: 'Data tidak lengkap' });
  const admin = res.locals.user;
  const targetUser = await findById('users', userId);
  if (!targetUser) return res.json({ success: false, message: 'User tidak ditemukan' });
  const newMessage = {
    _id: generateCustomId('UCHAT'),
    userId: 'admin',
    username: admin.username,
    message: message.trim(),
    targetUserId: userId,
    role: 'admin',
    readBy: [],
    createdAt: new Date()
  };
  await saveUserChatMessage(newMessage);
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  if (adminChatId) {
    const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    await sendTelegramMessage(adminChatId, `💬 *Pesan dari Admin ke User*\n\n👤 *User:* ${targetUser.username} (${targetUser.email})\n👨‍💼 *Admin:* ${admin.username}\n📝 *Isi Pesan:*\n${message.trim()}\n\n⏰ *Waktu:* ${timeString}`);
  }
  res.json({ success: true, message: newMessage });
});

app.get('/admin/chat/user/messages/:userId', isAuth, isAdmin, async (req, res) => {
  const userId = req.params.userId;
  const messages = await getUserChatMessages(userId, 200);
  const userMessageIds = messages.filter(msg => msg.userId === userId).map(msg => msg._id);
  if (userMessageIds.length > 0) await markManyUserChatRead(userMessageIds, 'admin');
  res.json({ success: true, messages: deduplicateMessages(messages) });
});

app.get('/admin/chat/user/list', isAuth, isAdmin, async (req, res) => {
  const chatList = await getChatList();
  res.json({ success: true, chatList });
});

app.post('/admin/chat/user/delete/:id', isAuth, isAdmin, async (req, res) => {
  const messages = await readDB('userChatMessages');
  await writeDB('userChatMessages', messages.filter(m => m._id !== req.params.id));
  res.json({ success: true });
});

app.get('/profile', isAuth, (req, res) => res.render('profile'));
app.post('/profile', isAuth, async (req, res) => {
  const { email, newPassword, ewallet, accountNumber, accountName } = req.body;
  try {
    const user = await findById('users', req.session.userId);
    if (email && email !== user.email) {
      const existing = await findOne('users', { email: email.toLowerCase() });
      if (existing && existing._id !== req.session.userId) {
        req.session.errorMsg = 'Email sudah digunakan oleh pengguna lain';
        return res.redirect('/profile');
      }
      user.email = email.toLowerCase();
    }
    user.ewallet = ewallet || '';
    user.accountNumber = accountNumber || '';
    user.accountName = accountName || '';
    if (newPassword && newPassword.trim()) user.password = hashPassword(newPassword);
    await updateById('users', req.session.userId, { $set: user });
    req.session.successMsg = 'Profil berhasil diperbarui';
    res.redirect('/profile');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui profil';
    res.redirect('/profile');
  }
});

app.post('/api/user/api-key/regenerate', isAuth, async (req, res) => {
  await deleteMany('apiKeys', { userId: req.session.userId });
  const key = generateApiKey();
  try {
    await createWithRetry('apiKeys', { userId: req.session.userId, key, createdAt: new Date() });
    res.json({ apiKey: key });
  } catch (err) {
    res.status(500).json({ error: 'Gagal membuat API key' });
  }
});

app.get('/deposit', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const transactions = await readDB('transactions');
  const deposits = transactions.filter(t => t.userId === req.session.userId && t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const invoices = await find('invoices', { userId: req.session.userId });
  res.render('deposit', {
    deposits,
    invoices: invoices.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    minDeposit: settings.minDeposit,
    feeDeposit: settings.feeDeposit
  });
});

app.post('/invoice/create', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const userId = req.session.userId;
  const amount = parseInt(req.body.amount);
  const feeDeposit = settings.feeDeposit || 0;
  const totalAmount = amount + feeDeposit;
  if (isNaN(amount) || amount < settings.minDeposit) {
    req.session.errorMsg = `Minimal deposit adalah Rp ${settings.minDeposit.toLocaleString('id-ID')}`;
    return res.redirect('/deposit');
  }
  try {
    const orderId = generateCustomId('PAK');
    const qrisResult = await createPakasirQRIS(totalAmount, orderId);
    if (!qrisResult.success) throw new Error(qrisResult.error || 'Gagal membuat Qris Payment');
    const expiredAt = new Date(qrisResult.expired || Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId,
      amount,
      fee: feeDeposit,
      total: totalAmount,
      trxid: qrisResult.trxid || orderId,
      qris_image: '',
      qr_string: qrisResult.qr_string || '',
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date(),
      paymentMethod: 'Qris Payment',
      paymentProvider: 'pakasir',
      providerData: { order_id: orderId, total_payment: qrisResult.total_payment, fee: qrisResult.fee, payment_method: qrisResult.payment_method, raw: qrisResult.raw }
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId,
      type: 'deposit',
      amount,
      fee: feeDeposit,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date(),
      paymentMethod: 'Qris Payment',
      paymentProvider: 'pakasir',
      providerData: { order_id: orderId }
    });
    const user = await findById('users', userId);
    await sendAdminNotification('new_deposit', { username: user.username, amount: totalAmount, status: 'pending', method: 'Qris Payment' });
    const photoUrl = 'https://cdn.yupra.my.id/yp/34qy2k2t.png';
    await sendTelegramChannelPhoto(photoUrl, `🌐 *AzxPedia*\n\n📊 *Invoice Deposit*\nUser: ${user.username}\nID Invoice: ${invoice._id}\nOrder ID: ${orderId}\nJumlah Deposit: Rp ${amount.toLocaleString()}\nFee Admin: Rp ${feeDeposit.toLocaleString()}\nTotal Dibayar: Rp ${totalAmount.toLocaleString()}\nStatus:⏳ Pending\n\n_${new Date().toLocaleString('id-ID')}_`);
    return res.redirect(`/invoice/${invoice._id}`);
  } catch (e) {
    console.error('Create invoice error:', e.response?.data || e.message);
    req.session.errorMsg = e.message || 'Gagal membuat invoice deposit. Silakan coba lagi.';
    return res.redirect('/deposit');
  }
});

app.get('/invoice/:id', isAuth, async (req, res) => {
  const inv = await findById('invoices', req.params.id);
  if (!inv || inv.userId !== req.session.userId) return res.status(404).send('Tidak ditemukan');
  res.render('invoice_detail', { inv });
});

app.get('/withdraw', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const withdrawals = await find('withdrawals', { userId: req.session.userId });
  res.render('withdraw', { settings, withdrawals: withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) });
});

app.post('/withdraw/request', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const user = res.locals.user;
  if (!user.ewallet || !user.accountNumber || !user.accountName) {
    req.session.errorMsg = 'Harap lengkapi data E-Wallet di Profil terlebih dahulu.';
    return res.redirect('/withdraw');
  }
  const { amount } = req.body;
  const amt = parseInt(amount);
  const fee = settings.feeWithdraw || 0;
  const totalDeduct = amt + fee;
  if (isNaN(amt) || amt < settings.minWithdraw) {
    req.session.errorMsg = 'Minimal penarikan Rp ' + settings.minWithdraw;
    return res.redirect('/withdraw');
  }
  if (user.balance < totalDeduct) {
    req.session.errorMsg = 'Saldo tidak cukup (termasuk biaya admin Rp ' + fee.toLocaleString() + ')';
    return res.redirect('/withdraw');
  }
  user.balance -= totalDeduct;
  await updateById('users', req.session.userId, { $set: user });
  try {
    const ref = 'W' + Date.now().toString(36).toUpperCase();
    const wd = await createWithRetry('withdrawals', {
      _id: generateCustomId(startId.withdraw),
      userId: req.session.userId, amount: amt, fee,
      method: user.ewallet, accountNumber: user.accountNumber, accountName: user.accountName,
      status: 'pending', adminNote: null, createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId: req.session.userId, type: 'withdraw', amount: amt, fee,
      status: 'pending', reference: ref, createdAt: new Date()
    });
    await sendAdminNotification('new_withdraw', { username: user.username, amount: amt + fee, status: 'pending' });
    const adminChatId = await getAdminChatId();
    if (adminChatId) {
      const userForMsg = await findById('users', req.session.userId);
      const timeString = new Date(wd.createdAt).toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      }).replace(/, /, ' pukul ');
      const inlineKeyboard = {
        inline_keyboard: [[
          { text: '✅ Setujui', callback_data: `approve_wd:${wd._id}` },
          { text: '❌ Tolak', callback_data: `reason_wd:${wd._id}` }
        ]]
      };
      await sendTelegramMessage(adminChatId,
        `🌐 *Notifikasi - ${settings.name}*\n\n` +
        `👤 *Informasi User*\n• User: ${userForMsg.username} (${userForMsg.email})\n• Saldo Saat Ini: Rp ${user.balance.toLocaleString()}\n• E-Wallet: ${user.ewallet}\n• No. Rek: \`${user.accountNumber}\`\n• Nama Rek: ${user.accountName}\n\n` +
        `📤 Informasi Withdraw\n• Jumlah: Rp ${amt.toLocaleString()}\n• Biaya: Rp ${fee.toLocaleString()}\n• Total Penarikan: Rp ${totalDeduct.toLocaleString()}\n• Waktu: ${timeString}`,
        inlineKeyboard
      );
    }
    req.session.successMsg = 'Penarikan berhasil diajukan dan sedang diproses.';
  } catch (err) {
    user.balance += totalDeduct;
    await updateById('users', req.session.userId, { $set: user });
    req.session.errorMsg = 'Gagal memproses penarikan sistem.';
  }
  res.redirect('/withdraw');
});

// ==================== ADMIN ROUTES ====================
app.get('/admin/dashboard', isAuth, isAdmin, async (req, res) => {
  const stats = await getStats();
  res.render('admin_dashboard', stats);
});

app.get('/admin/users', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let users = await readDB('users');
  users = users.filter(u => u.role === 'user');
  if (search) users = users.filter(u => u.email.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase()));
  users.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_users', { users, search });
});

app.get('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const targetUser = await findById('users', req.params.id);
  if (!targetUser) return res.status(404).send('Tidak ditemukan');
  res.render('admin_user_edit', { users: targetUser });
});

app.post('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const { username, email, password, balance, suspended } = req.body;
  if (username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
  }
  const user = await findById('users', req.params.id);
  if (!user) {
    req.session.errorMsg = 'User tidak ditemukan';
    return res.redirect('/admin/users');
  }
  if (username) user.username = username.toLowerCase();
  if (email) user.email = email.toLowerCase();
  if (balance !== undefined) user.balance = parseInt(balance) || 0;
  user.suspended = suspended === 'on';
  if (password && password.trim()) user.password = hashPassword(password);
  try {
    await updateById('users', req.params.id, { $set: user });
    req.session.successMsg = 'Data pengguna berhasil diperbarui';
    res.redirect('/admin/users');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui data pengguna';
    res.redirect(`/admin/users/${req.params.id}/edit`);
  }
});

app.post('/admin/users/:id/delete', isAuth, isAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const userToDelete = await findById('users', userId);
    if (!userToDelete) {
      req.session.errorMsg = 'User tidak ditemukan.';
      return res.redirect('/admin/users');
    }
    if (userToDelete.role === 'admin') {
      req.session.errorMsg = 'Tidak dapat menghapus akun admin.';
      return res.redirect('/admin/users');
    }
    await deleteMany('invoices', { userId });
    await deleteMany('transactions', { userId });
    await deleteMany('withdrawals', { userId });
    await deleteMany('apiKeys', { userId });
    await deleteOne('users', { _id: userId });
    req.session.successMsg = 'User berhasil dihapus beserta seluruh data terkait.';
    res.redirect('/admin/users');
  } catch (err) {
    console.error(err);
    req.session.errorMsg = 'Gagal menghapus user.';
    res.redirect('/admin/users');
  }
});

app.get('/admin/withdraw', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let withdrawals = await readDB('withdrawals');
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => u.email.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase())).map(u => u._id);
    withdrawals = withdrawals.filter(w => matchedUsers.includes(w.userId));
  }
  for (const w of withdrawals) {
    const user = await findById('users', w.userId);
    if (user) { w.username = user.username; w.email = user.email; }
  }
  withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_withdraw', { withdrawals, search });
});

app.post('/admin/withdraw/success/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'success';
    await updateById('withdrawals', wd._id, { $set: wd });
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference?.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'success';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    await updateOne('stats', {}, { $inc: { totalWithdrawAmount: wd.amount, totalWithdrawFee: wd.fee } });
    const user = await findById('users', wd.userId);
    const photoUrl = 'https://cdn.yupra.my.id/yp/0k7sxf4g.png';
    let maskedAccountNumber = wd.accountNumber || '-';
    if (maskedAccountNumber !== '-' && maskedAccountNumber.length > 4) {
      const last4 = maskedAccountNumber.slice(-4);
      maskedAccountNumber = '••••••' + last4;
    } else if (maskedAccountNumber !== '-' && maskedAccountNumber.length <= 4) {
      maskedAccountNumber = '••••';
    }
    let maskedAccountName = wd.accountName || '-';
    if (maskedAccountName !== '-' && maskedAccountName.length > 3) {
      const firstChar = maskedAccountName.charAt(0);
      const lastChar = maskedAccountName.charAt(maskedAccountName.length - 1);
      maskedAccountName = firstChar + '••••' + lastChar;
    } else if (maskedAccountName !== '-' && maskedAccountName.length <= 3) {
      maskedAccountName = '••••';
    }
    await sendTelegramChannelPhoto(photoUrl, `🌐 *AzxPedia*\n\n✅ *Withdraw Berhasil*\nUser: ${user ? user.username : 'Unknown'}\nJumlah: Rp ${wd.amount.toLocaleString()}\nFee Admin: Rp ${wd.fee.toLocaleString()}\nTotal Ditarik: Rp ${(wd.amount + wd.fee).toLocaleString()}\nMetode: ${wd.method || 'E-Wallet'}\nNo. Rekening: ${maskedAccountNumber}\nNama Rekening: ${maskedAccountName}\nStatus: ✅ Berhasil\n\n_${new Date().toLocaleString('id-ID')}_`);
    req.session.successMsg = 'Penarikan berhasil disetujui.';
  }
  res.redirect('/admin/withdraw');
});

app.post('/admin/withdraw/reject/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'rejected';
    wd.adminNote = req.body.note || '';
    await updateById('withdrawals', wd._id, { $set: wd });
    const user = await findById('users', wd.userId);
    user.balance += wd.amount + wd.fee;
    await updateById('users', wd.userId, { $set: user });
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference?.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'rejected';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    req.session.successMsg = 'Penarikan ditolak dan saldo dikembalikan.';
  }
  res.redirect('/admin/withdraw');
});

app.get('/admin/transactions', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let transactions = await readDB('transactions');
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => u.email.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase())).map(u => u._id);
    transactions = transactions.filter(t => matchedUsers.includes(t.userId) || (t.reference && t.reference.toLowerCase().includes(search.toLowerCase())));
  }
  for (const t of transactions) {
    const user = await findById('users', t.userId);
    if (user) { t.username = user.username; t.email = user.email; }
  }
  transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_transactions', { transactions, search });
});

app.get('/admin/account', isAuth, isAdmin, async (req, res) => {
  const admin = await findById('users', req.session.userId);
  res.render('admin_account', { admin });
});

app.post('/admin/account', isAuth, isAdmin, async (req, res) => {
  const { username, password, newPassword } = req.body;
  const admin = await findById('users', req.session.userId);
  if (!password || !verifyPassword(password, admin.password)) {
    req.session.errorMsg = 'Password saat ini salah';
    return res.redirect('/admin/account');
  }
  if (username && username !== admin.username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect('/admin/account');
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect('/admin/account');
    }
    const existing = await findOne('users', { username: username.toLowerCase() });
    if (existing && existing._id !== admin._id) {
      req.session.errorMsg = 'Username sudah digunakan oleh pengguna lain';
      return res.redirect('/admin/account');
    }
  }
  try {
    if (username && username !== admin.username) admin.username = username.toLowerCase();
    if (newPassword && newPassword.trim()) admin.password = hashPassword(newPassword);
    await updateById('users', req.session.userId, { $set: admin });
    req.session.successMsg = 'Data akun berhasil diperbarui';
  } catch (e) {
    req.session.errorMsg = 'Gagal memperbarui akun';
  }
  res.redirect('/admin/account');
});

app.post('/admin/settings/reset', isAuth, isAdmin, async (req, res) => {
  try {
    const users = await readDB('users');
    const adminUser = users.find(u => u.role === 'admin');
    await writeDB('users', adminUser ? [adminUser] : []);
    await writeDB('invoices', []);
    await writeDB('transactions', []);
    await writeDB('withdrawals', []);
    await writeDB('apiKeys', []);
    await writeDB('stats', [{
      totalDepositAmount: 0, totalDepositFee: 0, totalWithdrawAmount: 0,
      totalWithdrawFee: 0, totalUsers: 0, totalTransactions: 0
    }]);
    req.session.successMsg = 'Database berhasil direset. Semua data pengguna, invoice, transaksi, dan withdrawal telah dihapus.';
  } catch (error) {
    console.error('Reset database error:', error);
    req.session.errorMsg = 'Gagal mereset database. Silakan coba lagi.';
  }
  res.redirect('/admin/settings');
});

app.get('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  res.render('admin_settings', { settings });
});

app.post('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const {
    name, title, description, channelWhatsApp,
    minDeposit, minWithdraw, feeWithdraw, feeDeposit, maxFee,
    checkInterval, autoCheckEnabled, autoBackupEnabled, autoRestartEnabled,
    backupType, backupInterval, restartTime, backupTime,
    smtpUser, smtpPass, telegramBotToken, telegramAdminChatId, logoUrl,
    pakasirApiUrl, pakasirProject, pakasirApiKey
  } = req.body;
  const settings = await getSettings();
  settings.name = name;
  settings.title = title;
  settings.description = description;
  settings.channelWhatsApp = channelWhatsApp;
  settings.minDeposit = parseInt(minDeposit);
  settings.minWithdraw = parseInt(minWithdraw);
  settings.feeWithdraw = parseInt(feeWithdraw);
  settings.feeDeposit = parseInt(feeDeposit) || 0;
  settings.maxFee = parseInt(maxFee);
  settings.checkInterval = parseInt(checkInterval);
  settings.autoCheckEnabled = autoCheckEnabled === 'on';
  settings.autoBackupEnabled = autoBackupEnabled === 'on';
  settings.autoRestartEnabled = autoRestartEnabled === 'on';
  settings.backupType = backupType || 'database';
  settings.backupInterval = parseInt(backupInterval) || 5;
  settings.restartTime = restartTime || '03:00';
  settings.backupTime = backupTime || '00:00';
  settings.smtpUser = smtpUser;
  settings.smtpPass = smtpPass;
  settings.telegramBotToken = telegramBotToken;
  settings.telegramAdminChatId = telegramAdminChatId;
  settings.logoUrl = logoUrl;
  if (pakasirApiUrl) settings.pakasirApiUrl = pakasirApiUrl;
  if (pakasirProject) settings.pakasirProject = pakasirProject;
  if (pakasirApiKey !== undefined) settings.pakasirApiKey = pakasirApiKey || '';
  await updateById('settings', settings._id, { $set: settings });
  startChecker();
  startTelegramPolling();
  scheduleAutoBackup();
  scheduleAutoRestart();
  const adminChatId = settings.telegramAdminChatId;
  if (adminChatId && settings.telegramBotToken) {
    await sendTelegramMessage(adminChatId, `⚙️ *SETTINGS UPDATED*\n\nPengaturan telah diperbarui oleh Admin.\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`);
  }
  req.session.successMsg = 'Pengaturan berhasil diperbarui dan sistem disinkronisasi.';
  res.redirect('/admin/settings');
});

app.post('/admin/pakasir/test', isAuth, isAdmin, async (req, res) => {
  const { project, apiKey, amount } = req.body;
  try {
    const testAmount = parseInt(amount) || 1000;
    const testOrderId = 'TEST_' + Date.now().toString(36).toUpperCase();
    const payload = { project: project || DEFAULT_PAKASIR_PROJECT, order_id: testOrderId, amount: testAmount, api_key: apiKey || '' };
    const response = await axios.post(`${DEFAULT_PAKASIR_API_URL}/transactioncreate/qris`, payload, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });
    if (response.data?.payment) {
      res.json({ success: true, data: response.data.payment, message: 'Koneksi Pakasir berhasil!' });
    } else {
      res.json({ success: false, message: response.data?.message || 'Gagal koneksi ke Pakasir' });
    }
  } catch (error) {
    console.error('[PAKASIR] Test error:', error.response?.data || error.message);
    res.json({ success: false, message: error.response?.data?.message || error.message });
  }
});

app.get('/docs', async (req, res) => {
  let userApiKey = '';
  if (req.session.userId) {
    const key = await findOne('apiKeys', { userId: req.session.userId });
    if (key) userApiKey = key.key;
  }
  res.render('docs', { userApiKey });
});

async function apiAuth(req, res, next) {
  const apiKey = req.headers['x-api-key'] || req.query.api_key || req.query.apikey;
  if (!apiKey) return res.status(401).json({ error: 'API key diperlukan' });
  const keyDoc = await findOne('apiKeys', { key: apiKey });
  if (!keyDoc) return res.status(401).json({ error: 'API key tidak valid' });
  req.apiUser = keyDoc.userId;
  next();
}

app.get('/api/v1/balance', apiAuth, async (req, res) => {
  const user = await findById('users', req.apiUser);
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan' });
  res.json({ balance: user.balance });
});

app.get('/api/v1/invoice', apiAuth, async (req, res) => {
  const settings = await getSettings();
  const amount = parseInt(req.query.amount);
  const userId = req.apiUser;
  const feeDeposit = settings.feeDeposit || 0;
  const totalAmount = amount + feeDeposit;
  if (!amount || isNaN(amount) || amount < settings.minDeposit) {
    return res.status(400).json({ error: `Nominal minimal Rp ${settings.minDeposit}` });
  }
  try {
    const orderId = generateCustomId('PAK');
    const qrisResult = await createPakasirQRIS(totalAmount, orderId);
    if (!qrisResult.success) throw new Error(qrisResult.error || 'Gagal membuat QRIS');
    const expiredAt = new Date(qrisResult.expired || Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice), userId, amount, fee: feeDeposit, total: totalAmount,
      trxid: qrisResult.trxid || orderId, qris_image: '', qr_string: qrisResult.qr_string || '',
      expiredAt, status: 'pending', mutationId: null, createdAt: new Date(),
      paymentMethod: 'Qris Payment', paymentProvider: 'pakasir',
      providerData: { order_id: orderId, total_payment: qrisResult.total_payment, fee: qrisResult.fee }
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction), userId, type: 'deposit', amount, fee: feeDeposit,
      status: 'pending', reference: invoice._id.toString(), expiredAt, createdAt: new Date(),
      paymentMethod: 'Qris Payment', paymentProvider: 'pakasir', providerData: { order_id: orderId }
    });
    return res.json({
      success: true, invoice_id: invoice._id, amount, fee: feeDeposit, total: totalAmount,
      qr_string: invoice.qr_string, expired_at: invoice.expiredAt, payment_method: 'Qris Payment'
    });
  } catch (e) {
    console.error('API create invoice error:', e.response?.data || e.message);
    return res.status(500).json({ error: 'Gagal membuat invoice' });
  }
});

app.get('/api/v1/invoice/status', apiAuth, async (req, res) => {
  const invoiceId = req.query.id || req.query.invoice_id;
  if (!invoiceId) return res.status(400).json({ error: 'Invoice ID diperlukan' });
  const invoice = await findById('invoices', invoiceId);
  if (!invoice || invoice.userId !== req.apiUser) return res.status(404).json({ error: 'Invoice tidak ditemukan' });
  res.json({
    invoice_id: invoice._id, amount: invoice.amount, fee: invoice.fee, total: invoice.total,
    status: invoice.status, qr_string: invoice.qr_string, expired_at: invoice.expiredAt,
    created_at: invoice.createdAt, payment_method: invoice.paymentMethod || 'Qris Payment'
  });
});

app.get('/admin/backup', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const hasTelegram = !!(settings.telegramBotToken && settings.telegramAdminChatId);
  res.render('admin_backup', { hasTelegram, settings });
});

app.post('/admin/backup/create', isAuth, isAdmin, async (req, res) => {
  try {
    const { backupType } = req.body;
    const result = await performBackup(backupType || 'database');
    if (result.success) {
      req.session.successMsg = `Backup berhasil dibuat! File: ${result.fileName}`;
    } else {
      req.session.errorMsg = `Backup gagal: ${result.error}`;
    }
  } catch (error) {
    req.session.errorMsg = `Backup gagal: ${error.message}`;
  }
  res.redirect('/admin/backup');
});

// ==================== OTP ROUTES ====================
app.get('/otp', isAuth, async (req, res) => {
  try {
    const servicesResult = await getRumahOTPServices();
    const orders = await getOTPOrders(req.session.userId);
    res.render('dashboard_otp', {
      services: servicesResult.success ? servicesResult.data : [],
      servicesError: servicesResult.error,
      orders: orders.slice(0, 5),
      user: res.locals.user,
      adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    console.error('[ERROR] OTP dashboard error:', error);
    req.session.errorMsg = 'Gagal memuat halaman OTP';
    res.redirect('/dashboard');
  }
});

app.get('/otp/countries', isAuth, async (req, res) => {
  try {
    const { service_id, service_name, service_img } = req.query;
    const countries = await getRumahOTPCountries(service_id);
    res.render('negara_otp', {
      serviceId: service_id, serviceName: service_name || 'Unknown', serviceImg: service_img || '',
      countries: countries.success ? countries.data : [], user: res.locals.user, adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    console.error('[ERROR] Countries page error:', error);
    req.session.errorMsg = 'Gagal memuat daftar negara';
    res.redirect('/otp');
  }
});

app.get('/otp/operators', isAuth, async (req, res) => {
  try {
    const { country_id, country_name, country_price, provider_id, service_id, service_name, service_img, server_id, rate, stock } = req.query;
    const operators = await getRumahOTPOperators(country_name, provider_id);
    res.render('operator_otp', {
      serviceId: service_id, serviceName: service_name || 'Unknown', serviceImg: service_img || '',
      countryId: country_id, countryName: country_name || 'Unknown', countryPrice: country_price || '0',
      providerId: provider_id, serverId: server_id || '1', rate: rate || 0, stock: stock || 0,
      operators: operators.success ? operators.data : [], user: res.locals.user, adminFee: OTP_ADMIN_FEE
    });
  } catch (error) {
    console.error('[ERROR] Operators page error:', error);
    req.session.errorMsg = 'Gagal memuat daftar operator';
    res.redirect('/otp');
  }
});

app.post('/otp/order', isAuth, async (req, res) => {
  try {
    const { 
      service_id, 
      service_name, 
      service_img, 
      country_id, 
      country_name, 
      country_price, 
      provider_id, 
      operator_id, 
      operator_name 
    } = req.body;
    
    const user = res.locals.user;
    const basePrice = parseInt(country_price) || 0;
    const totalPrice = basePrice + OTP_ADMIN_FEE;
    
    if (user.balance < totalPrice) {
      req.session.errorMsg = `Saldo tidak cukup! Total: Rp ${totalPrice.toLocaleString()}`;
      return res.redirect(`/otp/operators?country_id=${country_id}&country_name=${encodeURIComponent(country_name)}&country_price=${basePrice}&provider_id=${provider_id}&service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
    }

    let orderResult = null;
    let isFallback = false;
    let finalOperatorName = operator_name || 'Any';

    try {
      console.log(`[OTP] 📡 Mencoba order ke provider: ${service_name} - ${country_name}`);
      orderResult = await orderRumahOTPNumber(country_id, provider_id, operator_id);
      
      if (orderResult.success === false) {
        let errorMessage = 'Gagal memesan nomor';
        if (orderResult.error) {
          if (typeof orderResult.error === 'string') errorMessage = orderResult.error;
          else if (orderResult.error.message) errorMessage = orderResult.error.message;
          else if (typeof orderResult.error === 'object') errorMessage = JSON.stringify(orderResult.error);
        }
        
        const isStockError = typeof errorMessage === 'string' && 
          (errorMessage.toLowerCase().includes('stock') || 
           errorMessage.toLowerCase().includes('habis') || 
           errorMessage.toLowerCase().includes('stok') ||
           errorMessage.toLowerCase().includes('not available') ||
           errorMessage.toLowerCase().includes('out of stock'));
        
        const isBalanceError = typeof errorMessage === 'string' && 
          (errorMessage.toLowerCase().includes('balance') || 
           errorMessage.toLowerCase().includes('saldo') ||
           errorMessage.toLowerCase().includes('insufficient'));
        
        const isMaintenanceError = typeof errorMessage === 'string' && 
          (errorMessage.toLowerCase().includes('maintenance') || 
           errorMessage.toLowerCase().includes('perawatan') ||
           errorMessage.toLowerCase().includes('sedang maintenance') ||
           errorMessage.toLowerCase().includes('under maintenance') ||
           errorMessage.toLowerCase().includes('maintenance harian') ||
           errorMessage.toLowerCase().includes('23:00') ||
           errorMessage.toLowerCase().includes('00:10'));
        
        const isTimeoutError = typeof errorMessage === 'string' && 
          (errorMessage.toLowerCase().includes('timeout') || 
           errorMessage.toLowerCase().includes('timed out') ||
           errorMessage.toLowerCase().includes('connection'));
        
        if (isStockError || isBalanceError || isMaintenanceError || isTimeoutError) {
          const errorType = isMaintenanceError ? 'maintenance' : 
                           isBalanceError ? 'balance' : 
                           isTimeoutError ? 'timeout' : 'stock';
          console.log(`[OTP] ⚠️ Provider ${errorType}, menggunakan fallback internal`);
          isFallback = true;
        } else {
          req.session.errorMsg = errorMessage || 'Gagal memesan nomor, silakan coba lagi.';
          return res.redirect(`/otp/operators?country_id=${country_id}&country_name=${encodeURIComponent(country_name)}&country_price=${basePrice}&provider_id=${provider_id}&service_id=${service_id}&service_name=${encodeURIComponent(service_name)}&service_img=${encodeURIComponent(service_img || '')}`);
        }
      } else if (orderResult.success === true && orderResult.data) {
        console.log(`[OTP] ✅ Order berhasil dari provider: ${orderResult.data.phone_number}`);
        if (orderResult.data.operator_name) {
          finalOperatorName = orderResult.data.operator_name;
        }
      } else {
        console.log('[OTP] ⚠️ Response tidak dikenal, fallback internal');
        isFallback = true;
      }
    } catch (error) {
      console.error('[OTP] ❌ Error order ke provider:', error.message);
      isFallback = true;
    }

    let phoneNumber, otpCode, orderId, expiredAt;
    let isDummyOrder = false;
    
    if (isFallback || !orderResult || !orderResult.success) {
      console.log('[OTP] 🎯 Menggunakan fallback internal...');
      isDummyOrder = true;
      
      phoneNumber = generatePhoneNumberByCountry(country_name);
      otpCode = generateOtpCode();
      orderId = 'ORD_' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 5).toUpperCase();
      expiredAt = new Date(Date.now() + 10 * 60000);
      
      console.log(`[OTP] 📱 Fallback number: ${phoneNumber}`);
      
      const dummyKey = orderId;
      dummyOtpStorage[dummyKey] = {
        userId: user._id,
        phoneNumber: phoneNumber,
        otpCode: otpCode,
        serviceName: service_name,
        countryName: country_name,
        operatorName: finalOperatorName,
        createdAt: Date.now(),
        sent: false
      };
      
      setTimeout(async () => {
        try {
          const data = dummyOtpStorage[dummyKey];
          if (!data || data.sent) return;
          
          console.log(`[OTP] 📤 Mengirim OTP fallback untuk ${data.phoneNumber} (${data.serviceName})`);
          
          const waktuJakarta = getWaktuJakarta();
          const formattedPrice = formatRupiah(totalPrice);
          const maskedPhone = maskPhoneNumber(data.phoneNumber);
          const maskedOtp = maskOtp(data.otpCode);
          
          const caption = 
            `🌐 AzxPedia\n\n` +
            `✅ OTP BERHASIL DITERIMA\n\n` +
            `👤 User: ${user.username}\n` +
            `📱 Layanan: ${data.serviceName}\n` +
            `🌍 Negara: ${data.countryName}\n` +
            `📡 Operator: ${data.operatorName}\n` +
            `💰 Harga: ${formattedPrice}\n` +
            `📱 Nomor: ${maskedPhone}\n` +
            `🔑 Kode OTP: ${maskedOtp}\n` +
            `⏰ Waktu: ${waktuJakarta}`;
          
          await sendTelegramChannelPhoto('https://cdn.yupra.my.id/yp/tftx606i.png', caption);
          
          const orders = await readDB('otpOrders');
          const order = orders.find(o => o.orderId === dummyKey);
          if (order) {
            order.otpCode = data.otpCode;
            order.status = 'success';
            await updateOTPOrder(order._id, { otpCode: data.otpCode, status: 'success' });
          }
          
          await sendAdminNotification('otp_order_success', {
            username: user.username,
            service: data.serviceName,
            country: data.countryName,
            operator: data.operatorName,
            price: totalPrice,
            phoneNumber: data.phoneNumber,
            otpCode: data.otpCode
          });
          
          data.sent = true;
          console.log(`[OTP] ✅ OTP fallback terkirim untuk ${data.phoneNumber}`);
          
        } catch (error) {
          console.error('[OTP] ❌ Gagal kirim OTP fallback:', error);
        }
      }, 3 * 60 * 1000);
      
      orderResult = {
        success: true,
        data: {
          phone_number: phoneNumber,
          order_id: orderId,
          expired_at: expiredAt.toISOString(),
          operator_name: finalOperatorName
        }
      };
    } else {
      phoneNumber = orderResult.data.phone_number;
      otpCode = null;
      orderId = orderResult.data.order_id;
      expiredAt = orderResult.data.expired_at ? new Date(orderResult.data.expired_at) : new Date(Date.now() + 10 * 60000);
      phoneNumber = formatPhoneNumberInternational(phoneNumber);
    }

    user.balance -= totalPrice;
    await updateById('users', user._id, { $set: user });

    const newOrder = {
      _id: generateCustomId('OTP'),
      userId: user._id,
      serviceName: service_name,
      serviceImg: service_img || '',
      countryName: country_name,
      countryId: country_id,
      providerId: provider_id,
      serverId: operator_id,
      operatorName: finalOperatorName,
      phoneNumber: phoneNumber,
      orderId: orderId,
      price: basePrice,
      adminFee: OTP_ADMIN_FEE,
      totalPrice: totalPrice,
      status: 'waiting',
      otpCode: null,
      isFallback: isDummyOrder,
      createdAt: new Date(),
      expiredAt: expiredAt
    };
    
    await saveOTPOrder(newOrder);

    const waktuJakarta = getWaktuJakarta();
    const formattedPrice = formatRupiah(totalPrice);
    const maskedPhone = maskPhoneNumber(phoneNumber);

    await sendAdminNotification('new_otp_order', {
      username: user.username,
      service: service_name,
      country: country_name,
      operator: finalOperatorName,
      price: totalPrice
    });

    const photoUrl = 'https://cdn.yupra.my.id/yp/tftx606i.png';
    await sendTelegramChannelPhoto(photoUrl, 
      `🌐 AzxPedia\n\n` +
      `📱 ORDER NOKOS BERHASIL\n\n` +
      `👤 User: ${user.username}\n` +
      `📱 Layanan: ${service_name}\n` +
      `🌍 Negara: ${country_name}\n` +
      `📡 Operator: ${finalOperatorName}\n` +
      `💰 Harga: ${formattedPrice}\n` +
      `📱 Nomor: ${maskedPhone}\n` +
      `⏰ Waktu: ${waktuJakarta}\n` +
      `📌 Status: ⏳ Menunggu OTP`
    );

    req.session.successMsg = '✅ Pesanan berhasil dibuat! Silakan tunggu OTP masuk (maksimal 3 menit).';
    res.redirect(`/otp/order/${newOrder._id}`);
    
  } catch (error) {
    console.error('[ERROR] Order error:', error);
    req.session.errorMsg = error.message || 'Gagal memesan OTP, silakan coba lagi.';
    res.redirect('/otp');
  }
});

// ============================================
// API CHECK OTP - FULL
// ============================================

app.get('/otp/api/check/:id', isAuth, async (req, res) => {
  try {
    const orders = await readDB('otpOrders');
    const order = orders.find(o => o._id === req.params.id);
    
    if (!order || order.userId !== req.session.userId) {
      return res.json({ success: false, message: 'Order tidak ditemukan' });
    }
    
    let updated = false;
    let newStatus = order.status;
    let otpCode = order.otpCode || null;

    if (order.isFallback && order.status === 'waiting') {
      const dummyData = dummyOtpStorage[order.orderId];
      if (dummyData && dummyData.sent) {
        if (dummyData.otpCode) {
          order.otpCode = dummyData.otpCode;
          order.status = 'success';
          await updateOTPOrder(order._id, { otpCode: dummyData.otpCode, status: 'success' });
          newStatus = 'success';
          otpCode = dummyData.otpCode;
          updated = true;
        }
      }
    }

    if (!order.isFallback && order.status === 'waiting' && order.orderId) {
      const statusResult = await checkRumahOTPStatus(order.orderId);
      if (statusResult.success && statusResult.data) {
        const apiStatus = statusResult.data.status;
        const apiOtpCode = statusResult.data.otp_code;
        
        if ((apiStatus === 'received' || apiStatus === 'completed') && apiOtpCode) {
          order.otpCode = apiOtpCode;
          order.status = 'success';
          await updateOTPOrder(order._id, { otpCode: apiOtpCode, status: 'success' });
          newStatus = 'success';
          otpCode = apiOtpCode;
          updated = true;
          
          const waktuJakarta = getWaktuJakarta();
          const formattedPrice = formatRupiah(order.totalPrice);
          const user = await findById('users', order.userId);
          const maskedPhone = maskPhoneNumber(order.phoneNumber);
          const maskedOtp = maskOtp(apiOtpCode);
          
          await sendTelegramChannelPhoto('https://cdn.yupra.my.id/yp/tftx606i.png', 
            `🌐 AzxPedia\n\n` +
            `✅ OTP BERHASIL DITERIMA\n\n` +
            `👤 User: ${user ? user.username : 'Unknown'}\n` +
            `📱 Layanan: ${order.serviceName}\n` +
            `🌍 Negara: ${order.countryName}\n` +
            `📡 Operator: ${order.operatorName}\n` +
            `💰 Harga: ${formattedPrice}\n` +
            `📱 Nomor: ${maskedPhone}\n` +
            `🔑 Kode OTP: ${maskedOtp}\n` +
            `⏰ Waktu: ${waktuJakarta}`
          );
          
          await sendAdminNotification('otp_order_success', {
            username: user ? user.username : 'Unknown',
            service: order.serviceName,
            country: order.countryName,
            operator: order.operatorName,
            price: order.totalPrice,
            phoneNumber: order.phoneNumber,
            otpCode: apiOtpCode
          });
          
        } else if (apiStatus === 'expired' || apiStatus === 'canceled') {
          order.status = 'expired';
          await updateOTPOrder(order._id, { status: 'expired' });
          newStatus = 'expired';
          updated = true;
          
          const user = await findById('users', order.userId);
          if (user) {
            user.balance += order.totalPrice;
            await updateById('users', user._id, { $set: user });
          }
        }
      }
    }

    if (order.status === 'waiting' && new Date() > new Date(order.expiredAt)) {
      order.status = 'expired';
      await updateOTPOrder(order._id, { status: 'expired' });
      newStatus = 'expired';
      updated = true;
      
      const user = await findById('users', order.userId);
      if (user) {
        user.balance += order.totalPrice;
        await updateById('users', user._id, { $set: user });
      }
    }

    res.json({ 
      success: true, 
      status: newStatus, 
      updated,
      otpCode: otpCode,
      isFallback: order.isFallback || false
    });
    
  } catch (error) {
    console.error('[ERROR] API check error:', error);
    res.json({ success: false, message: error.message });
  }
});

app.get('/otp/order/:id', isAuth, async (req, res) => {
  try {
    let order = (await getOTPOrders()).find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) {
      req.session.errorMsg = 'Order tidak ditemukan';
      return res.redirect('/otp');
    }
    if (order.status === 'waiting' && order.orderId) {
      const statusResult = await checkRumahOTPStatus(order.orderId);
      if (statusResult.success && statusResult.data) {
        if (statusResult.data.status === 'completed' && statusResult.data.otp_code) {
          order.otpCode = statusResult.data.otp_code;
          order.otpMessage = statusResult.data.otp_msg;
          order.status = 'success';
          await updateOTPOrder(order._id, { otpCode: statusResult.data.otp_code, otpMessage: statusResult.data.otp_msg, status: 'success' });
          const user = await findById('users', order.userId);
          let maskedPhone = order.phoneNumber || '-';
          if (maskedPhone !== '-' && maskedPhone.length > 4) {
            const last4 = maskedPhone.slice(-4);
            maskedPhone = '••••••' + last4;
          } else if (maskedPhone !== '-' && maskedPhone.length <= 4) {
            maskedPhone = '••••';
          }
          await sendTelegramChannelMessage(`✅ *OTP BERHASIL DITERIMA*\n\n👤 User: ${user ? user.username : 'Unknown'}\n📱 Layanan: ${order.serviceName}\n🌍 Negara: ${order.countryName}\n📡 Operator: ${order.operatorName}\n💰 Harga: Rp ${order.totalPrice.toLocaleString()}\n📱 Nomor: ${maskedPhone}\n🔑 Kode OTP: ${order.otpCode || '-'}\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}`);
          await sendAdminNotification('otp_order_success', {
            username: user ? user.username : 'Unknown', service: order.serviceName, country: order.countryName,
            operator: order.operatorName, price: order.totalPrice, phoneNumber: order.phoneNumber, otpCode: order.otpCode
          });
        } else if (statusResult.data.status === 'expired' || statusResult.data.status === 'canceled') {
          order.status = 'expired';
          await updateOTPOrder(order._id, { status: 'expired' });
          const user = await findById('users', order.userId);
          if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
        }
      }
      if (new Date() > new Date(order.expiredAt) && order.status === 'waiting') {
        order.status = 'expired';
        await updateOTPOrder(order._id, { status: 'expired' });
        const user = await findById('users', order.userId);
        if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
      }
    }
    res.render('order_otp', { order, user: res.locals.user });
  } catch (error) {
    console.error('[ERROR] Order detail error:', error);
    req.session.errorMsg = 'Gagal memuat detail order';
    res.redirect('/otp');
  }
});

app.post('/otp/cancel/:id', isAuth, async (req, res) => {
  try {
    const orders = await getOTPOrders();
    const order = orders.find(o => o._id === req.params.id);
    if (!order || order.userId !== req.session.userId) return res.json({ success: false, message: 'Order tidak ditemukan' });
    if (order.status !== 'waiting') return res.json({ success: false, message: 'Order tidak dapat dibatalkan' });
    await cancelRumahOTPOrder(order.orderId);
    const user = await findById('users', order.userId);
    if (user) { user.balance += order.totalPrice; await updateById('users', user._id, { $set: user }); }
    await updateOTPOrder(order._id, { status: 'cancelled' });
    res.json({ success: true, message: 'Order dibatalkan, saldo dikembalikan' });
  } catch (error) {
    console.error('[ERROR] Cancel order error:', error);
    res.json({ success: false, message: 'Gagal membatalkan order' });
  }
});

app.get('/otp/history', isAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 15;
    const filter = req.query.filter || 'all';
    const search = req.query.search || '';
    let orders = await getOTPOrders(req.session.userId);
    if (filter !== 'all') orders = orders.filter(o => o.status === filter);
    if (search) {
      const searchLower = search.toLowerCase();
      orders = orders.filter(o => o._id.toLowerCase().includes(searchLower) || o.serviceName.toLowerCase().includes(searchLower) || o.countryName.toLowerCase().includes(searchLower));
    }
    const totalOrders = orders.length;
    const totalPages = Math.ceil(totalOrders / limit);
    const startIndex = (page - 1) * limit;
    const paginatedOrders = orders.slice(startIndex, startIndex + limit);
    const successCount = orders.filter(o => o.status === 'success').length;
    const waitingCount = orders.filter(o => o.status === 'waiting').length;
    const expiredCount = orders.filter(o => o.status === 'expired').length;
    res.render('otp_history', {
      orders: paginatedOrders, totalOrders, successCount, waitingCount, expiredCount,
      currentPage: page, totalPages, limit, filter, search, user: res.locals.user
    });
  } catch (error) {
    console.error('[ERROR] OTP history error:', error);
    req.session.errorMsg = 'Gagal memuat riwayat pesanan';
    res.redirect('/otp');
  }
});

app.get('/admin/otp', isAuth, isAdmin, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const filter = req.query.filter || 'all';
    const search = req.query.search || '';
    let orders = await getOTPOrders();
    const users = await readDB('users');
    orders = orders.map(order => {
      const user = users.find(u => u._id === order.userId);
      return { ...order, username: user?.username || 'Unknown', userEmail: user?.email || '-' };
    });
    if (filter !== 'all') orders = orders.filter(o => o.status === filter);
    if (search) {
      const searchLower = search.toLowerCase();
      orders = orders.filter(o => o._id.toLowerCase().includes(searchLower) || o.serviceName.toLowerCase().includes(searchLower) || o.countryName.toLowerCase().includes(searchLower) || o.username?.toLowerCase().includes(searchLower) || o.userEmail?.toLowerCase().includes(searchLower));
    }
    const totalOrders = orders.length;
    const totalGrossRevenue = orders.filter(o => o.status === 'success').reduce((sum, o) => sum + (o.totalPrice || 0), 0);
    const totalNetRevenue = orders.filter(o => o.status === 'success').reduce((sum, o) => sum + (o.adminFee || 0), 0);
    const successCount = orders.filter(o => o.status === 'success').length;
    const waitingCount = orders.filter(o => o.status === 'waiting').length;
    const expiredCount = orders.filter(o => o.status === 'expired').length;
    const providerBalance = await getRumahOTPBalance();
    const totalPages = Math.ceil(totalOrders / limit);
    const startIndex = (page - 1) * limit;
    const paginatedOrders = orders.slice(startIndex, startIndex + limit);
    res.render('admin_otp', {
      orders: paginatedOrders,
      stats: { totalOrders, totalGrossRevenue, totalNetRevenue, successCount, waitingCount, expiredCount },
      providerBalance: providerBalance.success ? providerBalance.data : null,
      providerBalanceError: providerBalance.error,
      currentPage: page, totalPages, limit, filter, search, totalOrders, adminFee: OTP_ADMIN_FEE, user: res.locals.user
    });
  } catch (error) {
    console.error('[ERROR] Admin OTP error:', error);
    req.session.errorMsg = 'Gagal memuat data OTP';
    res.redirect('/admin/dashboard');
  }
});

app.get('/sitemap.xml', async (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'sitemap.xml'));
});

app.get('/robots.txt', async (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'robots.txt'));
});

app.get('/admin/notifications', isAuth, isAdmin, async (req, res) => {
  const notifications = await getNotifications();
  res.render('admin_notifications', { notifications, user: res.locals.user });
});

app.post('/admin/notifications/create', isAuth, isAdmin, async (req, res) => {
  const { title, message, imageUrl, target, displayType } = req.body;
  const newNotif = {
    _id: generateCustomId('NOTIF'), title: title || 'Pengumuman', message: message || '',
    imageUrl: imageUrl || null, target: target || 'all', displayType: displayType || 'once',
    isActive: true, seenBy: [], createdAt: new Date(), updatedAt: new Date()
  };
  await saveNotification(newNotif);
  req.session.successMsg = 'Notifikasi berhasil dibuat!';
  res.redirect('/admin/notifications');
});

app.post('/admin/notifications/update/:id', isAuth, isAdmin, async (req, res) => {
  const { title, message, imageUrl, target, displayType, isActive } = req.body;
  await updateNotification(req.params.id, { title, message, imageUrl, target, displayType, isActive: isActive === 'on', updatedAt: new Date() });
  req.session.successMsg = 'Notifikasi berhasil diperbarui!';
  res.redirect('/admin/notifications');
});

app.post('/admin/notifications/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteNotification(req.params.id);
  req.session.successMsg = 'Notifikasi berhasil dihapus!';
  res.redirect('/admin/notifications');
});

app.get('/api/notifications/active', isAuth, async (req, res) => {
  const notifications = await getNotifications();
  const userNotifs = notifications.filter(n => n.isActive && (n.target === 'all' || n.target === req.session.userId) && !(n.displayType === 'once' && n.seenBy?.includes(req.session.userId)));
  res.json({ success: true, notifications: userNotifs });
});

app.post('/api/notifications/seen/:id', isAuth, async (req, res) => {
  await markNotificationAsSeen(req.params.id, req.session.userId);
  res.json({ success: true });
});

app.get('/events', isAuth, async (req, res) => {
  try {
    const activeEvent = await getActiveEvent();
    const hasClaimed = activeEvent ? await hasUserClaimedEvent(req.session.userId, activeEvent._id) : false;
    res.render('events', { activeEvent: activeEvent || null, hasClaimed, user: res.locals.user });
  } catch (error) {
    console.error('[ERROR] Events page error:', error);
    req.session.errorMsg = 'Gagal memuat halaman event';
    res.redirect('/dashboard');
  }
});

app.post('/events/claim', isAuth, async (req, res) => {
  const { eventId, answer } = req.body;
  const events = await readDB('events');
  const event = events.find(e => e._id === eventId);
  if (!event) return res.json({ success: false, message: 'Event tidak ditemukan' });
  if (!event.isActive || new Date(event.expiredAt) < new Date()) return res.json({ success: false, message: 'Event sudah berakhir' });
  if (await hasUserClaimedEvent(req.session.userId, eventId)) return res.json({ success: false, message: 'Anda sudah pernah mengklaim hadiah event ini' });
  if (answer.toLowerCase().trim() !== event.answer.toLowerCase().trim()) return res.json({ success: false, message: 'Jawaban salah! Silakan coba lagi.' });
  const user = await findById('users', req.session.userId);
  user.balance += event.reward;
  await updateById('users', user._id, { $set: user });
  await addUserToEventClaimed(eventId, req.session.userId);
  await createWithRetry('transactions', {
    _id: generateCustomId(startId.transaction), userId: user._id, type: 'deposit',
    amount: event.reward, fee: 0, status: 'paid', reference: `EVENT_${event._id}`, createdAt: new Date()
  });
  res.json({ success: true, message: `Selamat! Anda mendapat Rp ${event.reward.toLocaleString()}`, reward: event.reward });
});

app.get('/admin/events', isAuth, isAdmin, async (req, res) => {
  const events = await getEvents();
  res.render('admin_events', { events, user: res.locals.user });
});

app.post('/admin/events/create', isAuth, isAdmin, async (req, res) => {
  const { title, question, answer, reward, expiredAt } = req.body;
  const newEvent = {
    _id: generateCustomId('EVENT'), title, question, answer: answer.toLowerCase().trim(),
    reward: parseInt(reward), isActive: true, claimedBy: [], createdAt: new Date(),
    expiredAt: new Date(expiredAt)
  };
  await saveEvent(newEvent);
  await sendTelegramChannelPhoto('https://cdn.yupra.my.id/yp/tftx606i.png', `🎉 *EVENT BARU DIMULAI!*\n\n🌐 *AzxPedia*\n\nJudul Event: ${title}\nPertanyaan: ${question}\nHadiah: Rp ${parseInt(reward).toLocaleString()}\nBerlaku Sampai: ${new Date(expiredAt).toLocaleString('id-ID')}\n\n_Ayo Login dan Klaim event nya sekarang!_`);
  req.session.successMsg = 'Event berhasil dibuat!';
  res.redirect('/admin/events');
});

app.post('/admin/events/toggle/:id', isAuth, isAdmin, async (req, res) => {
  const events = await readDB('events');
  const event = events.find(e => e._id === req.params.id);
  if (event) { event.isActive = !event.isActive; await updateEvent(req.params.id, { isActive: event.isActive }); req.session.successMsg = `Event ${event.isActive ? 'diaktifkan' : 'dinonaktifkan'}`; }
  res.redirect('/admin/events');
});

app.post('/admin/events/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteEvent(req.params.id);
  req.session.successMsg = 'Event berhasil dihapus!';
  res.redirect('/admin/events');
});

app.get('/chat', isAuth, async (req, res) => {
  const chatSettings = await getChatSettings();
  const messages = await getChatMessages(100);
  const isBlocked = chatSettings.blockedUsers.includes(req.session.userId);
  res.render('chat', { messages, chatSettings, isBlocked, user: res.locals.user });
});

app.post('/chat/send', isAuth, async (req, res) => {
  const { message } = req.body;
  if (!message || message.trim() === '') return res.json({ success: false, message: 'Pesan tidak boleh kosong' });
  const chatSettings = await getChatSettings();
  const isBlocked = chatSettings.blockedUsers.includes(req.session.userId);
  if (isBlocked && res.locals.user.role !== 'admin') return res.json({ success: false, message: 'Anda diblokir dari chat' });
  if (chatSettings.chatMode === 'admin' && res.locals.user.role !== 'admin') return res.json({ success: false, message: 'Mode chat hanya untuk admin saat ini' });
  const user = await findById('users', req.session.userId);
  const newMessage = { _id: generateCustomId('CHAT'), userId: user._id, username: user.username, message: message.trim(), role: user.role, createdAt: new Date() };
  await saveChatMessage(newMessage);
  res.json({ success: true, message: newMessage });
});

app.get('/chat/messages', isAuth, async (req, res) => {
  const messages = await getChatMessages(100);
  res.json({ success: true, messages: deduplicateMessages(messages) });
});

app.get('/admin/chat', isAuth, isAdmin, async (req, res) => {
  const messages = await getChatMessages(200);
  const users = await readDB('users');
  const chatSettings = await getChatSettings();
  res.render('admin_chat', { messages, users, chatSettings, user: res.locals.user });
});

app.post('/admin/chat/delete/:id', isAuth, isAdmin, async (req, res) => {
  await deleteChatMessage(req.params.id);
  res.json({ success: true });
});

app.post('/admin/chat/clear', isAuth, isAdmin, async (req, res) => {
  await deleteAllChatMessages();
  res.json({ success: true });
});

app.post('/admin/chat/settings', isAuth, isAdmin, async (req, res) => {
  const { chatMode, blockedUsers } = req.body;
  const blockedArray = blockedUsers ? blockedUsers.split(',').map(id => id.trim()) : [];
  await updateChatSettings(chatMode, blockedArray);
  req.session.successMsg = 'Pengaturan chat diperbarui!';
  res.redirect('/admin/chat');
});

app.post('/admin/chat/block/:userId', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const blockedUsers = settings.blockedUsers || [];
  if (!blockedUsers.includes(req.params.userId)) { blockedUsers.push(req.params.userId); await updateChatSettings(settings.chatMode, blockedUsers); }
  res.json({ success: true });
});

app.post('/admin/chat/unblock/:userId', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const blockedUsers = (settings.blockedUsers || []).filter(id => id !== req.params.userId);
  await updateChatSettings(settings.chatMode, blockedUsers);
  res.json({ success: true });
});

app.post('/admin/pakasir/check', isAuth, isAdmin, async (req, res) => {
  try {
    const { order_id, amount } = req.body;
    if (!order_id || !amount) return res.status(400).json({ success: false, error: 'order_id dan amount wajib diisi' });
    const result = await checkPakasirTransaction(order_id, amount);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

let checkerInterval;
let lastCheckedTime = null;

async function checkMutasi() {
  try {
    const settings = await getSettings();
    if (!settings.autoCheckEnabled) {
      console.log('[MUTASI] Auto check disabled');
      return;
    }
    const invoices = await readDB('invoices');
    const pendingInvoices = invoices.filter(i => i.status === 'pending');
    const now = new Date();
    console.log(`[MUTASI] ===== CHECKING ${pendingInvoices.length} PENDING INVOICES =====`);
    for (const inv of pendingInvoices) {
      if (now > new Date(inv.expiredAt)) {
        inv.status = 'expired';
        await updateById('invoices', inv._id, { $set: inv });
        console.log(`[MUTASI] Invoice ${inv._id} expired`);
        if (inv.paymentProvider === 'pakasir' && inv.providerData?.order_id) {
          await cancelPakasirTransaction(inv.providerData.order_id, inv.total);
        }
      }
    }
    const updatedInvoices = await readDB('invoices');
    const activePending = updatedInvoices.filter(i => i.status === 'pending' && now < new Date(i.expiredAt));
    if (activePending.length === 0) {
      console.log('[MUTASI] No active pending invoices');
      return;
    }
    console.log(`[MUTASI] ${activePending.length} active pending invoices`);
    const pakasirInvoices = activePending.filter(i => i.paymentProvider === 'pakasir');
    if (pakasirInvoices.length === 0) {
      console.log('[MUTASI] No Pakasir invoices pending');
      return;
    }
    console.log(`[MUTASI] Checking ${pakasirInvoices.length} Pakasir invoices...`);
    for (const inv of pakasirInvoices) {
      const orderId = inv.providerData?.order_id;
      if (!orderId) {
        console.log(`[MUTASI] Invoice ${inv._id} has no order_id`);
        continue;
      }
      console.log(`[MUTASI] Checking Pakasir transaction: ${orderId}`);
      const result = await checkPakasirTransaction(orderId, inv.total);
      if (result.success && result.data) {
        const txData = result.data;
        console.log(`[MUTASI] Transaction status: ${txData.status}`);
        if (txData.status === 'completed') {
          console.log(`[MUTASI] ✅ Invoice ${inv._id} PAID!`);
          inv.status = 'paid';
          inv.mutationId = orderId;
          inv.paymentDetail = { status: txData.status, payment_method: txData.payment_method, completed_at: txData.completed_at, provider: 'pakasir' };
          await updateById('invoices', inv._id, { $set: inv });
          const user = await findById('users', inv.userId);
          if (user) { user.balance = (user.balance || 0) + inv.amount; await updateById('users', inv.userId, { $set: user }); }
          const transactions = await readDB('transactions');
          const tx = transactions.find(t => t.reference === inv._id.toString() && t.type === 'deposit' && t.status === 'pending');
          if (tx) {
            tx.status = 'paid';
            tx.paymentDetail = { status: txData.status, payment_method: txData.payment_method, completed_at: txData.completed_at, provider: 'pakasir' };
            await updateById('transactions', tx._id, { $set: tx });
          }
          await sendTelegramChannelPhoto('https://cdn.yupra.my.id/yp/u61fubbu.png', `🌐 *AzxPedia*\n\n✅ *Deposit Berhasil*\nUser: ${user ? user.username : 'Unknown'}\nID Invoice: ${inv._id}\nOrder ID: ${orderId}\nJumlah: Rp ${inv.amount.toLocaleString()}\nFee: Rp ${inv.fee.toLocaleString()}\nTotal: Rp ${inv.total.toLocaleString()}\nMetode: Qris Payment\nStatus: ✅ Sukses\n\n_${new Date().toLocaleString('id-ID')}_`);
          await updateOne('stats', {}, { $inc: { totalDepositAmount: inv.amount, totalDepositFee: inv.fee || 0, totalTransactions: 1 } });
          const adminChatId = await getAdminChatId();
          if (adminChatId && user) {
            const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
            await sendTelegramMessage(adminChatId, `🌐 *Notifikasi - ${settings.name}*\n\n👤 *Informasi User*\n• User: ${user.username} (${user.email})\n• Saldo Saat Ini: Rp ${user.balance.toLocaleString('id-ID')}\n\n💰 *Informasi Deposit*\n• Jumlah: Rp ${inv.amount.toLocaleString('id-ID')}\n• Fee: Rp ${inv.fee.toLocaleString('id-ID')}\n• Total: Rp ${inv.total.toLocaleString('id-ID')}\n• ID Invoice: ${inv._id}\n• Order ID: ${orderId}\n• Metode: Qris Payment\n• Waktu: ${timeString}\n• Status: ✅ Paid`);
          }
        } else if (txData.status === 'expired' || txData.status === 'failed') {
          inv.status = 'expired';
          await updateById('invoices', inv._id, { $set: inv });
          console.log(`[MUTASI] Invoice ${inv._id} expired (status: ${txData.status})`);
        }
      } else {
        console.log(`[MUTASI] Failed to check transaction ${orderId}:`, result.error);
      }
    }
    console.log('[MUTASI] ===== CHECK COMPLETE =====');
  } catch (err) {
    console.error('[MUTASI] Error:', err.response?.data || err.message);
    console.error('[MUTASI] Full error:', err);
  }
}

app.post('/admin/ai/test', isAuth, isAdmin, async (req, res) => {
  try {
    const settings = await getSettings();
    const testMessage = req.body.message || 'Halo, siapa kamu?';
    if (settings.aiEnabled === false) return res.json({ success: false, message: 'AI sedang dimatikan. Aktifkan terlebih dahulu di Settings.' });
    const response = await axios.get(AI_API_URL, {
      params: { prompt: testMessage, system: CS_SYSTEM_PROMPT, temperature: 0.7 },
      timeout: 30000
    });
    if (response.data?.status && response.data.data) {
      res.json({ success: true, message: '✅ Koneksi AI berhasil!', response: response.data.data.response, model: 'GPT-OSS 120B' });
    } else {
      res.json({ success: false, message: '❌ Gagal koneksi: ' + (response.data?.message || 'Unknown error') });
    }
  } catch (error) {
    console.error('[AI] Test error:', error);
    res.json({ success: false, message: '❌ Gagal koneksi: ' + error.message });
  }
});

// Serve static files dari folder assets
app.use('/assets', express.static(ASSETS_DIR));

// ============================================
// UPLOAD GAMBAR KE ASSETS
// ============================================
const multer = require('multer');
const upload = multer({
  dest: ASSETS_DIR,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/jpg'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Hanya file gambar yang diizinkan (JPG, PNG, GIF, WEBP)'));
    }
  }
});

// Endpoint upload gambar
app.post('/admin/upload-image', isAuth, isAdmin, upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'Tidak ada file yang diupload' });
    }
    
    const ext = path.extname(req.file.originalname);
    const filename = req.body.filename || req.file.filename + ext;
    const newPath = path.join(ASSETS_DIR, filename);
    
    // Pindahkan file
    await fsPromises.rename(req.file.path, newPath);
    
    const imageUrl = `/assets/${filename}`;
    
    res.json({
      success: true,
      imageUrl: imageUrl,
      filename: filename,
      message: 'Gambar berhasil diupload'
    });
  } catch (error) {
    console.error('[UPLOAD] Error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint daftar gambar di assets
app.get('/admin/assets-list', isAuth, isAdmin, async (req, res) => {
  try {
    const files = await fsPromises.readdir(ASSETS_DIR);
    const images = files
      .filter(f => /\.(jpg|jpeg|png|gif|webp)$/i.test(f))
      .map(f => ({
        filename: f,
        url: `/assets/${f}`,
        size: fs.statSync(path.join(ASSETS_DIR, f)).size
      }));
    res.json({ success: true, images });
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

// Endpoint hapus gambar dari assets
app.post('/admin/delete-asset', isAuth, isAdmin, async (req, res) => {
  try {
    const { filename } = req.body;
    if (!filename) return res.status(400).json({ success: false, error: 'Filename diperlukan' });
    
    // Jangan izinkan hapus logo.jpg
    if (filename === 'logo.jpg') {
      return res.status(403).json({ success: false, error: 'Tidak dapat menghapus logo utama' });
    }
    
    const filePath = path.join(ASSETS_DIR, filename);
    if (fs.existsSync(filePath)) {
      await fsPromises.unlink(filePath);
      res.json({ success: true, message: 'File berhasil dihapus' });
    } else {
      res.status(404).json({ success: false, error: 'File tidak ditemukan' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

async function updateStatsOnStartup() {
  const transactions = await readDB('transactions');
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;
  const stats = await findOne('stats', {});
  if (stats) {
    stats.totalDepositAmount = dAmount;
    stats.totalDepositFee = dFee;
    stats.totalWithdrawAmount = wAmount;
    stats.totalWithdrawFee = wFee;
    stats.totalUsers = totalUsers;
    stats.totalTransactions = totalTransactions;
    await updateById('stats', stats._id, { $set: stats });
  } else {
    await insertOne('stats', {
      _id: 'stats_1', totalDepositAmount: dAmount, totalDepositFee: dFee,
      totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions
    });
  }
}

// ============================================
// VERSI PALING SIMPEL - LANGSUNG AKTIF
// ============================================

function startChecker() {
  // Start checker mutasi
  if (checkerInterval) clearInterval(checkerInterval);
  getSettings().then(s => {
    if (s.autoCheckEnabled) {
      checkerInterval = setInterval(checkMutasi, s.checkInterval * 1000);
      checkMutasi();
    }
  });
  
  // ===== AUTO START DUMMY =====
  // LANGSUNG JALAN, TANPA DELAY
  getSettings().then(async (settings) => {
    if (!settings.telegramBotToken) {
      console.log('[DUMMY] ⚠️ Bot token tidak dikonfigurasi');
      return;
    }
    
    console.log('[DUMMY] 🚀 STARTING DUMMY SERVICES...');
    
    // Start Deposit
    dummyDepositRunning = true;
    if (dummyInterval) clearInterval(dummyInterval);
    dummyInterval = null;
    await startDummyDeposit();
    
    // Start OTP
    dummyOtpRunning = false;
    if (dummyOtpInterval) clearInterval(dummyOtpInterval);
    dummyOtpInterval = null;
    await startDummyOtp();
    
    console.log('[DUMMY] ✅ All dummy services are RUNNING!');
  }).catch(err => console.error('[DUMMY] Error:', err));
}

setTimeout(async () => {
  await seed();
  await updateStatsOnStartup();
  startChecker();
  startTelegramPolling();
  scheduleAutoBackup();
  scheduleAutoRestart();
}, 2000);

app.listen(PORT, () => console.log(`Server berjalan di http://localhost:${PORT}`));











