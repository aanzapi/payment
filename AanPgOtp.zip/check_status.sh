#!/bin/bash

# ============================================
# Check Installation Status
# ============================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   AZX Gateway - Installation Status       ${NC}"
echo -e "${BLUE}============================================${NC}"

# Check Node.js
echo -ne "\nNode.js: "
if command -v node &> /dev/null; then
    echo -e "${GREEN}✓ $(node -v)${NC}"
else
    echo -e "${RED}✗ Not installed${NC}"
fi

# Check NPM
echo -ne "NPM: "
if command -v npm &> /dev/null; then
    echo -e "${GREEN}✓ $(npm -v)${NC}"
else
    echo -e "${RED}✗ Not installed${NC}"
fi

# Check Flutter
echo -ne "Flutter: "
if command -v flutter &> /dev/null; then
    echo -e "${GREEN}✓ $(flutter --version | head -n1)${NC}"
elif [ -f "/opt/flutter/bin/flutter" ]; then
    echo -e "${GREEN}✓ Found at /opt/flutter${NC}"
else
    echo -e "${RED}✗ Not installed${NC}"
fi

# Check Android SDK
echo -ne "Android SDK: "
if [ -d "/opt/android-sdk" ]; then
    echo -e "${GREEN}✓ Installed${NC}"
else
    echo -e "${YELLOW}⚠ Not installed (optional)${NC}"
fi

# Check Java
echo -ne "Java: "
if command -v java &> /dev/null; then
    echo -e "${GREEN}✓ $(java -version 2>&1 | head -n1)${NC}"
else
    echo -e "${YELLOW}⚠ Not installed (optional)${NC}"
fi

# Check directories
echo -e "\n${BLUE}Directories:${NC}"
for dir in data builds builds/uploads builds/results builds/temp public; do
    echo -ne "  $dir: "
    if [ -d "$dir" ]; then
        echo -e "${GREEN}✓ Exists${NC}"
    else
        echo -e "${YELLOW}⚠ Missing${NC}"
    fi
done

# Check .env file
echo -ne "\n.env file: "
if [ -f ".env" ]; then
    echo -e "${GREEN}✓ Exists${NC}"
else
    echo -e "${YELLOW}⚠ Missing (copy from .env.example)${NC}"
fi

echo -e "\n${BLUE}============================================${NC}"