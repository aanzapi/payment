const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const AdmZip = require('adm-zip');
const { getPendingBuilds, updateFlutterBuild } = require('./database');

const BUILDS_DIR = path.join(__dirname, '../../builds');
const BUILDS_TEMP_DIR = path.join(BUILDS_DIR, 'temp');
const BUILDS_RESULT_DIR = path.join(BUILDS_DIR, 'results');
const BUILD_EXPIRY_HOURS = 1;

let isProcessing = false;
let currentBuild = null;

async function processBuildQueue() {
  if (isProcessing) return;
  
  try {
    const pendingBuilds = await getPendingBuilds();
    if (pendingBuilds.length === 0) return;
    
    const build = pendingBuilds[0];
    if (!build) return;
    
    console.log(`[BUILDER] Processing build: ${build._id}`);
    
    isProcessing = true;
    currentBuild = build;
    await updateFlutterBuild(build._id, { status: 'processing', startedAt: new Date() });
    
    const extractPath = path.join(BUILDS_TEMP_DIR, build._id);
    const apkOutputPath = path.join(BUILDS_RESULT_DIR, `${build._id}.apk`);
    
    if (!fs.existsSync(extractPath)) fs.mkdirSync(extractPath, { recursive: true });
    
    // Ekstrak ZIP
    const zip = new AdmZip(build.originalFile);
    zip.extractAllTo(extractPath, true);
    console.log(`[BUILDER] Extracted to: ${extractPath}`);
    
    // Cek apakah ini project Flutter
    const pubspecPath = path.join(extractPath, 'pubspec.yaml');
    if (!fs.existsSync(pubspecPath)) {
      throw new Error('File pubspec.yaml tidak ditemukan. Pastikan yang diupload adalah project Flutter.');
    }
    
    // Build Flutter
    const flutterCmd = `cd ${extractPath} && flutter clean && flutter pub get && flutter build apk --release`;
    console.log(`[BUILDER] Running: ${flutterCmd}`);
    
    const { stdout, stderr } = await execPromise(flutterCmd, { timeout: 10 * 60 * 1000 });
    
    if (stderr && !stderr.includes('Warning')) {
      console.log(`[BUILDER] stderr: ${stderr.substring(0, 500)}`);
    }
    
    // Cari APK hasil build
    const possiblePaths = [
      path.join(extractPath, 'build', 'app', 'outputs', 'flutter-apk', 'app-release.apk'),
      path.join(extractPath, 'build', 'app', 'outputs', 'apk', 'release', 'app-release.apk'),
      path.join(extractPath, 'build', 'app', 'outputs', 'apk', 'release', 'app.apk')
    ];
    
    let apkPath = null;
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        apkPath = p;
        break;
      }
    }
    
    if (!apkPath) throw new Error('APK tidak ditemukan setelah build');
    
    fs.copyFileSync(apkPath, apkOutputPath);
    
    const expiredAt = new Date();
    expiredAt.setHours(expiredAt.getHours() + BUILD_EXPIRY_HOURS);
    
    await updateFlutterBuild(build._id, {
      status: 'success',
      outputFile: apkOutputPath,
      completedAt: new Date(),
      expiredAt: expiredAt,
      message: 'Build berhasil!'
    });
    
    console.log(`[BUILDER] Build success: ${build._id}`);
    
    // Cleanup
    fs.rmSync(extractPath, { recursive: true, force: true });
    
  } catch (error) {
    console.error(`[BUILDER] Error: ${error.message}`);
    if (currentBuild && currentBuild._id) {
      await updateFlutterBuild(currentBuild._id, {
        status: 'failed',
        message: error.message,
        completedAt: new Date()
      });
    }
  } finally {
    isProcessing = false;
    currentBuild = null;
  }
}

// Jalankan worker setiap 5 detik
setInterval(() => {
  processBuildQueue();
}, 5000);

module.exports = { processBuildQueue };