const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const AdmZip = require('adm-zip');
const { getPendingBuilds, updateFlutterBuild } = require('./database');

const BUILDS_DIR = path.join(__dirname, '../../builds');
const BUILDS_TEMP_DIR = path.join(BUILDS_DIR, 'temp');
const BUILDS_RESULT_DIR = path.join(BUILDS_DIR, 'results');

let isProcessing = false;
let currentBuild = null;

async function processBuildQueue() {
  if (isProcessing) {
    console.log(`[BUILDER] Already processing, skip`);
    return;
  }
  
  try {
    const pendingBuilds = await getPendingBuilds();
    if (pendingBuilds.length === 0) return;
    
    const build = pendingBuilds[0];
    if (!build) return;
    
    console.log(`[BUILDER] Processing build: ${build._id}`);
    console.log(`[BUILDER] User: ${build.username}`);
    
    isProcessing = true;
    currentBuild = build;
    await updateFlutterBuild(build._id, { status: 'processing', startedAt: new Date() });
    
    const extractPath = path.join(BUILDS_TEMP_DIR, build._id);
    const apkOutputPath = path.join(BUILDS_RESULT_DIR, `${build._id}.apk`);
    
    // Buat folder temp
    if (!fs.existsSync(extractPath)) fs.mkdirSync(extractPath, { recursive: true });
    
    // Ekstrak ZIP
    console.log(`[BUILDER] Extracting ZIP...`);
    const zip = new AdmZip(build.originalFile);
    zip.extractAllTo(extractPath, true);
    
    // Cek pubspec.yaml
    if (!fs.existsSync(path.join(extractPath, 'pubspec.yaml'))) {
      throw new Error('pubspec.yaml tidak ditemukan di root ZIP');
    }
    
    // Set environment
    const env = {
      ...process.env,
      ANDROID_HOME: '/opt/android-sdk',
      ANDROID_SDK_ROOT: '/opt/android-sdk',
      JAVA_HOME: '/usr/lib/jvm/java-17-openjdk-amd64',
      PATH: '/opt/flutter/bin:/opt/android-sdk/platform-tools:/opt/android-sdk/cmdline-tools/latest/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    };
    
    // Build dengan single command (agar error terlihat)
    const buildScript = `
cd ${extractPath}
echo "=== FLUTTER CLEAN ==="
/opt/flutter/bin/flutter clean 2>&1
echo ""
echo "=== FLUTTER PUB GET ==="
/opt/flutter/bin/flutter pub get 2>&1
echo ""
echo "=== FLUTTER BUILD APK ==="
/opt/flutter/bin/flutter build apk --release 2>&1
echo ""
echo "=== DONE ==="
`;
    
    const scriptPath = path.join(extractPath, 'build.sh');
    fs.writeFileSync(scriptPath, buildScript);
    fs.chmodSync(scriptPath, '755');
    
    console.log(`[BUILDER] Running build script...`);
    
    const { stdout, stderr } = await execPromise(`bash ${scriptPath}`, { 
      timeout: 30 * 60 * 1000,
      env: env,
      maxBuffer: 50 * 1024 * 1024  // 50MB buffer
    });
    
    // Log output untuk debugging
    console.log(`[BUILDER] Build output (first 1000 chars):`);
    console.log(stdout.substring(0, 1000));
    
    // Cari APK
    let apkPath = null;
    const possiblePaths = [
      path.join(extractPath, 'build', 'app', 'outputs', 'flutter-apk', 'app-release.apk'),
      path.join(extractPath, 'build', 'app', 'outputs', 'apk', 'release', 'app-release.apk'),
      path.join(extractPath, 'build', 'app', 'outputs', 'apk', 'release', 'app.apk')
    ];
    
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        apkPath = p;
        break;
      }
    }
    
    if (!apkPath) {
      // Cari file .apk dengan find
      const findCmd = `find ${extractPath} -name "*.apk" 2>/dev/null`;
      const { stdout: findOut } = await execPromise(findCmd);
      const apkFiles = findOut.trim().split('\n').filter(f => f);
      if (apkFiles.length > 0) {
        apkPath = apkFiles[0];
        console.log(`[BUILDER] Found APK via find: ${apkPath}`);
      }
    }
    
    if (!apkPath) {
      // Log untuk debugging
      console.log(`[BUILDER] Build folder contents:`);
      const lsCmd = `ls -la ${extractPath}/build/app/outputs/ 2>/dev/null || echo "No outputs folder"`;
      const { stdout: lsOut } = await execPromise(lsCmd);
      console.log(lsOut);
      throw new Error('APK tidak ditemukan setelah build');
    }
    
    fs.copyFileSync(apkPath, apkOutputPath);
    
    const expiredAt = new Date();
    expiredAt.setHours(expiredAt.getHours() + 1);
    
    await updateFlutterBuild(build._id, {
      status: 'success',
      outputFile: apkOutputPath,
      completedAt: new Date(),
      expiredAt: expiredAt,
      message: 'Build berhasil!'
    });
    
    console.log(`[BUILDER] Build SUCCESS: ${build._id}`);
    
    // Cleanup
    fs.rmSync(extractPath, { recursive: true, force: true });
    
  } catch (error) {
    console.error(`[BUILDER] Build FAILED: ${error.message}`);
    
    // Kirim error message yang lebih jelas
    let errorMessage = error.message;
    if (error.stdout) {
      // Cari error yang berarti
      const match = error.stdout.match(/Error: (.*?)(?:\n|$)/);
      if (match) errorMessage = match[1];
    }
    
    if (currentBuild && currentBuild._id) {
      await updateFlutterBuild(currentBuild._id, {
        status: 'failed',
        message: errorMessage,
        completedAt: new Date()
      });
    }
  } finally {
    isProcessing = false;
    currentBuild = null;
  }
}

setInterval(processBuildQueue, 10000);

module.exports = { processBuildQueue };
