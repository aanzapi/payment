const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '../../data');
const BUILDS_FILE = path.join(DATA_DIR, 'flutter_builds.json');

// Pastikan file ada
if (!fs.existsSync(BUILDS_FILE)) {
  fs.writeFileSync(BUILDS_FILE, JSON.stringify([], null, 2));
}

async function readBuilds() {
  try {
    const data = await fsPromises.readFile(BUILDS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

async function writeBuilds(builds) {
  try {
    await fsPromises.writeFile(BUILDS_FILE, JSON.stringify(builds, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

async function getFlutterBuilds(userId = null) {
  const builds = await readBuilds();
  if (userId) {
    return builds.filter(b => b.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
  return builds.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function saveFlutterBuild(buildData) {
  const builds = await readBuilds();
  builds.push(buildData);
  await writeBuilds(builds);
  return buildData;
}

async function updateFlutterBuild(buildId, updateData) {
  const builds = await readBuilds();
  const index = builds.findIndex(b => b._id === buildId);
  if (index !== -1) {
    Object.assign(builds[index], updateData);
    await writeBuilds(builds);
    return true;
  }
  return false;
}

async function getPendingBuilds() {
  const builds = await readBuilds();
  return builds.filter(b => b.status === 'pending').sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
}

async function cleanupExpiredBuilds() {
  const builds = await readBuilds();
  let updated = false;
  for (const build of builds) {
    if (build.expiredAt && new Date(build.expiredAt) < new Date() && build.status === 'success') {
      if (build.outputFile && fs.existsSync(build.outputFile)) fs.unlinkSync(build.outputFile);
      if (build.originalFile && fs.existsSync(build.originalFile)) fs.unlinkSync(build.originalFile);
      build.status = 'expired';
      await updateFlutterBuild(build._id, { status: 'expired' });
      updated = true;
    }
  }
  return updated;
}

function generateBuildId() {
  const timestamp = Date.now().toString(36);
  const random = crypto.randomBytes(4).toString('hex');
  return `BLD${timestamp}${random}`.toUpperCase();
}

module.exports = {
  getFlutterBuilds,
  saveFlutterBuild,
  updateFlutterBuild,
  getPendingBuilds,
  cleanupExpiredBuilds,
  generateBuildId
};