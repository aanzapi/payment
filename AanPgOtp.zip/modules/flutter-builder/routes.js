const path = require('path');
const fs = require('fs');
const multer = require('multer');
const crypto = require('crypto');
const { getFlutterBuilds, saveFlutterBuild, updateFlutterBuild, generateBuildId } = require('./database');
const { processBuildQueue } = require('./worker');

const BUILDS_DIR = path.join(__dirname, '../../builds');
const BUILDS_UPLOAD_DIR = path.join(BUILDS_DIR, 'uploads');
const BUILD_COST_LIMIT = 5;
const LIMIT_PACKAGES = [
  { limit: 5, price: 1000, pricePerLimit: 200 },
  { limit: 10, price: 1800, pricePerLimit: 180, discount: '10%' },
  { limit: 25, price: 4000, pricePerLimit: 160, discount: '20%' },
  { limit: 50, price: 7500, pricePerLimit: 150, discount: '25%' },
  { limit: 100, price: 14000, pricePerLimit: 140, discount: '30%' }
];

// Konfigurasi upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, BUILDS_UPLOAD_DIR),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '.zip');
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
      cb(null, true);
    } else {
      cb(new Error('Hanya file ZIP yang diperbolehkan'));
    }
  }
});

function generateCustomId(prefix) {
  const randomHex = crypto.randomBytes(4).toString('hex');
  return prefix + randomHex.toUpperCase();
}

function generateTransactionId() {
  return 'TRX' + Date.now().toString(36).toUpperCase() + crypto.randomBytes(4).toString('hex').toUpperCase();
}

async function registerFlutterRoutes(app, dbHelpers) {
  const { findById, updateById, createWithRetry, readDB, sendAdminNotification } = dbHelpers;

  // Halaman utama Flutter Builder
  app.get('/flutter-build', async (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    const user = await findById('users', req.session.userId);
    const builds = await getFlutterBuilds(req.session.userId);
    res.render('flutter_build', {
      builds: builds.slice(0, 20),
      user: user || { flutterLimit: 0 },
      buildCost: BUILD_COST_LIMIT,
      packages: LIMIT_PACKAGES
    });
  });

  // Halaman beli limit
  app.get('/flutter-buy-limit', async (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    const user = await findById('users', req.session.userId);
    res.render('flutter_buy_limit', {
      packages: LIMIT_PACKAGES,
      user: user || { balance: 0, flutterLimit: 0 }
    });
  });

  // Proses beli limit
  app.post('/flutter-buy-limit', async (req, res) => {
    try {
      if (!req.session.userId) return res.redirect('/login');
      const { limit, price } = req.body;
      const user = await findById('users', req.session.userId);
      const totalPrice = parseInt(price);
      const limitAmount = parseInt(limit);
      
      if (user.balance < totalPrice) {
        req.session.errorMsg = `Saldo tidak cukup! Harga: Rp ${totalPrice.toLocaleString()}`;
        return res.redirect('/flutter-buy-limit');
      }
      
      user.balance -= totalPrice;
      user.flutterLimit = (user.flutterLimit || 0) + limitAmount;
      await updateById('users', user._id, { $set: { balance: user.balance, flutterLimit: user.flutterLimit } });
      
      await createWithRetry('transactions', {
        _id: generateTransactionId(),
        userId: user._id,
        type: 'deposit',
        amount: totalPrice,
        fee: 0,
        status: 'paid',
        reference: `FLUTTER_LIMIT_${limitAmount}`,
        createdAt: new Date()
      });
      
      req.session.successMsg = `Berhasil membeli ${limitAmount} limit Flutter! Sisa limit: ${user.flutterLimit}`;
      res.redirect('/flutter-build');
    } catch (error) {
      console.error('Error buying limit:', error);
      req.session.errorMsg = 'Gagal membeli limit';
      res.redirect('/flutter-buy-limit');
    }
  });

  // Upload dan mulai build
  app.post('/flutter-build/upload', upload.single('sourceCode'), async (req, res) => {
    try {
      if (!req.session.userId) return res.redirect('/login');
      const { flutterVersion, buildType } = req.body;
      const user = await findById('users', req.session.userId);
      
      if ((user.flutterLimit || 0) < BUILD_COST_LIMIT) {
        req.session.errorMsg = `Limit tidak cukup! Butuh ${BUILD_COST_LIMIT} limit. Silakan beli limit terlebih dahulu.`;
        return res.redirect('/flutter-buy-limit');
      }
      
      if (!req.file) {
        req.session.errorMsg = 'Silakan upload file ZIP source code Flutter';
        return res.redirect('/flutter-build');
      }
      
      if (!req.file.originalname.endsWith('.zip')) {
        fs.unlinkSync(req.file.path);
        req.session.errorMsg = 'File harus berekstensi .zip';
        return res.redirect('/flutter-build');
      }
      
      user.flutterLimit -= BUILD_COST_LIMIT;
      await updateById('users', user._id, { $set: { flutterLimit: user.flutterLimit } });
      
      const newBuild = {
        _id: generateBuildId(),
        userId: user._id,
        username: user.username,
        flutterVersion: flutterVersion || 'stable',
        buildType: buildType || 'release',
        originalFile: req.file.path,
        outputFile: null,
        status: 'pending',
        message: 'Menunggu antrian build...',
        createdAt: new Date(),
        expiredAt: null,
        completedAt: null,
        limitUsed: BUILD_COST_LIMIT
      };
      
      await saveFlutterBuild(newBuild);
      
      if (sendAdminNotification) {
        await sendAdminNotification('new_flutter_build', {
          username: user.username,
          buildId: newBuild._id
        });
      }
      
      req.session.successMsg = `Build ditambahkan ke antrian! Sisa limit: ${user.flutterLimit}`;
      res.redirect('/flutter-build');
    } catch (error) {
      console.error('[ERROR] Upload build:', error);
      req.session.errorMsg = 'Gagal memproses upload';
      res.redirect('/flutter-build');
    }
  });

  // Download APK
  app.get('/flutter-build/download/:id', async (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    const builds = await getFlutterBuilds();
    const build = builds.find(b => b._id === req.params.id);
    
    if (!build || build.userId !== req.session.userId) {
      req.session.errorMsg = 'Build tidak ditemukan';
      return res.redirect('/flutter-build');
    }
    
    if (build.status !== 'success') {
      req.session.errorMsg = 'Build belum selesai atau gagal';
      return res.redirect('/flutter-build');
    }
    
    if (new Date(build.expiredAt) < new Date()) {
      req.session.errorMsg = 'Link download sudah kadaluarsa (1 jam)';
      return res.redirect('/flutter-build');
    }
    
    if (!fs.existsSync(build.outputFile)) {
      req.session.errorMsg = 'File APK tidak ditemukan';
      return res.redirect('/flutter-build');
    }
    
    res.download(build.outputFile, `${build._id}.apk`);
  });

  // Cek status build (API)
  app.get('/flutter-build/status/:id', async (req, res) => {
    if (!req.session.userId) return res.json({ success: false });
    const builds = await getFlutterBuilds();
    const build = builds.find(b => b._id === req.params.id);
    if (!build || build.userId !== req.session.userId) {
      return res.json({ success: false, message: 'Build tidak ditemukan' });
    }
    res.json({
      success: true,
      status: build.status,
      message: build.message,
      expiredAt: build.expiredAt,
      outputFile: build.status === 'success' ? `/flutter-build/download/${build._id}` : null
    });
  });

  // Admin: Lihat semua build
  app.get('/admin/flutter-builds', async (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    const user = await findById('users', req.session.userId);
    if (user.role !== 'admin') return res.redirect('/dashboard');
    
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const status = req.query.status || 'all';
    const search = req.query.search || '';
    
    let builds = await getFlutterBuilds();
    const users = await readDB('users');
    
    builds = builds.map(build => {
      const userData = users.find(u => u._id === build.userId);
      return {
        ...build,
        username: userData?.username || 'Unknown',
        userEmail: userData?.email || '-'
      };
    });
    
    if (status !== 'all') {
      builds = builds.filter(b => b.status === status);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      builds = builds.filter(b => 
        b._id.toLowerCase().includes(searchLower) ||
        b.username.toLowerCase().includes(searchLower) ||
        b.userEmail.toLowerCase().includes(searchLower)
      );
    }
    
    const totalBuilds = builds.length;
    const pendingCount = builds.filter(b => b.status === 'pending').length;
    const processingCount = builds.filter(b => b.status === 'processing').length;
    const successCount = builds.filter(b => b.status === 'success').length;
    const failedCount = builds.filter(b => b.status === 'failed').length;
    const expiredCount = builds.filter(b => b.status === 'expired').length;
    
    const totalPages = Math.ceil(totalBuilds / limit);
    const startIndex = (page - 1) * limit;
    const paginatedBuilds = builds.slice(startIndex, startIndex + limit);
    
    res.render('admin_flutter_builds', {
      builds: paginatedBuilds,
      stats: { totalBuilds, pendingCount, processingCount, successCount, failedCount, expiredCount },
      currentPage: page,
      totalPages: totalPages,
      limit: limit,
      status: status,
      search: search,
      user: user
    });
  });
}

module.exports = { registerFlutterRoutes, LIMIT_PACKAGES, BUILD_COST_LIMIT };
