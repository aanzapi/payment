require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MemoryStore = require('memorystore')(session);
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const fs = require('fs');
const fsPromises = require('fs').promises;
const archiver = require('archiver');
const FormData = require('form-data');

const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;

// ===================== JSON DATABASE SETUP =====================
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILES = {
  users: 'users.json',
  invoices: 'invoices.json',
  transactions: 'transactions.json',
  withdrawals: 'withdrawals.json',
  apiKeys: 'apikeys.json',
  settings: 'settings.json',
  stats: 'stats.json'
};

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize all JSON files if they don't exist
for (const [key, filename] of Object.entries(DB_FILES)) {
  const filepath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filepath)) {
    fs.writeFileSync(filepath, JSON.stringify([], null, 2));
  }
}

// Helper functions for JSON database operations
async function readDB(collection) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    const data = await fsPromises.readFile(filepath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${collection}:`, error);
    return [];
  }
}

async function writeDB(collection, data) {
  try {
    const filepath = path.join(DATA_DIR, DB_FILES[collection]);
    await fsPromises.writeFile(filepath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error(`Error writing ${collection}:`, error);
    return false;
  }
}

async function findOne(collection, query) {
  const data = await readDB(collection);
  return data.find(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  });
}

async function find(collection, query = {}) {
  const data = await readDB(collection);
  if (Object.keys(query).length === 0) return data;
  return data.filter(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  });
}

async function findById(collection, id) {
  const data = await readDB(collection);
  return data.find(item => item._id === id);
}

async function insertOne(collection, document) {
  const data = await readDB(collection);
  data.push(document);
  await writeDB(collection, data);
  return document;
}

async function updateOne(collection, query, update, options = {}) {
  const data = await readDB(collection);
  let updated = false;
  for (let i = 0; i < data.length; i++) {
    let match = true;
    for (const [key, value] of Object.entries(query)) {
      if (data[i][key] !== value) {
        match = false;
        break;
      }
    }
    if (match) {
      if (update.$set) {
        Object.assign(data[i], update.$set);
      }
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      if (update.$push) {
        for (const [key, value] of Object.entries(update.$push)) {
          if (!data[i][key]) data[i][key] = [];
          data[i][key].push(value);
        }
      }
      updated = true;
      break;
    }
  }
  if (updated || options.upsert) {
    await writeDB(collection, data);
    return { modifiedCount: updated ? 1 : 0, upsertedId: !updated && options.upsert ? update._id : null };
  }
  return { modifiedCount: 0 };
}

async function updateById(collection, id, update) {
  const data = await readDB(collection);
  for (let i = 0; i < data.length; i++) {
    if (data[i]._id === id) {
      if (update.$set) {
        Object.assign(data[i], update.$set);
      }
      if (update.$inc) {
        for (const [key, value] of Object.entries(update.$inc)) {
          data[i][key] = (data[i][key] || 0) + value;
        }
      }
      await writeDB(collection, data);
      return true;
    }
  }
  return false;
}

async function deleteOne(collection, query) {
  const data = await readDB(collection);
  let deleted = false;
  for (let i = 0; i < data.length; i++) {
    let match = true;
    for (const [key, value] of Object.entries(query)) {
      if (data[i][key] !== value) {
        match = false;
        break;
      }
    }
    if (match) {
      data.splice(i, 1);
      deleted = true;
      break;
    }
  }
  if (deleted) {
    await writeDB(collection, data);
    return { deletedCount: 1 };
  }
  return { deletedCount: 0 };
}

async function deleteMany(collection, query) {
  const data = await readDB(collection);
  let deletedCount = 0;
  if (Object.keys(query).length === 0) {
    deletedCount = data.length;
    await writeDB(collection, []);
  } else {
    for (let i = data.length - 1; i >= 0; i--) {
      let match = true;
      for (const [key, value] of Object.entries(query)) {
        if (data[i][key] !== value) {
          match = false;
          break;
        }
      }
      if (match) {
        data.splice(i, 1);
        deletedCount++;
      }
    }
    await writeDB(collection, data);
  }
  return { deletedCount };
}

async function countDocuments(collection, query = {}) {
  const data = await readDB(collection);
  if (Object.keys(query).length === 0) return data.length;
  return data.filter(item => {
    for (const [key, value] of Object.entries(query)) {
      if (item[key] !== value) return false;
    }
    return true;
  }).length;
}

async function aggregate(collection, pipeline) {
  let data = await readDB(collection);
  for (const stage of pipeline) {
    if (stage.$match) {
      data = data.filter(item => {
        for (const [key, value] of Object.entries(stage.$match)) {
          if (typeof value === 'object' && value !== null) {
            if (value.$gte !== undefined && item[key] < value.$gte) return false;
            if (value.$lte !== undefined && item[key] > value.$lte) return false;
            if (value.$gt !== undefined && item[key] <= value.$gt) return false;
            if (value.$lt !== undefined && item[key] >= value.$lt) return false;
            if (value.$in !== undefined && !value.$in.includes(item[key])) return false;
          } else if (item[key] !== value) return false;
        }
        return true;
      });
    } else if (stage.$group) {
      const groups = {};
      for (const item of data) {
        let groupKey = '';
        for (const [key, value] of Object.entries(stage.$group._id)) {
          if (value === null) groupKey = '__null__';
          else groupKey = '__all__';
        }
        if (!groups[groupKey]) {
          groups[groupKey] = {};
          for (const [key, value] of Object.entries(stage.$group)) {
            if (key !== '_id') {
              groups[groupKey][key] = 0;
            }
          }
        }
        for (const [key, value] of Object.entries(stage.$group)) {
          if (key !== '_id') {
            if (value.$sum) {
              groups[groupKey][key] += item[value.$sum] || 0;
            }
          }
        }
      }
      data = Object.values(groups);
    } else if (stage.$sort) {
      const sortKey = Object.keys(stage.$sort)[0];
      const sortOrder = stage.$sort[sortKey];
      data.sort((a, b) => sortOrder === 1 ? (a[sortKey] || 0) - (b[sortKey] || 0) : (b[sortKey] || 0) - (a[sortKey] || 0));
    } else if (stage.$limit) {
      data = data.slice(0, stage.$limit);
    }
  }
  return data;
}

// ===================== CUSTOM ID PREFIX CONFIGURATION =====================
const startId = {
  apikey: 'AZX',
  invoice: 'INV',
  withdraw: 'WD',
  transaction: 'TRX'
};

// ===================== MIDDLEWARE DASAR =====================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  store: new MemoryStore({ checkPeriod: 86400000 }),
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ===================== SETUP LIMITER =====================
const Limiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 15,
  handler: (req, res) => {
    req.session.errorMsg = 'Terlalu banyak percobaan login. Silakan coba lagi setelah 5 menit.';
    res.redirect('/login');
  }
});

// ===================== CUSTOM ID GENERATOR =====================
function generateCustomId(prefix) {
  const len = 10 - prefix.length;
  const randomHex = crypto.randomBytes(Math.ceil(len / 2)).toString('hex').substring(0, len);
  return prefix + randomHex;
}

function generateApiKey() {
  return startId.apikey + '_' + crypto.randomUUID().replace(/-/g, '').substring(0, 16);
}

// ===================== ANTI-DUPLICATE HELPER =====================
async function createWithRetry(collection, data, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const existing = await findOne(collection, { _id: data._id });
      if (existing) {
        if (collection === 'invoices') data._id = generateCustomId(startId.invoice);
        else if (collection === 'transactions') data._id = generateCustomId(startId.transaction);
        else if (collection === 'withdrawals') data._id = generateCustomId(startId.withdraw);
        else if (collection === 'apiKeys') data.key = generateApiKey();
        continue;
      }
      return await insertOne(collection, data);
    } catch (err) {
      if (attempt < maxRetries - 1) continue;
      throw err;
    }
  }
  throw new Error('Gagal membuat dokumen setelah beberapa kali percobaan');
}

// ===================== HELPERS =====================
async function getSettings() {
  let settings = await findOne('settings', {});
  if (!settings) {
    settings = {
      _id: 'settings_1',
      name: 'Azx Gateway',
      title: 'Layanan Payment Gateway',
      description: 'Terima pembayaran melalui QRIS Payment untuk Aplikasi atau Platform Bisnis kamu dengan mudah, cepat, dan aman.',
      channelWhatsApp: 'https://whatsapp.com/channel/0029VbBZsRTL7UVe8r945707',
      apiDomain: 'skyserver.web.id',
      apiKey: 'skyy7',
      username: '',
      token: '',
      minDeposit: 1000,
      minWithdraw: 5000,
      feeWithdraw: 1000,
      maxFee: 500,
      checkInterval: 20,
      autoCheckEnabled: true,
      autoBackupEnabled: false,
      smtpUser: '',
      smtpPass: '',
      telegramBotToken: '',
      telegramAdminChatId: '',
      logoUrl: 'https://img2.pixhost.to/images/8187/731158188_skyzo.png'
    };
    await insertOne('settings', settings);
  }
  return settings;
}

async function getStats() {
  const transactions = await readDB('transactions');
  
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;

  await updateOne('stats', {}, {
    $set: {
      totalDepositAmount: dAmount,
      totalDepositFee: dFee,
      totalWithdrawAmount: wAmount,
      totalWithdrawFee: wFee,
      totalUsers,
      totalTransactions
    }
  }, { upsert: true });

  return { totalDepositAmount: dAmount, totalDepositFee: dFee, totalWithdrawAmount: wAmount, totalWithdrawFee: wFee, totalUsers, totalTransactions };
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function verifyPassword(password, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex') === hash;
}

// ===================== BACKUP FUNCTIONS =====================
async function createBackupZip() {
  return new Promise(async (resolve, reject) => {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `backup_${timestamp}.zip`;
      const zipFilePath = path.join(__dirname, zipFileName);
      
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', () => {
        console.log(`✅ Backup berhasil: ${zipFileName} (${archive.pointer()} bytes)`);
        resolve({ path: zipFilePath, name: zipFileName, size: archive.pointer() });
      });
      
      archive.on('error', (err) => {
        reject(err);
      });
      
      archive.pipe(output);
      
      if (fs.existsSync(DATA_DIR)) {
        archive.directory(DATA_DIR, 'data');
      } else {
        reject(new Error('Folder data tidak ditemukan'));
      }
      
      await archive.finalize();
    } catch (error) {
      reject(error);
    }
  });
}

async function sendBackupToTelegram(zipPath, zipName) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  const adminChatId = settings.telegramAdminChatId;
  
  if (!token || !adminChatId) {
    console.log('⚠️ Telegram belum dikonfigurasi, backup hanya disimpan lokal');
    return false;
  }
  
  try {
    const stats = fs.statSync(zipPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    
    if (stats.size > 50 * 1024 * 1024) {
      console.log('⚠️ File backup terlalu besar (>50MB), tidak bisa dikirim ke Telegram');
      return false;
    }
    
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
      chat_id: adminChatId,
      text: `📦 *Backup Database*\n\n📁 Nama: ${zipName}\n📊 Ukuran: ${fileSizeMB} MB\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\n🔄 Sedang mengirim file backup...`,
      parse_mode: 'Markdown'
    });
    
    const formData = new FormData();
    formData.append('chat_id', adminChatId);
    formData.append('document', fs.createReadStream(zipPath));
    formData.append('caption', `🗄️ Backup Database - ${new Date().toLocaleDateString('id-ID')}\n\n⚠️ Simpan file ini dengan aman!`);
    
    await axios.post(`https://api.telegram.org/bot${token}/sendDocument`, formData, {
      headers: { ...formData.getHeaders() }
    });
    
    console.log(`✅ Backup terkirim ke Telegram: ${zipName}`);
    return true;
  } catch (error) {
    console.error('❌ Gagal kirim backup ke Telegram:', error.message);
    return false;
  }
}

async function performBackupAndSend() {
  try {
    console.log('🔄 Memulai proses backup...');
    const { path: zipPath, name: zipName, size } = await createBackupZip();
    
    const sent = await sendBackupToTelegram(zipPath, zipName);
    
    setTimeout(() => {
      fs.unlink(zipPath, (err) => {
        if (err) console.error('Gagal hapus file zip:', err);
        else console.log(`🗑️ File zip dihapus: ${zipName}`);
      });
    }, 5000);
    
    return { success: true, fileName: zipName, size, sentToTelegram: sent };
  } catch (error) {
    console.error('❌ Backup gagal:', error);
    return { success: false, error: error.message };
  }
}

// ===================== TELEGRAM BOT FUNCTIONS =====================
let pollingTimeout = null;
let isPollingActive = false;

async function getAdminChatId() {
  const settings = await getSettings();
  return settings.telegramAdminChatId || null;
}

async function sendTelegramMessage(chatId, text, replyMarkup) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token || !chatId) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: 'Markdown',
      reply_markup: replyMarkup
    });
  } catch (e) {
    console.error('Telegram sendMessage error:', e.response?.data || e.message);
  }
}

async function deleteMessage(chatId, messageId) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/deleteMessage`, {
      chat_id: chatId,
      message_id: messageId
    });
  } catch (e) {
    console.error('Telegram deleteMessage error:', e.response?.data || e.message);
  }
}

async function answerCallbackQuery(callbackQueryId, text) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return;
  try {
    await axios.post(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
      callback_query_id: callbackQueryId,
      text,
      show_alert: false
    });
  } catch (e) {}
}

const REJECT_REASONS = {
  1: 'Rekening Tidak Valid',
  2: 'Ewallet Tidak Valid',
  3: 'System Maintenance'
};

async function handleCallbackQuery(cb) {
  const data = cb.data;
  if (!data) return;

  const parts = data.split(':');
  const action = parts[0];
  const id = parts[1];
  if (!id) return;

  const wd = await findById('withdrawals', id);
  const settings = await getSettings();
  if (!wd) {
    await answerCallbackQuery(cb.id, 'Withdrawal tidak ditemukan.');
    return;
  }
  if (wd.status !== 'pending') {
    await answerCallbackQuery(cb.id, 'Withdrawal sudah diproses.');
    return;
  }

  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const user = await findById('users', wd.userId);
  if (!user) {
    await answerCallbackQuery(cb.id, 'User tidak ditemukan.');
    return;
  }

  const timeString = new Date(wd.createdAt).toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).replace(/, /, ' pukul ');

  const userInfoText = (u) =>
    `👤 *Informasi User*\n` +
    `• *User:* ${u.username} (${u.email})\n` +
    `• *Saldo Saat Ini:* Rp ${u.balance.toLocaleString()}\n` +
    `• *E-Wallet:* ${u.ewallet}\n` +
    `• *No. Rek:* \`${u.accountNumber}\`\n` +
    `• *Nama Rek:* ${u.accountName}\n\n`;

  const withdrawInfoText = () =>
    `📤 *Informasi Withdraw*\n` +
    `• *Jumlah:* Rp ${wd.amount.toLocaleString()}\n` +
    `• *Biaya:* Rp ${wd.fee.toLocaleString()}\n` +
    `• *Total Tarik:* Rp ${(wd.amount + wd.fee).toLocaleString()}\n` +
    `• *ID Withdraw:* ${wd._id}\n` +
    `• *Waktu:* ${timeString}\n`;

  const header = `🌐 *Notifikasi - ${settings.name}*\n\n`;

  if (action === 'approve_wd') {
    wd.status = 'success';
    await updateById('withdrawals', wd._id, { $set: wd });
    
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'success';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    
    await updateOne('stats', {}, { $inc: { totalWithdrawAmount: wd.amount, totalWithdrawFee: wd.fee } });
    await deleteMessage(chatId, messageId);
    await sendTelegramMessage(
      chatId,
      header + userInfoText(user) + withdrawInfoText() + `• *Status:* ✅ Berhasil`
    );
    await answerCallbackQuery(cb.id, 'Withdrawal disetujui.');
  } else if (action === 'reason_wd') {
    const reasonsKeyboard = {
      inline_keyboard: [
        [{ text: '1️⃣ Rekening Tidak Valid', callback_data: `reject_wd:${wd._id}:1` }],
        [{ text: '2️⃣ Ewallet Tidak Valid', callback_data: `reject_wd:${wd._id}:2` }],
        [{ text: '3️⃣ System Maintenance', callback_data: `reject_wd:${wd._id}:3` }],
        [{ text: '🔙 Batal', callback_data: `cancel_wd:${wd._id}` }]
      ]
    };
    try {
      await axios.post(`https://api.telegram.org/bot${settings.telegramBotToken}/editMessageText`, {
        chat_id: chatId,
        message_id: messageId,
        text: header + userInfoText(user) + withdrawInfoText() + `\n*Pilih alasan penolakan:*`,
        parse_mode: 'Markdown',
        reply_markup: reasonsKeyboard
      });
    } catch (e) {}
    await answerCallbackQuery(cb.id, 'Pilih alasan penolakan:');
  } else if (action === 'reject_wd') {
    const reasonId = parts[2];
    const reasonText = REJECT_REASONS[reasonId] || 'Ditolak via bot';
    wd.status = 'rejected';
    wd.adminNote = reasonText;
    await updateById('withdrawals', wd._id, { $set: wd });
    
    const updatedUser = await findById('users', wd.userId);
    updatedUser.balance = (updatedUser.balance || 0) + wd.amount + wd.fee;
    await updateById('users', wd.userId, { $set: updatedUser });
    
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'rejected';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    
    await deleteMessage(chatId, messageId);
    await sendTelegramMessage(
      chatId,
      header + userInfoText(updatedUser) + withdrawInfoText() +
      `• *Status:* ❌ Ditolak\n📝 Alasan: ${reasonText}\n♻️ Saldo sudah dikembalikan.`
    );
    await answerCallbackQuery(cb.id, 'Withdrawal ditolak, saldo dikembalikan.');
  } else if (action === 'cancel_wd') {
    const origKeyboard = {
      inline_keyboard: [
        [
          { text: '✅ Setujui', callback_data: `approve_wd:${wd._id}` },
          { text: '❌ Tolak', callback_data: `reason_wd:${wd._id}` }
        ]
      ]
    };
    try {
      await axios.post(`https://api.telegram.org/bot${settings.telegramBotToken}/editMessageText`, {
        chat_id: chatId,
        message_id: messageId,
        text: header + userInfoText(user) + withdrawInfoText(),
        parse_mode: 'Markdown',
        reply_markup: origKeyboard
      });
    } catch (e) {}
    await answerCallbackQuery(cb.id, 'Dibatalkan.');
  }
}

async function handleTelegramUpdate(update) {
  const settings = await getSettings();
  const adminChatId = settings.telegramAdminChatId;
  if (!adminChatId) return;
  if (update.callback_query) {
    const cb = update.callback_query;
    if (cb.message && cb.message.chat && String(cb.message.chat.id) === String(adminChatId)) {
      await handleCallbackQuery(cb);
    }
  } else if (update.message && update.message.text) {
    const msg = update.message;
    if (String(msg.chat.id) === String(adminChatId)) {
      if (msg.text === '/start') {
        sendTelegramMessage(adminChatId, `Chat ID kamu: ${msg.chat.id}\nUsername: @${msg.chat.username || 'tidak disetel'}\nBot sudah terhubung.`);
      }
    }
  }
}

async function telegramGetUpdates(offset) {
  const settings = await getSettings();
  const token = settings.telegramBotToken;
  if (!token) return [];
  try {
    const res = await axios.get(`https://api.telegram.org/bot${token}/getUpdates`, {
      params: { offset, timeout: 15 },
      timeout: 20000
    });
    if (res.data.ok) return res.data.result;
    else {
      console.error('Telegram getUpdates tidak ok:', res.data);
      return [];
    }
  } catch (e) {
    if (e.response && e.response.status === 409) {
      console.error('Error 409 Conflict terdeteksi, menghentikan polling.');
      stopTelegramPolling();
    } else {
      console.error('Telegram getUpdates error:', e.message);
    }
    return [];
  }
}

function stopTelegramPolling() {
  if (pollingTimeout) {
    clearTimeout(pollingTimeout);
    pollingTimeout = null;
  }
  isPollingActive = false;
}

async function ensureNoWebhook(token) {
  try {
    const infoRes = await axios.get(`https://api.telegram.org/bot${token}/getWebhookInfo`);
    if (infoRes.data.ok && infoRes.data.result.url) {
      console.log('Webhook terdeteksi, menghapus...');
      await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook`);
      console.log('Webhook dihapus.');
    } else {
      console.log('Tidak ada webhook.');
    }
    return true;
  } catch (e) {
    console.error('Gagal menghapus webhook:', e.message);
    return false;
  }
}

async function startTelegramPolling() {
  stopTelegramPolling();
  const settings = await getSettings();
  if (!settings.telegramBotToken) {
    return;
  }
  if (isPollingActive) {
    console.log('Polling sudah berjalan.');
    return;
  }
  const ok = await ensureNoWebhook(settings.telegramBotToken);
  if (!ok) {
    console.log('Tidak dapat memastikan webhook, polling tidak dimulai.');
    return;
  }
  isPollingActive = true;
  console.log('Polling Telegram dimulai.');
  let offset = 0;
  async function poll() {
    if (!isPollingActive) return;
    const updates = await telegramGetUpdates(offset);
    for (const update of updates) {
      offset = update.update_id + 1;
      await handleTelegramUpdate(update);
    }
    pollingTimeout = setTimeout(poll, 1000);
  }
  poll();
}

// ===================== GLOBAL MIDDLEWARE =====================
app.use(async (req, res, next) => {
  res.locals.user = null;
  if (req.session.userId) {
    try {
      res.locals.user = await findById('users', req.session.userId);
    } catch {}
  }
  res.locals.settings = await getSettings();
  res.locals.error = req.session.errorMsg || null;
  res.locals.success = req.session.successMsg || null;
  delete req.session.errorMsg;
  delete req.session.successMsg;
  next();
});

function isAuth(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}

function isAdmin(req, res, next) {
  if (req.session.userRole === 'admin') return next();
  res.redirect('/login');
}

// ===================== SEED ADMIN =====================
async function seed() {
  const admin = await findOne('users', { role: 'admin' });
  if (!admin) {
    await insertOne('users', {
      _id: crypto.randomBytes(12).toString('hex'),
      username: 'admin',
      email: 'admin@gmail.com',
      password: hashPassword('admin123'),
      role: 'admin',
      balance: 0,
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    });
    console.log(`🔑 Admin Account Default\nUsername: admin\nPassword: admin123`);
  }
}

// ===================== ROUTES DASHBOARD / AUTH =====================
app.get('/', (req, res) => res.render('home'));
app.get('/home', (req, res) => res.render('home'));
app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('login');
});
app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('register');
});

app.post('/login', Limiter, async (req, res) => {
  const { login, password } = req.body;
  if (!login || !password) {
    req.session.errorMsg = 'Harap isi semua field';
    return res.redirect('/login');
  }
  const isEmail = login.includes('@');
  let user;
  if (isEmail) {
    user = await findOne('users', { email: login.toLowerCase() });
    if (user && user.role === 'admin') {
      req.session.errorMsg = 'Admin hanya dapat login menggunakan username';
      return res.redirect('/login');
    }
  } else {
    user = await findOne('users', { username: login.toLowerCase() });
  }
  if (!user || !verifyPassword(password, user.password)) {
    req.session.errorMsg = 'Username/email atau kata sandi salah';
    return res.redirect('/login');
  }
  if (user.suspended) {
    req.session.errorMsg = 'Akun Anda dinonaktifkan';
    return res.redirect('/login');
  }
  req.session.userId = user._id;
  req.session.userRole = user.role;
  if (user.role === 'admin') return res.redirect('/admin/dashboard');
  res.redirect('/dashboard');
});

app.post('/register', Limiter, async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || username.trim().length === 0) {
    req.session.errorMsg = 'Username tidak boleh kosong';
    return res.redirect('/register');
  }
  if (!/^[a-zA-Z0-9]+$/.test(username)) {
    req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
    return res.redirect('/register');
  }
  if (username.length > 15) {
    req.session.errorMsg = 'Username maksimal 15 karakter';
    return res.redirect('/register');
  }
  try {
    const existingUser = await findOne('users', { $or: [{ username: username.toLowerCase() }, { email: email.toLowerCase() }] });
    if (existingUser) {
      req.session.errorMsg = 'Username atau email sudah terdaftar';
      return res.redirect('/register');
    }
    
    const user = {
      _id: crypto.randomBytes(12).toString('hex'),
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      password: hashPassword(password),
      balance: 0,
      role: 'user',
      suspended: false,
      ewallet: '',
      accountNumber: '',
      accountName: '',
      createdAt: new Date()
    };
    await insertOne('users', user);
    await createWithRetry('apiKeys', { userId: user._id, key: generateApiKey(), createdAt: new Date() });
    req.session.userId = user._id;
    req.session.userRole = 'user';
    res.redirect('/dashboard');
  } catch (err) {
    req.session.errorMsg = 'Gagal mendaftar, periksa kembali data Anda';
    res.redirect('/register');
  }
});

// ===================== CEK KETERSEDIAAN USERNAME / EMAIL =====================
app.post('/check-availability', async (req, res) => {
  const { type, value } = req.body;
  if (!type || !value || !['username', 'email'].includes(type)) {
    return res.json({ available: false, message: 'Parameter tidak valid' });
  }

  if (type === 'username') {
    if (!/^[a-zA-Z0-9]{1,15}$/.test(value)) {
      return res.json({ available: false, message: 'Format username tidak valid (huruf/angka, maks 15 karakter)' });
    }
    const exists = await findOne('users', { username: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Username sudah digunakan' : 'Username tersedia' });
  }

  if (type === 'email') {
    if (!/^\S+@\S+\.\S+$/.test(value)) {
      return res.json({ available: false, message: 'Format email tidak valid' });
    }
    const exists = await findOne('users', { email: value.toLowerCase() });
    return res.json({ available: !exists, message: exists ? 'Email sudah terdaftar' : 'Email tersedia' });
  }
});

// ===================== LUPA PASSWORD =====================
app.get('/forgot-password', (req, res) => {
  if (req.session.userId) return res.redirect(req.session.userRole === 'admin' ? '/admin/dashboard' : '/dashboard');
  res.render('forgot_password');
});

app.post('/forgot-password', Limiter, async (req, res) => {
  const { login } = req.body;
  if (!login) {
    req.session.errorMsg = 'Harap masukkan email atau username Anda.';
    return res.redirect('/forgot-password');
  }
  try {
    const settings = await getSettings();
    if (!settings.smtpUser || !settings.smtpPass) {
      req.session.errorMsg = 'Fitur pengiriman email belum dikonfigurasi oleh Administrator.';
      return res.redirect('/forgot-password');
    }
    const isEmail = login.includes('@');
    let user;
    if (isEmail) {
      user = await findOne('users', { email: login.toLowerCase() });
    } else {
      user = await findOne('users', { username: login.toLowerCase() });
    }
    if (!user) {
      req.session.errorMsg = 'Akun tidak ditemukan di sistem kami.';
      return res.redirect('/forgot-password');
    }
    if (!user.email) {
      req.session.errorMsg = 'Akun ini tidak memiliki alamat email yang valid.';
      return res.redirect('/forgot-password');
    }
    const token = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 30 * 60 * 1000;
    await updateById('users', user._id, { $set: user });

    const resetLink = `http://${req.headers.host}/reset-password/${token}`;
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: settings.smtpUser,
        pass: settings.smtpPass
      },
      tls: { rejectUnauthorized: false },
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 10000
    });

    await transporter.sendMail({
      to: user.email,
      from: `"${settings.name}" <${settings.smtpUser}>`,
      subject: `Permintaan Reset Password - ${settings.name}`,
      text: `Halo ${user.username},\n\nKami menerima permintaan untuk mengatur ulang kata sandi akun Anda. Silakan salin tautan berikut ke browser Anda:\n${resetLink}\n\nTautan ini hanya berlaku 30 menit.\n\nJika Anda tidak meminta ini, abaikan email ini.`,
      html: `
        <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #f9fafb; padding: 40px 20px; margin: 0;">
          <div style="max-width: 500px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; border: 1px solid #f3f4f6; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
            <div style="height: 6px; background-color: #111827; width: 100%;"></div>
            <div style="padding: 40px;">
              <h2 style="color: #111827; font-size: 18px; font-weight: 600; margin-top: 0; margin-bottom: 16px; text-align: center;">
                Reset Password - ${settings.name}
              </h2>
              <p style="color: #4b5563; font-size: 15px; line-height: 1.6; margin-bottom: 24px;">
                Halo <strong style="color: #111827;">${user.username}</strong>,<br><br>
                Kami menerima permintaan untuk mengatur ulang kata sandi akun Anda di <strong>${settings.name}</strong>. Jika ini memang Anda, silakan klik tombol di bawah ini:
              </p>
              <div style="text-align: center; margin-bottom: 30px;">
                <a href="${resetLink}" style="display: inline-block; background-color: #111827; color: #ffffff; text-decoration: none; padding: 14px 28px; border-radius: 8px; font-weight: 600; font-size: 15px;">
                  Ganti Password Saya
                </a>
              </div>
              <p style="color: #dc2626; font-size: 13px; font-weight: 600; text-align: center; margin-bottom: 30px; background-color: #fef2f2; padding: 10px; border-radius: 8px;">
                Tautan ini hanya berlaku selama 30 menit.
              </p>
              <div style="border-top: 1px solid #e5e7eb; padding-top: 24px;">
                <p style="color: #6b7280; font-size: 13px; line-height: 1.5; margin: 0;">
                  Jika tombol di atas tidak berfungsi, salin dan tempel URL berikut ke browser Anda:<br>
                  <a href="${resetLink}" style="color: #2563eb; word-break: break-all;">${resetLink}</a>
                </p>
              </div>
            </div>
          </div>
          <div style="text-align: center; max-width: 500px; margin: 24px auto 0;">
            <p style="color: #9ca3af; font-size: 12px; line-height: 1.5; margin-bottom: 10px;">
              Jika Anda tidak merasa membuat permintaan ini, abaikan email ini dengan aman. Kata sandi Anda tidak akan berubah.
            </p>
            <p style="color: #d1d5db; font-size: 12px;">
              &copy; ${new Date().getFullYear()} ${settings.name}. All rights reserved.
            </p>
          </div>
        </div>
      `
    });

    req.session.successMsg = `Link reset password telah dikirim ke email Anda yang terdaftar.`;
    res.redirect('/forgot-password');
  } catch (error) {
    console.error('Error Forgot Password:', error);
    req.session.errorMsg = 'Gagal memproses email. Pastikan konfigurasi SMTP di Admin valid.';
    res.redirect('/forgot-password');
  }
});

app.get('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const user = users.find(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (!user) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa (berlaku 30 menit).';
      return res.redirect('/forgot-password');
    }
    res.render('reset_password', { token: req.params.token });
  } catch (error) {
    res.redirect('/login');
  }
});

app.post('/reset-password/:token', async (req, res) => {
  try {
    const users = await readDB('users');
    const userIndex = users.findIndex(u => u.resetPasswordToken === req.params.token && u.resetPasswordExpires > Date.now());
    if (userIndex === -1) {
      req.session.errorMsg = 'Token reset password tidak valid atau sudah kedaluwarsa.';
      return res.redirect('/forgot-password');
    }
    const { password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      req.session.errorMsg = 'Password dan konfirmasi password tidak cocok.';
      return res.redirect(`/reset-password/${req.params.token}`);
    }
    users[userIndex].password = hashPassword(password);
    delete users[userIndex].resetPasswordToken;
    delete users[userIndex].resetPasswordExpires;
    await writeDB('users', users);
    req.session.successMsg = 'Password berhasil diubah. Silakan login dengan password baru.';
    res.redirect('/login');
  } catch (error) {
    req.session.errorMsg = 'Gagal mereset password.';
    res.redirect(`/reset-password/${req.params.token}`);
  }
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/login'); });

// --- Dashboard User ---
app.get('/dashboard', isAuth, async (req, res) => {
  if (req.session.userRole === 'admin') return res.redirect('/admin/dashboard');
  const userId = req.session.userId;
  const user = res.locals.user;
  
  const transactions = await readDB('transactions');
  const userTransactions = transactions.filter(t => t.userId === user._id);
  const totalDeposit = userTransactions.filter(t => t.type === 'deposit' && t.status === 'paid').reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalWithdraw = userTransactions.filter(t => t.type === 'withdraw' && t.status === 'success').reduce((sum, t) => sum + (t.amount || 0), 0);
  const recentTrx = userTransactions.filter(t => t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  const apiKeys = await find('apiKeys', { userId });
  
  res.render('dashboard', { user, totalDeposit, totalWithdraw, recentTrx, apiKeys });
});

// --- Profile ---
app.get('/profile', isAuth, (req, res) => res.render('profile'));
app.post('/profile', isAuth, async (req, res) => {
  const { email, newPassword, ewallet, accountNumber, accountName } = req.body;
  try {
    const user = await findById('users', req.session.userId);
    if (email && email !== user.email) {
      const existing = await findOne('users', { email: email.toLowerCase() });
      if (existing && existing._id !== req.session.userId) {
        req.session.errorMsg = 'Email sudah digunakan oleh pengguna lain';
        return res.redirect('/profile');
      }
      user.email = email.toLowerCase();
    }
    user.ewallet = ewallet || '';
    user.accountNumber = accountNumber || '';
    user.accountName = accountName || '';
    if (newPassword && newPassword.trim()) {
      user.password = hashPassword(newPassword);
    }
    await updateById('users', req.session.userId, { $set: user });
    req.session.successMsg = 'Profil berhasil diperbarui';
    res.redirect('/profile');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui profil';
    res.redirect('/profile');
  }
});

app.post('/api/user/api-key/regenerate', isAuth, async (req, res) => {
  await deleteMany('apiKeys', { userId: req.session.userId });
  const key = generateApiKey();
  try {
    await createWithRetry('apiKeys', { userId: req.session.userId, key, createdAt: new Date() });
    res.json({ apiKey: key });
  } catch (err) {
    res.status(500).json({ error: 'Gagal membuat API key' });
  }
});

// --- Deposit ---
app.get('/deposit', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const transactions = await readDB('transactions');
  const deposits = transactions.filter(t => t.userId === req.session.userId && t.type === 'deposit').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const invoices = await find('invoices', { userId: req.session.userId });
  res.render('deposit', { deposits, invoices: invoices.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), minDeposit: settings.minDeposit });
});

app.post('/invoice/create', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const userId = req.session.userId;
  const amount = parseInt(req.body.amount);
  if (isNaN(amount) || amount < settings.minDeposit) {
    req.session.errorMsg = `Minimal deposit adalah Rp ${settings.minDeposit.toLocaleString('id-ID')}`;
    return res.redirect('/deposit');
  }
  try {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const invoices = await readDB('invoices');
    const lockedInvoices = invoices.filter(i => i.status === 'pending' || (i.status === 'paid' && new Date(i.createdAt) >= oneDayAgo));
    const usedFees = lockedInvoices.map(i => Number(i.fee)).filter(f => !isNaN(f));
    const availableFees = [];
    for (let i = 1; i <= settings.maxFee; i++) {
      if (!usedFees.includes(i)) availableFees.push(i);
    }
    if (availableFees.length === 0) {
      req.session.errorMsg = 'Kode unik deposit sedang penuh. Silakan coba lagi beberapa menit.';
      return res.redirect('/deposit');
    }
    const fee = availableFees[Math.floor(Math.random() * availableFees.length)];
    const total = amount + fee;
    const url = `https://${settings.apiDomain}/?action=createpayment&apikey=${settings.apiKey}&username=${settings.username}&amount=${total}&token=${settings.token}`;
    const resp = await axios.get(url);
    const data = resp.data;
    if (!data.status) throw new Error('Gagal membuat QRIS dari gateway');
    const expiredAt = new Date(Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId, amount, fee, total,
      trxid: data.result.trxid,
      qris_image: data.result.qris_image,
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId, type: 'deposit', amount, fee,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date()
    });
    return res.redirect(`/invoice/${invoice._id}`);
  } catch (e) {
    console.error('Create invoice error:', e.response?.data || e.message);
    req.session.errorMsg = 'Gagal membuat invoice deposit. Silakan coba lagi.';
    return res.redirect('/deposit');
  }
});

app.get('/invoice/:id', isAuth, async (req, res) => {
  const inv = await findById('invoices', req.params.id);
  if (!inv || inv.userId !== req.session.userId) return res.status(404).send('Tidak ditemukan');
  res.render('invoice_detail', { inv });
});

// --- Withdraw ---
app.get('/withdraw', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const withdrawals = await find('withdrawals', { userId: req.session.userId });
  res.render('withdraw', { settings, withdrawals: withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) });
});

app.post('/withdraw/request', isAuth, async (req, res) => {
  const settings = res.locals.settings;
  const user = res.locals.user;
  if (!user.ewallet || !user.accountNumber || !user.accountName) {
    req.session.errorMsg = 'Harap lengkapi data E-Wallet di Profil terlebih dahulu.';
    return res.redirect('/withdraw');
  }
  const { amount } = req.body;
  const amt = parseInt(amount);
  const fee = settings.feeWithdraw || 0;
  const totalDeduct = amt + fee;
  if (isNaN(amt) || amt < settings.minWithdraw) {
    req.session.errorMsg = 'Minimal penarikan Rp ' + settings.minWithdraw;
    return res.redirect('/withdraw');
  }
  
  if (user.balance < totalDeduct) {
    req.session.errorMsg = 'Saldo tidak cukup (termasuk biaya admin Rp ' + fee.toLocaleString() + ')';
    return res.redirect('/withdraw');
  }
  
  user.balance -= totalDeduct;
  await updateById('users', req.session.userId, { $set: user });
  
  try {
    const ref = 'W' + Date.now().toString(36).toUpperCase();
    const wd = await createWithRetry('withdrawals', {
      _id: generateCustomId(startId.withdraw),
      userId: req.session.userId, amount: amt, fee,
      method: user.ewallet, accountNumber: user.accountNumber, accountName: user.accountName,
      status: 'pending',
      adminNote: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId: req.session.userId, type: 'withdraw', amount: amt, fee,
      status: 'pending', reference: ref,
      createdAt: new Date()
    });
    const adminChatId = await getAdminChatId();
    if (adminChatId) {
      const userForMsg = await findById('users', req.session.userId);
      const timeString = new Date(wd.createdAt).toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      }).replace(/, /, ' pukul ');
      const header = `🌐 *Notifikasi - ${settings.name}*\n\n`;
      const userInfo = `👤 *Informasi User*\n• *User:* ${userForMsg.username} (${userForMsg.email})\n• *Saldo Saat Ini:* Rp ${user.balance.toLocaleString()}\n• *E-Wallet:* ${user.ewallet}\n• *No. Rek:* \`${user.accountNumber}\`\n• *Nama Rek:* ${user.accountName}\n\n`;
      const withdrawInfo = `📤 Informasi Withdraw\n• *Jumlah:* Rp ${amt.toLocaleString()}\n• *Biaya:* Rp ${fee.toLocaleString()}\n• *Total Penarikan:* Rp ${totalDeduct.toLocaleString()}\n• *Waktu:* ${timeString}\n`;
      const inlineKeyboard = {
        inline_keyboard: [[
          { text: '✅ Setujui', callback_data: `approve_wd:${wd._id}` },
          { text: '❌ Tolak', callback_data: `reason_wd:${wd._id}` }
        ]]
      };
      sendTelegramMessage(adminChatId, header + userInfo + withdrawInfo, inlineKeyboard);
    }
    req.session.successMsg = 'Penarikan berhasil diajukan dan sedang diproses.';
  } catch (err) {
    user.balance += totalDeduct;
    await updateById('users', req.session.userId, { $set: user });
    req.session.errorMsg = 'Gagal memproses penarikan sistem.';
  }
  res.redirect('/withdraw');
});

// ===================== ADMIN ROUTES =====================
app.get('/admin/dashboard', isAuth, isAdmin, async (req, res) => {
  const stats = await getStats();
  res.render('admin_dashboard', stats);
});

app.get('/admin/users', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let users = await readDB('users');
  users = users.filter(u => u.role === 'user');
  if (search) {
    users = users.filter(u => 
      u.email.toLowerCase().includes(search.toLowerCase()) || 
      u.username.toLowerCase().includes(search.toLowerCase())
    );
  }
  users.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_users', { users, search });
});

app.get('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const targetUser = await findById('users', req.params.id);
  if (!targetUser) return res.status(404).send('Tidak ditemukan');
  res.render('admin_user_edit', { users: targetUser });
});

app.post('/admin/users/:id/edit', isAuth, isAdmin, async (req, res) => {
  const { username, email, password, balance, suspended } = req.body;
  if (username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect(`/admin/users/${req.params.id}/edit`);
    }
  }
  const user = await findById('users', req.params.id);
  if (!user) {
    req.session.errorMsg = 'User tidak ditemukan';
    return res.redirect('/admin/users');
  }
  
  if (username) user.username = username.toLowerCase();
  if (email) user.email = email.toLowerCase();
  if (balance !== undefined) user.balance = parseInt(balance) || 0;
  user.suspended = suspended === 'on';
  if (password && password.trim()) user.password = hashPassword(password);
  
  try {
    await updateById('users', req.params.id, { $set: user });
    req.session.successMsg = 'Data pengguna berhasil diperbarui';
    res.redirect('/admin/users');
  } catch (err) {
    req.session.errorMsg = 'Gagal memperbarui data pengguna';
    res.redirect(`/admin/users/${req.params.id}/edit`);
  }
});

app.post('/admin/users/:id/delete', isAuth, isAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const userToDelete = await findById('users', userId);
    if (!userToDelete) {
      req.session.errorMsg = 'User tidak ditemukan.';
      return res.redirect('/admin/users');
    }
    if (userToDelete.role === 'admin') {
      req.session.errorMsg = 'Tidak dapat menghapus akun admin.';
      return res.redirect('/admin/users');
    }
    await deleteMany('invoices', { userId });
    await deleteMany('transactions', { userId });
    await deleteMany('withdrawals', { userId });
    await deleteMany('apiKeys', { userId });
    await deleteOne('users', { _id: userId });
    req.session.successMsg = 'User berhasil dihapus beserta seluruh data terkait.';
    res.redirect('/admin/users');
  } catch (err) {
    console.error(err);
    req.session.errorMsg = 'Gagal menghapus user.';
    res.redirect('/admin/users');
  }
});

app.get('/admin/withdraw', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let withdrawals = await readDB('withdrawals');
  
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => 
      u.email.toLowerCase().includes(search.toLowerCase()) || 
      u.username.toLowerCase().includes(search.toLowerCase())
    ).map(u => u._id);
    withdrawals = withdrawals.filter(w => matchedUsers.includes(w.userId));
  }
  
  for (const w of withdrawals) {
    const user = await findById('users', w.userId);
    if (user) {
      w.username = user.username;
      w.email = user.email;
    }
  }
  withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_withdraw', { withdrawals, search });
});

app.post('/admin/withdraw/success/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'success';
    await updateById('withdrawals', wd._id, { $set: wd });
    
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'success';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    
    await updateOne('stats', {}, { $inc: { totalWithdrawAmount: wd.amount, totalWithdrawFee: wd.fee } });
    req.session.successMsg = 'Penarikan berhasil disetujui.';
  }
  res.redirect('/admin/withdraw');
});

app.post('/admin/withdraw/reject/:id', isAuth, isAdmin, async (req, res) => {
  const wd = await findById('withdrawals', req.params.id);
  if (wd && wd.status === 'pending') {
    wd.status = 'rejected';
    wd.adminNote = req.body.note || '';
    await updateById('withdrawals', wd._id, { $set: wd });
    
    const user = await findById('users', wd.userId);
    user.balance += wd.amount + wd.fee;
    await updateById('users', wd.userId, { $set: user });
    
    const transactions = await find('transactions', { userId: wd.userId, type: 'withdraw', status: 'pending' });
    const pendingWithdraw = transactions.find(t => t.reference && t.reference.startsWith('W'));
    if (pendingWithdraw) {
      pendingWithdraw.status = 'rejected';
      await updateById('transactions', pendingWithdraw._id, { $set: pendingWithdraw });
    }
    
    req.session.successMsg = 'Penarikan ditolak dan saldo dikembalikan.';
  }
  res.redirect('/admin/withdraw');
});

app.get('/admin/transactions', isAuth, isAdmin, async (req, res) => {
  const search = req.query.search || '';
  let transactions = await readDB('transactions');
  
  if (search) {
    const users = await readDB('users');
    const matchedUsers = users.filter(u => 
      u.email.toLowerCase().includes(search.toLowerCase()) || 
      u.username.toLowerCase().includes(search.toLowerCase())
    ).map(u => u._id);
    transactions = transactions.filter(t => 
      matchedUsers.includes(t.userId) || 
      (t.reference && t.reference.toLowerCase().includes(search.toLowerCase()))
    );
  }
  
  for (const t of transactions) {
    const user = await findById('users', t.userId);
    if (user) {
      t.username = user.username;
      t.email = user.email;
    }
  }
  transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.render('admin_transactions', { transactions, search });
});

app.get('/admin/account', isAuth, isAdmin, async (req, res) => {
  const admin = await findById('users', req.session.userId);
  res.render('admin_account', { admin });
});

app.post('/admin/account', isAuth, isAdmin, async (req, res) => {
  const { username, password, newPassword } = req.body;
  const admin = await findById('users', req.session.userId);
  if (!password || !verifyPassword(password, admin.password)) {
    req.session.errorMsg = 'Password saat ini salah';
    return res.redirect('/admin/account');
  }
  if (username && username !== admin.username) {
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      req.session.errorMsg = 'Username hanya boleh berisi huruf dan angka (tanpa spasi atau simbol)';
      return res.redirect('/admin/account');
    }
    if (username.length > 15) {
      req.session.errorMsg = 'Username maksimal 15 karakter';
      return res.redirect('/admin/account');
    }
    const existing = await findOne('users', { username: username.toLowerCase() });
    if (existing && existing._id !== admin._id) {
      req.session.errorMsg = 'Username sudah digunakan oleh pengguna lain';
      return res.redirect('/admin/account');
    }
  }
  try {
    if (username && username !== admin.username) admin.username = username.toLowerCase();
    if (newPassword && newPassword.trim()) admin.password = hashPassword(newPassword);
    await updateById('users', req.session.userId, { $set: admin });
    req.session.successMsg = 'Data akun berhasil diperbarui';
  } catch (e) {
    req.session.errorMsg = 'Gagal memperbarui akun';
  }
  res.redirect('/admin/account');
});

app.post('/admin/settings/reset', isAuth, isAdmin, async (req, res) => {
  try {
    const users = await readDB('users');
    const adminUser = users.find(u => u.role === 'admin');
    
    await writeDB('users', adminUser ? [adminUser] : []);
    await writeDB('invoices', []);
    await writeDB('transactions', []);
    await writeDB('withdrawals', []);
    await writeDB('apiKeys', []);
    await writeDB('stats', [{
      totalDepositAmount: 0,
      totalDepositFee: 0,
      totalWithdrawAmount: 0,
      totalWithdrawFee: 0,
      totalUsers: 0,
      totalTransactions: 0
    }]);

    req.session.successMsg = 'Database berhasil direset. Semua data pengguna, invoice, transaksi, dan withdrawal telah dihapus.';
  } catch (error) {
    console.error('Reset database error:', error);
    req.session.errorMsg = 'Gagal mereset database. Silakan coba lagi.';
  }
  res.redirect('/admin/settings');
});

app.get('/admin/settings', isAuth, isAdmin, async (req, res) => {
  res.render('admin_settings');
});

app.post('/admin/settings', isAuth, isAdmin, async (req, res) => {
  const { name, title, description, apiDomain, apiKey, username, token, minDeposit, minWithdraw, channelWhatsApp, feeWithdraw, maxFee, checkInterval, autoCheckEnabled, autoBackupEnabled, smtpUser, smtpPass, telegramBotToken, telegramAdminChatId, logoUrl } = req.body;
  
  const settings = await getSettings();
  settings.name = name;
  settings.title = title;
  settings.description = description;
  settings.apiDomain = apiDomain;
  settings.apiKey = apiKey;
  settings.username = username;
  settings.token = token;
  settings.minDeposit = parseInt(minDeposit);
  settings.minWithdraw = parseInt(minWithdraw);
  settings.feeWithdraw = parseInt(feeWithdraw);
  settings.maxFee = parseInt(maxFee);
  settings.channelWhatsApp = channelWhatsApp;
  settings.checkInterval = parseInt(checkInterval);
  settings.autoCheckEnabled = autoCheckEnabled === 'on';
  settings.autoBackupEnabled = autoBackupEnabled === 'on';
  settings.smtpUser = smtpUser;
  settings.smtpPass = smtpPass;
  settings.telegramBotToken = telegramBotToken;
  settings.telegramAdminChatId = telegramAdminChatId;
  settings.logoUrl = logoUrl;
  
  await updateById('settings', settings._id, { $set: settings });
  startChecker();
  startTelegramPolling();
  startAutoBackup();
  req.session.successMsg = 'Pengaturan berhasil diperbarui dan sistem disinkronisasi.';
  res.redirect('/admin/settings');
});

// ===================== PUBLIC API / DOCS =====================
app.get('/docs', async (req, res) => {
  let userApiKey = '';
  if (req.session.userId) {
    const key = await findOne('apiKeys', { userId: req.session.userId });
    if (key) userApiKey = key.key;
  }
  res.render('docs', { userApiKey });
});

async function apiAuth(req, res, next) {
  const apiKey = req.headers['x-api-key'] || req.query.api_key || req.query.apikey;
  if (!apiKey) return res.status(401).json({ error: 'API key diperlukan' });
  const keyDoc = await findOne('apiKeys', { key: apiKey });
  if (!keyDoc) return res.status(401).json({ error: 'API key tidak valid' });
  req.apiUser = keyDoc.userId;
  next();
}

app.get('/api/v1/balance', apiAuth, async (req, res) => {
  const user = await findById('users', req.apiUser);
  if (!user) return res.status(404).json({ error: 'User tidak ditemukan' });
  res.json({ balance: user.balance });
});

app.get('/api/v1/invoice', apiAuth, async (req, res) => {
  const settings = await getSettings();
  const amount = parseInt(req.query.amount);
  const userId = req.apiUser;
  if (!amount || isNaN(amount) || amount < settings.minDeposit) {
    return res.status(400).json({ error: `Nominal minimal Rp ${settings.minDeposit}` });
  }
  try {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const invoices = await readDB('invoices');
    const lockedInvoices = invoices.filter(i => i.status === 'pending' || (i.status === 'paid' && new Date(i.createdAt) >= oneDayAgo));
    const usedFees = lockedInvoices.map(i => Number(i.fee)).filter(f => !isNaN(f));
    const availableFees = [];
    for (let i = 1; i <= settings.maxFee; i++) {
      if (!usedFees.includes(i)) availableFees.push(i);
    }
    if (availableFees.length === 0) {
      return res.status(503).json({ error: 'Kode unik sedang penuh, silakan coba lagi beberapa menit.' });
    }
    const fee = availableFees[Math.floor(Math.random() * availableFees.length)];
    const total = amount + fee;
    const url = `https://${settings.apiDomain}/?action=createpayment&apikey=${settings.apiKey}&username=${settings.username}&amount=${total}&token=${settings.token}`;
    const resp = await axios.get(url);
    const data = resp.data;
    if (!data.status) throw new Error('Gagal membuat pembayaran');
    const expiredAt = new Date(Date.now() + 10 * 60 * 1000);
    const invoice = await createWithRetry('invoices', {
      _id: generateCustomId(startId.invoice),
      userId, amount, fee, total,
      trxid: data.result.trxid,
      qris_image: data.result.qris_image,
      expiredAt,
      status: 'pending',
      mutationId: null,
      createdAt: new Date()
    });
    await createWithRetry('transactions', {
      _id: generateCustomId(startId.transaction),
      userId, type: 'deposit', amount, fee,
      status: 'pending',
      reference: invoice._id.toString(),
      expiredAt,
      createdAt: new Date()
    });
    return res.json({
      success: true,
      invoice_id: invoice._id,
      amount: invoice.amount,
      fee: invoice.fee,
      total: invoice.total,
      qris_image: invoice.qris_image,
      expired_at: invoice.expiredAt
    });
  } catch (e) {
    console.error('API create invoice error:', e.response?.data || e.message);
    return res.status(500).json({ error: 'Gagal membuat invoice' });
  }
});

app.get('/api/v1/invoice/status', apiAuth, async (req, res) => {
  const invoiceId = req.query.id || req.query.invoice_id;
  if (!invoiceId) return res.status(400).json({ error: 'Invoice ID diperlukan' });
  const invoice = await findById('invoices', invoiceId);
  if (!invoice || invoice.userId !== req.apiUser) {
    return res.status(404).json({ error: 'Invoice tidak ditemukan' });
  }
  res.json({
    invoice_id: invoice._id,
    amount: invoice.amount,
    fee: invoice.fee,
    total: invoice.total,
    status: invoice.status,
    qris_image: invoice.qris_image,
    expired_at: invoice.expiredAt,
    created_at: invoice.createdAt
  });
});

// ===================== BACKUP ROUTES =====================
app.get('/admin/backup', isAuth, isAdmin, async (req, res) => {
  const settings = await getSettings();
  const hasTelegram = !!(settings.telegramBotToken && settings.telegramAdminChatId);
  res.render('admin_backup', { hasTelegram });
});

app.post('/admin/backup/create', isAuth, isAdmin, async (req, res) => {
  try {
    const result = await performBackupAndSend();
    
    if (result.success) {
      req.session.successMsg = `✅ Backup berhasil dibuat! File: ${result.fileName}${result.sentToTelegram ? ' (sudah dikirim ke Telegram)' : ' (Telegram belum dikonfigurasi, file tersimpan di server)'}`;
    } else {
      req.session.errorMsg = `❌ Backup gagal: ${result.error}`;
    }
  } catch (error) {
    req.session.errorMsg = `❌ Backup gagal: ${error.message}`;
  }
  
  res.redirect('/admin/backup');
});

// ===================== AUTO BACKUP SCHEDULER =====================
let autoBackupInterval = null;

async function startAutoBackup() {
  if (autoBackupInterval) {
    clearInterval(autoBackupInterval);
    autoBackupInterval = null;
  }
  
  const settings = await getSettings();
  if (!settings.autoBackupEnabled) {
    console.log('⏸️ Auto backup dimatikan');
    return;
  }
  
  // Hitung waktu hingga jam 00:00 besok
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);
  const msUntilMidnight = tomorrow - now;
  
  console.log(`⏰ Auto backup akan berjalan pada ${tomorrow.toLocaleString('id-ID')}`);
  
  setTimeout(() => {
    performBackupAndSend();
    autoBackupInterval = setInterval(() => {
      performBackupAndSend();
    }, 24 * 60 * 60 * 1000);
  }, msUntilMidnight);
}

// ===================== AUTO MUTASI =====================
let checkerInterval;
async function checkMutasi() {
  try {
    const settings = await getSettings();
    if (!settings.autoCheckEnabled || !settings.apiKey) return;
    
    let invoices = await readDB('invoices');
    const pendingInvoices = invoices.filter(i => i.status === 'pending');
    const now = new Date();
    
    for (const inv of pendingInvoices) {
      if (now > new Date(inv.expiredAt)) {
        inv.status = 'expired';
        await updateById('invoices', inv._id, { $set: inv });
        
        const transactions = await readDB('transactions');
        const tx = transactions.find(t => t.reference === inv._id.toString() && t.type === 'deposit' && t.status === 'pending');
        if (tx) {
          tx.status = 'expired';
          await updateById('transactions', tx._id, { $set: tx });
        }
      }
    }
    
    invoices = await readDB('invoices');
    const mutasiUrl = `https://${settings.apiDomain}/?action=mutasiqr&apikey=${settings.apiKey}&username=${settings.username}&token=${settings.token}`;
    const resp = await axios.get(mutasiUrl);
    const data = resp.data;
    
    if (!data.status || !data.result || !data.result.success || !Array.isArray(data.result.results)) return;
    
    const results = data.result.results;
    const usedMutationIds = invoices.filter(i => i.mutationId !== null).map(i => String(i.mutationId));
    const availableMutations = results.filter(tx => tx.status === 'IN' && !usedMutationIds.includes(String(tx.id)));
    
    for (const inv of invoices) {
      if (inv.status !== 'pending') continue;
      
      const matchedMutation = availableMutations.find(tx => {
        const nominal = parseInt(String(tx.kredit).replace(/\./g, ''));
        if (nominal !== inv.total) return false;
        
        const rawDateString = tx.tanggal || tx.created_at || tx.createdAt || tx.date || tx.datetime;
        if (!rawDateString) return false;
        
        let mutationTime;
        if (rawDateString.includes('/')) {
          const [datePart, timePart] = rawDateString.split(' ');
          const [day, month, year] = datePart.split('/');
          mutationTime = new Date(`${year}-${month}-${day}T${timePart}+07:00`);
        } else {
          mutationTime = new Date(rawDateString);
        }
        
        if (isNaN(mutationTime.getTime())) return false;
        const diffMinutes = Math.abs(mutationTime.getTime() - new Date(inv.createdAt).getTime()) / 1000 / 60;
        return diffMinutes <= 30;
      });
      
      if (!matchedMutation) continue;
      
      inv.status = 'paid';
      inv.mutationId = String(matchedMutation.id);
      await updateById('invoices', inv._id, { $set: inv });
      
      const user = await findById('users', inv.userId);
      if (user) {
        user.balance = (user.balance || 0) + inv.amount;
        await updateById('users', inv.userId, { $set: user });
      }
      
      const transactions = await readDB('transactions');
      const tx = transactions.find(t => t.reference === inv._id.toString() && t.type === 'deposit' && t.status === 'pending');
      if (tx) {
        tx.status = 'paid';
        await updateById('transactions', tx._id, { $set: tx });
      }
      
      await updateOne('stats', {}, { $inc: { totalDepositAmount: inv.amount, totalDepositFee: inv.fee, totalTransactions: 1 } });
      
      const index = availableMutations.findIndex(tx => String(tx.id) === String(matchedMutation.id));
      if (index !== -1) availableMutations.splice(index, 1);
      
      const adminChatId = await getAdminChatId();
      if (adminChatId && user) {
        const timeString = new Date().toLocaleString('id-ID', {
          timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric',
          hour: '2-digit', minute: '2-digit', second: '2-digit'
        });
        const message = `🌐 *Notifikasi - ${settings.name}*\n\n👤 *Informasi User*\n• User: ${user.username} (${user.email})\n• Saldo Saat Ini: Rp ${user.balance.toLocaleString('id-ID')}\n\n💰 *Informasi Deposit*\n• Jumlah: Rp ${inv.amount.toLocaleString('id-ID')}\n• Fee: Rp ${inv.fee.toLocaleString('id-ID')}\n• Total: Rp ${inv.total.toLocaleString('id-ID')}\n• ID Invoice: ${inv._id}\n• Waktu: ${timeString}\n• Status: ✅ Paid`;
        await sendTelegramMessage(adminChatId, message);
      }
    }
  } catch (err) {
    console.error('Mutasi error:', err.response?.data || err.message);
  }
}

async function updateStatsOnStartup() {
  const transactions = await readDB('transactions');
  
  const depositPaid = transactions.filter(t => t.type === 'deposit' && t.status === 'paid');
  const withdrawSuccess = transactions.filter(t => t.type === 'withdraw' && t.status === 'success');
  
  const dAmount = depositPaid.reduce((sum, t) => sum + (t.amount || 0), 0);
  const dFee = depositPaid.reduce((sum, t) => sum + (t.fee || 0), 0);
  const wAmount = withdrawSuccess.reduce((sum, t) => sum + (t.amount || 0), 0);
  const wFee = withdrawSuccess.reduce((sum, t) => sum + (t.fee || 0), 0);
  const totalUsers = await countDocuments('users', { role: 'user' });
  const totalTransactions = transactions.length;
  
  const stats = await findOne('stats', {});
  if (stats) {
    stats.totalDepositAmount = dAmount;
    stats.totalDepositFee = dFee;
    stats.totalWithdrawAmount = wAmount;
    stats.totalWithdrawFee = wFee;
    stats.totalUsers = totalUsers;
    stats.totalTransactions = totalTransactions;
    await updateById('stats', stats._id, { $set: stats });
  } else {
    await insertOne('stats', {
      _id: 'stats_1',
      totalDepositAmount: dAmount,
      totalDepositFee: dFee,
      totalWithdrawAmount: wAmount,
      totalWithdrawFee: wFee,
      totalUsers,
      totalTransactions
    });
  }
}

function startChecker() {
  if (checkerInterval) clearInterval(checkerInterval);
  getSettings().then(s => {
    if (s.autoCheckEnabled) {
      checkerInterval = setInterval(checkMutasi, s.checkInterval * 1000);
      checkMutasi();
    }
  });
}

// Inisialisasi database dan start semua service
setTimeout(async () => {
  await seed();
  await updateStatsOnStartup();
  startChecker();
  startTelegramPolling();
  startAutoBackup();
}, 2000);

app.listen(PORT, () => console.log(`🚀 Server berjalan di http://localhost:${PORT}`));